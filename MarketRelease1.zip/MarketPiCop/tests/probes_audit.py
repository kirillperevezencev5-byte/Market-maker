"""Audit probes (iteration 1). Run only on a COPY of the project. They observe behaviour; they do not assert 'correct' behaviour."""
import json
import unittest

from tests import test_app as T


def setUpModule():
    T.setUpModule()

OUT = {}


def rec(key, value):
    OUT[key] = value
    print("PROBE", key, "=>", json.dumps(value, ensure_ascii=False, default=str)[:400], flush=True)


class Probes(unittest.TestCase):
    def test_01_billing(self):
        c, *_ = T.make_user_with_channel("Probe billing")
        st, me = c.get("/me")
        rec("new_user_default_plan", {"plan": me["plan"], "resource_limit": me["resource_limit"], "features": me["features"]})
        old = T.cfg.BILLING_MODE
        try:
            T.cfg.BILLING_MODE = "sandbox"
            c2, *_ = T.make_user_with_channel("Probe billing 2")
            st, r = c2.post("/subscriptions", {"plan": "business"})
            st2, me2 = c2.get("/me")
            rec("sandbox_self_upgrade", {"status": st, "plan_after": me2["plan"]})
            sid = r.get("id")
            st, r = c2.post(f"/subscriptions/{sid}/renew", {"months": 120})
            rec("sandbox_renew_120_months", {"status": st, "ends_at": r.get("ends_at")})
            st, r = c2.post(f"/subscriptions/{sid}/renew", {"months": 10 ** 12})
            rec("sandbox_renew_huge_months", {"status": st, "body": str(r)[:120]})
            T.cfg.BILLING_MODE = "live"
            c3, *_ = T.make_user_with_channel("Probe billing 3")
            st, r = c3.post("/subscriptions", {"plan": "business"})
            rec("live_self_upgrade", {"status": st, "error": r.get("error")})
            st, r = c3.post("/subscriptions", {"plan": "free"})
            sid3 = r.get("id")
            st, r = c3.post(f"/subscriptions/{sid3}/renew", {"months": 3})
            rec("live_renew_free_plan", {"status": st})
            st, me3 = c3.get("/me")
            rec("live_plan_after_downgrade_to_free", me3["plan"])
            st, r = c3.post("/subscriptions", {"plan": "pro"})
            rec("live_free_to_pro", {"status": st, "error": r.get("error")})
            st, r = c3.post("/subscriptions", {"plan": "beta"})
            rec("live_free_to_beta_legacy", {"status": st, "error": r.get("error")})
            # tables: any platform payment table?
            tables = [r["name"] for r in T.db.q("SELECT name FROM sqlite_master WHERE type='table'")]
            rec("tables_with_payment", [t for t in tables if "payment" in t or "transaction" in t or "ledger" in t])
        finally:
            T.cfg.BILLING_MODE = old

    def test_02_feature_gates_on_free(self):
        c, u, chat, res = T.make_user_with_channel("Probe gates")
        uid = T.db.one("SELECT id FROM users WHERE telegram_id=?", u["id"])["id"]
        T.db.run("UPDATE users SET plan='free' WHERE id=?", uid)
        st, me = c.get("/me")
        rec("gate_plan", me["plan"])
        rid = res["id"]
        res_ = {}
        res_["templates"] = c.post("/templates", {"name": "t", "text": "hello"})[0]
        res_["autoclean"] = c.post("/autoclean/rules", {"resource_id": rid, "match_type": "keyword", "match_text": "x"})[0]
        res_["moderation"] = c.post("/moderation/rules", {"resource_id": rid, "match_type": "keyword", "match_text": "x", "action": "warn"})[0]
        res_["autoreply"] = c.post("/autoreplies", {"resource_id": rid, "trigger": "hi", "reply": "yo", "match_type": "keyword", "name": "a"})[0]
        res_["antiscam_domain"] = c.post("/anti-scam/domains", {"resource_id": rid, "domain": "bad.example", "kind": "block"})[0]
        res_["ads"] = c.post("/ads", {"resource_id": rid, "title": "ad", "text": "x"})[0]
        res_["export"] = c.get("/export")[0]
        res_["second_connect"] = None
        rec("free_plan_route_status", res_)
        later = (T.datetime.now(T.timezone.utc) + T.timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%SZ")
        st, r = c.post("/posts", {"text": "scheduled on free", "resource_ids": [rid], "mode": "schedule", "scheduled_at": later})
        rec("free_plan_schedule_post", {"status": st, "err": r.get("error")})
        # resource limit
        c2, u2 = T.Client(), T.new_tg_user()
        T.login_via_bot(c2, u2)
        T.db.run("UPDATE users SET plan='free' WHERE telegram_id=?", u2["id"])
        T.connect_channel(c2, u2, "Free ch 1")
        st, r = c2.post("/resources/link-code")
        rec("free_second_link_code", {"status": st, "err": r.get("error")})
        # bot.py path (actual /connect from chat)
        T.chat = None

    def test_03_autopost_moderation(self):
        owner, owner_tg, chat, res = T.make_user_with_channel("Probe autopost", "supergroup")
        st, s = owner.get(f"/community-autopost/owner/{res['id']}")
        rec("autopost_owner_view_status", st)
        st, g = owner.get(f"/communities/{res['id']}/autopost") if False else (None, None)
        buyer, btg = T.Client(), T.new_tg_user()
        T.login_via_bot(buyer, btg)
        T.FAKE.members[(chat["id"], btg["id"])] = {"status": "member"}
        st, settings = owner.get(f"/communities/{res['id']}/autopost")
        rec("default_settings_require_moderation", (settings or {}).get("require_moderation") if isinstance(settings, dict) else settings)
        st, sub = buyer.post("/community-autopost/submissions", {
            "resource_id": res["id"], "idempotency_key": "probe-moderation-0000001",
            "category": "goods", "text": "Продам велосипед"})
        rec("submission_initial_status_with_default_moderation_on", {"status": st, "state": sub.get("status")})
        # owner did nothing; run scheduler step
        n = T.marketplace.process_autopost_submissions()
        final = T.db.one("SELECT status FROM community_autopost_submissions WHERE id=?", sub["id"])["status"]
        sent = any(m == "sendMessage" and p.get("chat_id") == chat["id"] and p.get("text") == "Продам велосипед" for m, p in T.FAKE.calls)
        rec("published_without_owner_decision", {"processed": n, "final_status": final, "message_sent_to_chat": sent})
        # idempotency + limits
        st, again = buyer.post("/community-autopost/submissions", {
            "resource_id": res["id"], "idempotency_key": "probe-moderation-0000001",
            "category": "goods", "text": "Продам велосипед"})
        rec("idempotent_repeat", {"status": st, "same_id": again.get("id") == sub["id"]})
        st, second = buyer.post("/community-autopost/submissions", {
            "resource_id": res["id"], "idempotency_key": "probe-moderation-0000002",
            "category": "goods", "text": "Второе"})
        rec("second_submission_same_day", {"status": st, "err": second.get("error")})
        # history table?
        tables = [r["name"] for r in T.db.q("SELECT name FROM sqlite_master WHERE type='table'")]
        rec("autopost_history_tables", [t for t in tables if "autopost" in t])
        # list leak: unrelated user sees groups of other owners without being a member
        stranger, stg = T.Client(), T.new_tg_user()
        T.login_via_bot(stranger, stg)
        st, lst = stranger.get("/community-autopost/communities")
        rec("stranger_sees_foreign_group_in_list", {"status": st, "visible": any(i["resource_id"] == res["id"] for i in lst["items"]), "count": len(lst["items"])})
        # cross-tenant review attempt
        st, r = stranger.post(f"/community-autopost/owner/{res['id']}/review", {"submission_id": sub["id"], "decision": "reject", "reason": "x"})
        rec("stranger_review_foreign", {"status": st})
        st, r = stranger.get(f"/community-autopost/owner/{res['id']}")
        rec("stranger_owner_view_foreign", {"status": st})
        # owner reviews a published one
        st, r = owner.post(f"/community-autopost/owner/{res['id']}/review", {"submission_id": sub["id"], "decision": "approve"})
        rec("review_after_publish", {"status": st, "err": r.get("error")})

    def test_04_webhook_and_headers(self):
        c = T.Client()
        req = T.urllib.request.Request(T.BASE + "/api/v1/status")
        with c.opener.open(req) as r:
            csp = r.headers.get("Content-Security-Policy")
        rec("csp", csp)
        st, r = c.call("POST", "/webhooks/yookassa", {"type": "notification", "event": "payment.succeeded", "object": {"id": "forged", "status": "succeeded", "metadata": {"payment_id": "1"}}})
        rec("forged_webhook", {"status": st, "body": str(r)[:150]})


def tearDownModule():  # noqa: F811
    T.tearDownModule()
    with open("/tmp/claude-0/-home-claude/613aa0e9-22f4-572d-aa67-22d168d823e9/scratchpad/probes.json", "w") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=1, default=str)


if __name__ == "__main__":
    unittest.main()
