"""Community plans, YooKassa payments, subscription lifecycle and owner settlement views."""
import json
import time
import hashlib
import logging
import re
import secrets
import sqlite3
import threading
from datetime import datetime, time as dt_time, timedelta, timezone
from zoneinfo import ZoneInfo

from . import db, payments, security, telegram
from .config import cfg
from .server import ApiError, require_role, route

_maintenance_lock = threading.Lock()
log = logging.getLogger("marketpilot.marketplace")
PLAN_PERMISSION_FIELDS = telegram.CHAT_PERMISSION_FIELDS
PLAN_QUOTA_FIELDS = {"max_messages_per_day"}
PLAN_FEATURE_FIELDS = {"autopost"}
AUTOPOST_CATEGORIES = {
    "goods": "Товары", "services": "Услуги", "jobs": "Работа",
    "real_estate": "Недвижимость", "other": "Другое",
}
AUTOPOST_ACTIVE_STATUSES = ("pending", "approved", "scheduled", "publishing", "published", "unknown")


def _feature_ready() -> None:
    if not cfg.COMMUNITY_PAYMENTS_ENABLED:
        raise ApiError(503, "payments_disabled", "Оплата подписок временно отключена")
    if not payments.configured():
        raise ApiError(503, "billing_unavailable", "Оплата YooKassa ещё не подключена")
    if not cfg.PUBLIC_URL.startswith("https://"):
        raise ApiError(503, "https_required", "Для оплаты нужен публичный HTTPS-адрес")


def _activate_pending_merchants() -> None:
    db.run("UPDATE community_merchants SET status='active',updated_at=? "
           "WHERE status='pending' AND payout_phone!='' AND payout_bank!=''", db.now_iso())


def _require_platform_admin(req) -> None:
    if not req.actor_user or req.actor_user["telegram_id"] not in cfg.PLATFORM_ADMIN_TELEGRAM_IDS:
        raise ApiError(403, "platform_admin_required", "Доступно только администратору платформы")


def _resource_for_owner(req, resource_id: int, role: str = "admin"):
    require_role(req, req.workspace_id, role)
    resource = db.one("SELECT * FROM resources WHERE id=? AND user_id=? AND is_demo=0 AND status='active'",
                      resource_id, req.user["id"])
    if resource is None:
        raise ApiError(404, "not_found", "Сообщество не найдено")
    return resource


def _refresh_community_resource(resource) -> dict:
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram для проверки сообщества")
    try:
        chat = client.get_chat(resource["chat_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_check_failed", "Не удалось проверить актуальные настройки сообщества в Telegram") from exc
    chat_type = chat.get("type")
    if chat_type not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Платный доступ доступен только для групп и супергрупп")
    current = dict(resource)
    current["type"] = chat_type
    current["title"] = chat.get("title") or resource["title"]
    current["username"] = chat.get("username")
    db.run("UPDATE resources SET type=?,title=?,username=?,last_checked_at=? WHERE id=?",
           current["type"], current["title"], current["username"], db.now_iso(), resource["id"])
    return current


def _ensure_paid_access_supported(resource) -> None:
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Платный доступ пока поддерживается только для групп и супергрупп")
    client = telegram.client()
    if client is None or not telegram.is_live() or not telegram.state.get("bot_id"):
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram для управления доступом")
    try:
        member = client.chat_member(resource["chat_id"], telegram.state["bot_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError):
        raise ApiError(503, "telegram_rights_unavailable", "Не удалось проверить права бота в группе")
    missing = []
    if member.get("status") not in ("administrator", "creator"):
        missing.append("права администратора")
    if member.get("status") == "administrator" and not resource["username"] and not member.get("can_invite_users"):
        missing.append("приглашение участников")
    if member.get("status") == "administrator" and not member.get("can_restrict_members"):
        missing.append("ограничение участников")
    if missing:
        raise ApiError(409, "bot_rights_missing", "Боту не хватает прав: " + ", ".join(missing))


def _plan_dict(row) -> dict:
    permissions = json.loads(row["limits_json"] or "{}")
    permissions.setdefault("autopost", True)
    return {"id": row["id"], "resource_id": row["resource_id"], "community": row["community"],
            "name": row["name"], "description": row["description"], "amount_minor": row["amount_minor"],
            "price": payments.money(row["amount_minor"]), "currency": "RUB", "duration_days": row["duration_days"],
            "max_members": row["max_members"], "active": bool(row["active"]),
            "permissions": permissions}


def _validate_plan_permissions(value) -> dict:
    if not isinstance(value, dict):
        raise ApiError(422, "validation", "Права тарифа должны быть объектом разрешений")
    unknown = set(value) - set(PLAN_PERMISSION_FIELDS) - PLAN_QUOTA_FIELDS - PLAN_FEATURE_FIELDS
    if unknown:
        raise ApiError(422, "validation", "В тарифе указано неизвестное ограничение")
    if any(not isinstance(value[key], bool)
           for key in set(value) & (set(PLAN_PERMISSION_FIELDS) | PLAN_FEATURE_FIELDS)):
        raise ApiError(422, "validation", "Каждое право тарифа должно быть включено или выключено")
    quota = value.get("max_messages_per_day")
    if quota is not None and (isinstance(quota, bool) or not isinstance(quota, int) or not 1 <= quota <= 10000):
        raise ApiError(422, "validation", "Дневной лимит должен быть от 1 до 10000 сообщений или пустым")
    result = {key: bool(value[key]) for key in PLAN_PERMISSION_FIELDS if key in value}
    result["autopost"] = bool(value.get("autopost", True))
    if "max_messages_per_day" in value:
        result["max_messages_per_day"] = quota
    return result


def _validate_chat_permissions(value) -> dict:
    if not isinstance(value, dict) or set(value) != set(telegram.CHAT_PERMISSION_FIELDS):
        raise ApiError(422, "validation", "Передайте все стандартные права Telegram")
    if any(not isinstance(allowed, bool) for allowed in value.values()):
        raise ApiError(422, "validation", "Каждое стандартное право должно быть включено или выключено")
    return {key: value[key] for key in telegram.CHAT_PERMISSION_FIELDS}


def _has_member_permissions(permissions: dict) -> bool:
    return any(key in permissions for key in PLAN_PERMISSION_FIELDS)


def autopost_subscriptions(buyer_user_id: int):
    now = db.now_iso()
    return db.q(
        "SELECT s.id subscription_id,s.buyer_user_id,s.ends_at,b.telegram_id buyer_telegram_id,r.id resource_id,r.workspace_id,"
        "r.user_id owner_user_id,r.chat_id,r.title community,r.type,r.status resource_status,"
        "r.capabilities,r.missing_rights,u.timezone owner_timezone,b.timezone buyer_timezone,"
        "p.name plan_name,p.limits_json,"
        "COALESCE(a.enabled,1) autopost_enabled "
        "FROM community_subscriptions s JOIN community_plans p ON p.id=s.plan_id "
        "JOIN resources r ON r.id=s.resource_id JOIN users u ON u.id=s.owner_user_id "
        "JOIN users b ON b.id=s.buyer_user_id "
        "LEFT JOIN community_autopost_settings a ON a.resource_id=r.id "
        "WHERE s.buyer_user_id=? AND s.status IN ('active','cancelled') "
        "AND COALESCE(s.starts_at,s.created_at)<=? AND s.ends_at>? "
        "AND r.status='active' AND r.is_demo=0 AND r.type IN ('group','supergroup') "
        "ORDER BY r.title,s.id DESC",
        buyer_user_id, now, now,
    )


def autopost_subscription(subscription_id: int, buyer_user_id: int):
    return next((row for row in autopost_subscriptions(buyer_user_id)
                 if row["subscription_id"] == subscription_id), None)


def _autopost_member_resource(resource_id: int, user_id: int, telegram_user_id: int):
    resource = db.one(
        "SELECT r.id resource_id,r.workspace_id,r.user_id owner_user_id,r.chat_id,r.title community,"
        "r.type,r.status resource_status,r.is_demo,r.capabilities,r.missing_rights,u.timezone owner_timezone "
        "FROM resources r JOIN users u ON u.id=r.user_id "
        "WHERE r.id=? AND r.status='active' AND r.is_demo=0 AND r.type IN ('group','supergroup')",
        resource_id,
    )
    if resource is None:
        raise ApiError(404, "not_found", "Сообщество не найдено")
    settings = _autopost_settings(resource_id)
    if not settings["enabled"]:
        raise ApiError(403, "autopost_disabled", "Владелец временно отключил объявления в этом сообществе")

    active_subscriptions = [row for row in autopost_subscriptions(user_id) if row["resource_id"] == resource_id]
    if active_subscriptions:
        eligible = next((row for row in active_subscriptions
                         if json.loads(row["limits_json"] or "{}").get("autopost", True) is not False), None)
        if eligible is None:
            raise ApiError(403, "autopost_not_in_plan", "Автопостинг не входит в ваш тариф сообщества")
        return eligible

    if db.one("SELECT 1 FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
              resource_id, telegram_user_id):
        raise ApiError(403, "autopost_blocked", "Владелец сообщества запретил вам отправлять объявления")
    if isinstance(telegram_user_id, bool) or not isinstance(telegram_user_id, int) or telegram_user_id <= 0:
        raise ApiError(403, "telegram_identity_required", "Войдите через Telegram, чтобы подтвердить участие в группе")
    if not telegram.is_live() or telegram.client() is None:
        raise ApiError(503, "telegram_unavailable", "Не удалось проверить ваше участие в Telegram-сообществе")
    try:
        member = telegram.client().chat_member(resource["chat_id"], telegram_user_id)
    except telegram.TelegramNetworkError as exc:
        raise ApiError(503, "telegram_check_failed", "Не удалось проверить ваше участие в сообществе") from exc
    except telegram.TelegramError as exc:
        if exc.code == 400 and "user not found" in exc.description.lower():
            member = {"status": "left"}
        else:
            raise ApiError(503, "telegram_check_failed", "Не удалось проверить ваше участие в сообществе") from exc
    if member.get("status") in ("left", "kicked") or (
            member.get("status") == "restricted" and not member.get("is_member")):
        raise ApiError(403, "community_membership_required", "Вступите в сообщество, чтобы отправить объявление")
    return {**dict(resource), "subscription_id": None, "buyer_telegram_id": telegram_user_id}


def _initial_status(draft: bool, settings: dict) -> str:
    """draft -> draft; moderation on -> pending (nothing is published without an owner decision); off -> scheduled."""
    if draft:
        return "draft"
    return "pending" if settings["require_moderation"] else "scheduled"


def _history_actor(submission_id: int, user_id: int, reason: str = "") -> None:
    """The DB trigger records every status change; this attaches who did it to the latest entry."""
    db.run("UPDATE community_autopost_history SET actor_user_id=?, reason=CASE WHEN ?!='' THEN ? ELSE reason END "
           "WHERE id=(SELECT MAX(id) FROM community_autopost_history WHERE submission_id=?)",
           user_id, reason, reason, submission_id)


_MEMBERSHIP_CACHE: dict = {}
_MEMBERSHIP_TTL = 300


def _is_group_member(chat_id: int, telegram_user_id: int) -> bool:
    """Live getChatMember with a short cache, so listing communities never shows a group the user is not in."""
    key = (chat_id, telegram_user_id)
    cached = _MEMBERSHIP_CACHE.get(key)
    if cached and time.time() - cached[0] < _MEMBERSHIP_TTL:
        return cached[1]
    client = telegram.client()
    if client is None or not telegram.is_live():
        return False
    try:
        member = client.chat_member(chat_id, telegram_user_id)
    except (telegram.TelegramError, telegram.TelegramNetworkError):
        return False
    ok = not (member.get("status") in ("left", "kicked") or
              (member.get("status") == "restricted" and not member.get("is_member")))
    _MEMBERSHIP_CACHE[key] = (time.time(), ok)
    return ok


def _autopost_settings(resource_id: int) -> dict:
    row = db.one("SELECT * FROM community_autopost_settings WHERE resource_id=?", resource_id)
    if row is None:
        return {
            "enabled": True, "require_moderation": True, "auto_publish": True,
            "allow_scheduling": False, "max_text_length": 1000, "max_photos": 1,
            "daily_limit": 1, "monthly_limit": 10, "min_interval_minutes": 60,
            "allow_links": False, "allowed_categories": ["goods", "services", "other"],
        }
    return {
        "enabled": bool(row["enabled"]), "require_moderation": bool(row["require_moderation"]),
        "auto_publish": bool(row["auto_publish"]), "allow_scheduling": bool(row["allow_scheduling"]),
        "max_text_length": row["max_text_length"], "max_photos": row["max_photos"],
        "daily_limit": row["daily_limit"], "monthly_limit": row["monthly_limit"],
        "min_interval_minutes": row["min_interval_minutes"], "allow_links": bool(row["allow_links"]),
        "allowed_categories": json.loads(row["allowed_categories_json"] or "[]"),
    }


def _validate_autopost_settings(value: dict) -> dict:
    boolean_fields = ("enabled", "require_moderation", "auto_publish", "allow_scheduling", "allow_links")
    if any(not isinstance(value.get(key), bool) for key in boolean_fields):
        raise ApiError(422, "validation", "Параметры автопостинга должны содержать логические значения")
    limits = {
        "max_text_length": (1, 4096), "max_photos": (0, 10),
        "daily_limit": (0, 1000), "monthly_limit": (0, 10000),
        "min_interval_minutes": (0, 10080),
    }
    result = {key: value[key] for key in boolean_fields}
    for key, (minimum, maximum) in limits.items():
        number = value.get(key)
        if isinstance(number, bool) or not isinstance(number, int) or not minimum <= number <= maximum:
            raise ApiError(422, "validation", f"Параметр «{key}» должен быть целым числом от {minimum} до {maximum}")
        result[key] = number
    categories = value.get("allowed_categories")
    if (not isinstance(categories, list) or not categories or
            any(not isinstance(category, str) or category not in AUTOPOST_CATEGORIES for category in categories) or
            len(set(categories)) != len(categories)):
        raise ApiError(422, "validation", "Выберите хотя бы одну допустимую категорию объявления")
    result["allowed_categories"] = categories
    return result


def _submission_payload(row, include_author: bool = False) -> dict:
    result = {
        "id": row["id"], "resource_id": row["resource_id"], "community": row["community"],
        "subscription_id": row["subscription_id"], "category": row["category"],
        "text": row["text"], "media": json.loads(row["media_json"] or "[]"),
        "scheduled_at": row["scheduled_at"], "status": row["status"],
        "review_reason": row["review_reason"], "created_at": row["created_at"],
        "published_at": row["published_at"], "error": row["error"],
    }
    if include_author:
        result["author"] = {
            "user_id": row["buyer_user_id"], "telegram_id": row["buyer_telegram_id"],
            "first_name": row["first_name"], "username": row["username"],
            "published_count": row["author_published_count"],
        }
    return result


def _submission_query(where: str, *args):
    return db.q(
        "SELECT s.*,r.title community,u.telegram_id buyer_telegram_id,u.first_name,u.username,"
        "(SELECT COUNT(*) FROM community_autopost_submissions published "
        "WHERE published.resource_id=s.resource_id AND published.buyer_user_id=s.buyer_user_id "
        "AND published.status='published') author_published_count,"
        "(SELECT json_group_array(json_object('id',m.id,'filename',m.filename,'mime',m.mime)) "
        "FROM media_uploads m WHERE m.user_id=s.buyer_user_id "
        "AND m.id IN (SELECT value FROM json_each(s.media_ids_json))) media_json "
        "FROM community_autopost_submissions s "
        "JOIN resources r ON r.id=s.resource_id JOIN users u ON u.id=s.buyer_user_id "
        f"WHERE {where} ORDER BY s.created_at DESC,s.id DESC", *args,
    )


def _quota_window(timezone_name: str):
    local_now = db.now().astimezone(ZoneInfo(timezone_name))
    local_midnight = datetime.combine(local_now.date(), dt_time.min, tzinfo=local_now.tzinfo)
    month_start = local_midnight.replace(day=1)
    return db.iso(local_midnight), db.iso(local_midnight + timedelta(days=1)), db.iso(month_start)


def _validate_autopost_content(body: dict, settings: dict):
    text = str(body.get("text") or "").strip()
    from .api import validate_text

    media_ids = body.get("media_ids", [])
    category = body.get("category", "other")
    if not isinstance(media_ids, list) or len(media_ids) > settings["max_photos"]:
        raise ApiError(422, "validation", "Превышено допустимое количество фотографий")
    if (any(isinstance(media_id, bool) or not isinstance(media_id, int) or media_id <= 0 for media_id in media_ids)
            or len(set(media_ids)) != len(media_ids)):
        raise ApiError(422, "validation", "Список фотографий содержит неверные идентификаторы")
    if category not in settings["allowed_categories"]:
        raise ApiError(422, "category_not_allowed", "Эта категория объявлений не разрешена владельцем")
    visible_length = validate_text(text, bool(media_ids))
    if visible_length > settings["max_text_length"]:
        raise ApiError(422, "text_too_long", "Текст объявления превышает установленный лимит")
    if not text and not media_ids:
        raise ApiError(422, "empty_submission", "Добавьте текст или фотографию")
    if not settings["allow_links"] and re.search(
            r"(?:https?://|www\.|(?:t\.me|telegram\.me)/|\b[\w.-]+\.[a-zа-я]{2,}\b)", text, re.IGNORECASE):
        raise ApiError(422, "links_not_allowed", "Владелец запретил ссылки в объявлениях")

    scheduled_value = body.get("scheduled_at")
    if scheduled_value:
        if not settings["allow_scheduling"]:
            raise ApiError(422, "scheduling_not_allowed", "Владелец не разрешил планирование публикаций")
        try:
            scheduled_at = db.parse_iso(str(scheduled_value))
        except ValueError as exc:
            raise ApiError(422, "bad_schedule", "Укажите дату в формате ISO 8601 UTC") from exc
        now = db.now()
        if scheduled_at <= now or scheduled_at > now + timedelta(days=365):
            raise ApiError(422, "bad_schedule", "Публикацию можно запланировать не более чем на год вперёд")
    else:
        scheduled_at = db.now()
    return text, category, media_ids, db.iso(scheduled_at)


def _validate_owned_media(user_id: int, media_ids: list[int]) -> None:
    if not media_ids:
        return
    marks = ",".join("?" for _ in media_ids)
    owned = db.q(f"SELECT id,size FROM media_uploads WHERE user_id=? AND id IN ({marks})",
                 user_id, *media_ids)
    if len(owned) != len(media_ids):
        raise ApiError(403, "media_forbidden", "Одно или несколько изображений недоступны")
    if sum(row["size"] for row in owned) > 50 * 1024 * 1024:
        raise ApiError(413, "media_group_too_large", "Общий размер фотографий не должен превышать 50 MiB")


def _check_autopost_limits(subscription, settings: dict, user_id: int, scheduled_at: str,
                           exclude_id: int | None = None):
    day_start, day_end, month_start = _quota_window(subscription["owner_timezone"])
    status_marks = ",".join("?" for _ in AUTOPOST_ACTIVE_STATUSES)
    base = (subscription["resource_id"], user_id, *AUTOPOST_ACTIVE_STATUSES)
    exclude_sql = " AND id!=?" if exclude_id is not None else ""
    exclude_args = (exclude_id,) if exclude_id is not None else ()
    if settings["daily_limit"] and db.one(
            f"SELECT COUNT(*) n FROM community_autopost_submissions WHERE resource_id=? AND buyer_user_id=? "
            f"AND status IN ({status_marks}) AND created_at>=? AND created_at<?{exclude_sql}",
            *base, day_start, day_end, *exclude_args)["n"] >= settings["daily_limit"]:
        raise ApiError(429, "daily_limit", "Достигнут дневной лимит объявлений")
    if settings["monthly_limit"] and db.one(
            f"SELECT COUNT(*) n FROM community_autopost_submissions WHERE resource_id=? AND buyer_user_id=? "
            f"AND status IN ({status_marks}) AND created_at>=?{exclude_sql}",
            *base, month_start, *exclude_args)["n"] >= settings["monthly_limit"]:
        raise ApiError(429, "monthly_limit", "Достигнут месячный лимит объявлений")
    if settings["min_interval_minutes"]:
        distance = timedelta(minutes=settings["min_interval_minutes"])
        schedule_dt = db.parse_iso(scheduled_at)
        nearby = db.one(
            f"SELECT 1 FROM community_autopost_submissions WHERE resource_id=? AND buyer_user_id=? "
            f"AND status IN ({status_marks}) AND scheduled_at>? AND scheduled_at<?{exclude_sql} LIMIT 1",
            *base, db.iso(schedule_dt - distance), db.iso(schedule_dt + distance), *exclude_args,
        )
        if nearby:
            raise ApiError(429, "minimum_interval", "Между публикациями должно пройти больше времени")


def _current_chat_permissions(resource) -> dict:
    saved = db.one("SELECT permissions_json FROM community_chat_settings WHERE resource_id=?", resource["id"])
    if saved is not None:
        return json.loads(saved["permissions_json"])
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram")
    try:
        chat = client.get_chat(resource["chat_id"])
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_permissions_unavailable", "Не удалось получить стандартные права группы") from exc
    current = chat.get("permissions") or {}
    return {key: bool(current.get(key, True)) for key in telegram.CHAT_PERMISSION_FIELDS}


@route("GET", "/api/v1/communities/<int:id>/permissions")
def get_community_permissions(req):
    resource = _resource_for_owner(req, req.params["id"], "viewer")
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Стандартные права доступны только для групп")
    return {"permissions": _current_chat_permissions(resource)}


@route("PUT", "/api/v1/communities/<int:id>/permissions")
def update_community_permissions(req):
    resource = _resource_for_owner(req, req.params["id"])
    if resource["type"] not in ("group", "supergroup"):
        raise ApiError(409, "unsupported_community_type", "Стандартные права доступны только для групп")
    permissions = _validate_chat_permissions(req.body.get("permissions"))
    client = telegram.client()
    if client is None or not telegram.is_live():
        raise ApiError(503, "telegram_unavailable", "Бот должен быть подключён к Telegram")
    try:
        member = client.chat_member(resource["chat_id"], telegram.state["bot_id"])
        if member.get("status") not in ("administrator", "creator"):
            raise ApiError(409, "bot_rights_missing", "Бот должен быть администратором группы")
        client.set_chat_permissions(resource["chat_id"], permissions)
    except (telegram.TelegramError, telegram.TelegramNetworkError) as exc:
        raise ApiError(503, "telegram_permissions_update_failed",
                       "Telegram не принял стандартные права. Проверьте права администратора бота.") from exc
    db.run("INSERT INTO community_chat_settings(resource_id,permissions_json,updated_at) VALUES(?,?,?) "
           "ON CONFLICT(resource_id) DO UPDATE SET permissions_json=excluded.permissions_json,updated_at=excluded.updated_at",
           resource["id"], json.dumps(permissions), db.now_iso())
    return {"permissions": permissions}


def _queue_access(subscription_id: int, action: str) -> None:
    db.run("INSERT OR IGNORE INTO community_access_jobs(workspace_id,subscription_id,action,created_at,updated_at) "
           "SELECT workspace_id,id,?,?,? FROM community_subscriptions WHERE id=?",
           action, db.now_iso(), db.now_iso(), subscription_id)


def _queue_member_permission(subscription_id: int) -> None:
    now = db.now_iso()
    db.run("INSERT INTO community_permission_jobs(workspace_id,subscription_id,created_at,updated_at) "
           "SELECT workspace_id,id,?,? FROM community_subscriptions WHERE id=? "
           "ON CONFLICT(subscription_id) DO UPDATE SET status='pending',attempts=0,last_error='',updated_at=excluded.updated_at",
           now, now, subscription_id)


def queue_member_permissions(chat_id: int, telegram_user_id: int) -> int:
    subscriptions = db.q(
        "SELECT s.id FROM community_subscriptions s "
        "JOIN resources r ON r.id=s.resource_id JOIN users u ON u.id=s.buyer_user_id "
        "WHERE r.chat_id=? AND u.telegram_id=? AND s.status='active' AND s.starts_at<=? AND s.ends_at>?",
        chat_id, telegram_user_id, db.now_iso(), db.now_iso(),
    )
    for subscription in subscriptions:
        _queue_member_permission(subscription["id"])
    process_member_permission_jobs()
    return len(subscriptions)


def process_member_permission_jobs(limit: int = 20) -> int:
    client = telegram.client()
    if client is None or not telegram.is_live():
        return 0
    rows = db.q(
        "SELECT j.id job_id,s.id subscription_id,s.status,s.ends_at,p.limits_json,r.chat_id,u.telegram_id "
        "FROM community_permission_jobs j JOIN community_subscriptions s ON s.id=j.subscription_id "
        "JOIN community_plans p ON p.id=s.plan_id JOIN resources r ON r.id=s.resource_id "
        "JOIN users u ON u.id=s.buyer_user_id WHERE j.status IN ('pending','failed','processing') "
        "ORDER BY j.id LIMIT ?", limit,
    )
    completed = 0
    for row in rows:
        db.run("UPDATE community_permission_jobs SET status='processing',attempts=attempts+1,updated_at=? WHERE id=?",
               db.now_iso(), row["job_id"])
        try:
            if row["status"] != "active" or not row["ends_at"] or row["ends_at"] <= db.now_iso():
                db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                       db.now_iso(), row["job_id"])
                completed += 1
                continue
            member = client.chat_member(row["chat_id"], row["telegram_id"])
            if member.get("status") not in ("member", "administrator", "creator", "restricted"):
                db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                       db.now_iso(), row["job_id"])
                completed += 1
                continue
            plan_settings = json.loads(row["limits_json"] or "{}")
            permissions = {key: plan_settings[key] for key in PLAN_PERMISSION_FIELDS if key in plan_settings}
            if permissions:
                client.restrict_chat_member(row["chat_id"], row["telegram_id"], permissions)
            db.run("UPDATE community_permission_jobs SET status='done',last_error='',updated_at=? WHERE id=?",
                   db.now_iso(), row["job_id"])
            completed += 1
        except Exception as exc:
            log.exception("applying community permissions failed for job %s", row["job_id"])
            db.run("UPDATE community_permission_jobs SET status='failed',last_error=?,updated_at=? WHERE id=?",
                   f"{type(exc).__name__}: {exc}"[:300], db.now_iso(), row["job_id"])
    return completed


def _settle_payment(provider_payment: dict, event_key: str = "") -> None:
    payment_id = (provider_payment.get("metadata") or {}).get("payment_id")
    if not payment_id or not str(payment_id).isdigit():
        raise ApiError(400, "payment_metadata_invalid", "Платёж не связан с заказом MarketPilot")
    local = db.one("SELECT * FROM community_payments WHERE id=?", int(payment_id))
    if local is None or local["provider_payment_id"] != provider_payment.get("id"):
        raise ApiError(404, "payment_not_found", "Заказ не найден")
    amount = provider_payment.get("amount") or {}
    if amount.get("currency") != "RUB" or amount.get("value") != payments.money(local["amount_minor"]):
        raise ApiError(400, "payment_amount_mismatch", "Сумма или валюта платежа не совпадает с заказом")
    if provider_payment.get("status") != "succeeded":
        return

    method = provider_payment.get("payment_method") or {}
    subscription = db.one("SELECT * FROM community_subscriptions WHERE id=?", local["subscription_id"])
    if subscription is None:
        raise ApiError(404, "subscription_not_found", "Подписка не найдена")
    saved_method_id = (method.get("id") if method.get("saved") else
                       subscription["payment_method_id"] if local["is_recurring"] else None)
    if event_key:
        db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
               "yookassa", event_key, "payment.succeeded", db.now_iso())

    with db.tx():
        current = db.one("SELECT status FROM community_payments WHERE id=?", local["id"])
        if current["status"] == "succeeded":
            return
        db.run("UPDATE community_payments SET status='succeeded', paid_at=?, payment_method_id=? WHERE id=?",
               db.now_iso(), saved_method_id, local["id"])
        duration = db.one("SELECT duration_days FROM community_plans WHERE id=?", local["plan_id"])["duration_days"]
        base = db.parse_iso(subscription["ends_at"]) if subscription["ends_at"] and subscription["ends_at"] > db.now_iso() else db.now()
        end = db.iso(base + timedelta(days=duration))
        auto_renew = bool(subscription["auto_renew"] and saved_method_id)
        db.run("UPDATE community_subscriptions SET status='active', starts_at=COALESCE(starts_at,?), ends_at=?, "
               "auto_renew=?, payment_method_id=?, updated_at=? WHERE id=?",
               db.now_iso(), end, int(auto_renew), saved_method_id if auto_renew else None, db.now_iso(), subscription["id"])
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="sale", amount_minor=local["amount_minor"],
                  created_at=db.now_iso())
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="commission", amount_minor=-local["commission_minor"],
                  created_at=db.now_iso())
        db.insert("community_ledger", workspace_id=local["workspace_id"], owner_user_id=local["owner_user_id"],
              resource_id=local["resource_id"],
                  payment_id=local["id"], currency="RUB", kind="payout", amount_minor=-local["owner_amount_minor"],
                  created_at=db.now_iso())
        payout_details = db.one("SELECT payout_phone,payout_bank FROM community_merchants WHERE resource_id=?",
                                local["resource_id"])
        db.insert("community_manual_payouts", payment_id=local["id"], owner_user_id=local["owner_user_id"],
                  payout_phone=payout_details["payout_phone"] if payout_details else "",
                  payout_bank=payout_details["payout_bank"] if payout_details else "",
                  amount_minor=local["owner_amount_minor"], status="pending",
                  created_at=db.now_iso(), updated_at=db.now_iso())
        db.event(local["buyer_user_id"], "community_subscription_active",
                 "Оплата подтверждена, привилегии тарифа активированы", local["resource_id"])
        db.event(local["owner_user_id"], "community_sale", "YooKassa подтвердила оплату тарифа сообщества", local["resource_id"])
        _queue_access(subscription["id"], "invite")
        _queue_member_permission(subscription["id"])


def _reconcile_payment(local) -> dict:
    if not local["provider_payment_id"]:
        if not cfg.COMMUNITY_PAYMENTS_ENABLED:
            return dict(local)
        if local["status"] != "unknown":
            return dict(local)
        subscription = db.one("SELECT * FROM community_subscriptions WHERE id=?", local["subscription_id"])
        plan = db.one("SELECT p.* FROM community_plans p JOIN community_merchants m "
                      "ON m.resource_id=p.resource_id AND m.status='active' WHERE p.id=?", local["plan_id"])
        if subscription is None or plan is None:
            return dict(local)
        try:
            result = payments.create_payment(amount_minor=local["amount_minor"], payment_id=local["id"],
                subscription_id=subscription["id"], return_url=f"{cfg.PUBLIC_URL}/app/?payment={local['id']}",
                save_payment_method=bool(subscription["auto_renew"]), idempotency_key=local["idempotency_key"])
        except payments.PaymentProviderError as exc:
            if not exc.ambiguous:
                db.run("UPDATE community_payments SET status='canceled' WHERE id=?", local["id"])
                db.run("UPDATE community_subscriptions SET status='payment_failed',auto_renew=0,updated_at=? WHERE id=?",
                       db.now_iso(), subscription["id"])
            return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))
        db.run("UPDATE community_payments SET provider_payment_id=?,confirmation_url=?,status=? WHERE id=?",
               result.get("id"), (result.get("confirmation") or {}).get("confirmation_url"),
               result.get("status", "pending"), local["id"])
        if result.get("status") == "succeeded":
            _settle_payment(result)
        return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))
    try:
        provider_payment = payments.get_payment(local["provider_payment_id"])
    except payments.PaymentProviderError as exc:
        raise ApiError(503, "payment_status_unavailable", str(exc))
    if provider_payment.get("status") == "succeeded":
        _settle_payment(provider_payment)
    elif provider_payment.get("status") == "canceled":
        db.run("UPDATE community_payments SET status='canceled' WHERE id=? AND status IN ('pending','unknown')", local["id"])
        db.run("UPDATE community_subscriptions SET auto_renew=0, updated_at=? WHERE id=? AND status IN ('pending','active')",
               db.now_iso(), local["subscription_id"])
    return dict(db.one("SELECT * FROM community_payments WHERE id=?", local["id"]))


def _payment_dict(row) -> dict:
    return {"id": row["id"], "subscription_id": row["subscription_id"], "amount": payments.money(row["amount_minor"]),
            "currency": row["currency"], "status": row["status"], "confirmation_url": row["confirmation_url"],
            "created_at": row["created_at"], "paid_at": row["paid_at"]}


@route("PUT", "/api/v1/communities/<int:id>/merchant")
def connect_merchant(req):
    resource = _resource_for_owner(req, req.params["id"], "owner")
    phone = str(req.body.get("payout_phone") or "").strip()
    if not re.fullmatch(r"[+0-9\s().-]+", phone):
        raise ApiError(422, "validation", "Проверьте формат номера телефона")
    digits = "".join(char for char in phone if "0" <= char <= "9")
    bank = str(req.body.get("payout_bank") or "").strip()
    if len(bank) > 80:
        raise ApiError(422, "validation", "Название банка должно быть не длиннее 80 символов")
    if not 10 <= len(digits) <= 15:
        raise ApiError(422, "validation", "Укажите номер телефона для перевода (от 10 до 15 цифр)")
    if not bank:
        raise ApiError(422, "validation", "Укажите банк для перевода")
    phone = "+" + digits
    status = "active"
    db.run("INSERT INTO community_merchants(resource_id,workspace_id,owner_user_id,yookassa_account_id,"
           "payout_phone,payout_bank,status,created_at,updated_at) VALUES(?,?,?,'',?,?,?,?,?) "
           "ON CONFLICT(resource_id) DO UPDATE SET workspace_id=excluded.workspace_id, "
           "yookassa_account_id='',"
           "payout_phone=excluded.payout_phone,payout_bank=excluded.payout_bank,status=excluded.status,"
           "updated_at=excluded.updated_at",
           resource["id"], resource["workspace_id"], req.user["id"], phone, bank, status, db.now_iso(), db.now_iso())
    db.audit(req.actor_user["id"], "community_merchant_connected", method="PUT", status=200,
             resource_id=resource["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"resource_id": resource["id"], "status": status}


@route("GET", "/api/v1/communities/<int:id>/merchant")
def get_merchant(req):
    resource = _resource_for_owner(req, req.params["id"], "viewer")
    _activate_pending_merchants()
    merchant = db.one("SELECT status,payout_phone,payout_bank FROM community_merchants WHERE resource_id=? AND owner_user_id=?",
                      resource["id"], req.user["id"])
    can_view_payout_details = req.actor_user["id"] == req.workspace_owner_id
    return {"resource_id": resource["id"], "status": merchant["status"] if merchant else "not_connected",
            "payout_phone": merchant["payout_phone"] if merchant and can_view_payout_details else "",
            "payout_bank": merchant["payout_bank"] if merchant and can_view_payout_details else ""}


@route("GET", "/api/v1/communities/<int:id>/autopost")
def get_community_autopost(req):
    resource = _resource_for_owner(req, req.params["id"], "viewer")
    settings = _autopost_settings(resource["id"])
    settings["categories"] = [{"id": key, "name": label} for key, label in AUTOPOST_CATEGORIES.items()]
    return settings


@route("PUT", "/api/v1/communities/<int:id>/autopost")
def update_community_autopost(req):
    resource = _resource_for_owner(req, req.params["id"])
    current = _autopost_settings(resource["id"])
    allowed = {
        "enabled", "require_moderation", "auto_publish", "allow_scheduling", "max_text_length",
        "max_photos", "daily_limit", "monthly_limit", "min_interval_minutes", "allow_links",
        "allowed_categories",
    }
    if set(req.body) - allowed:
        raise ApiError(422, "validation", "Передан неизвестный параметр автопостинга")
    current.update(req.body)
    settings = _validate_autopost_settings(current)
    db.run(
        "INSERT INTO community_autopost_settings(resource_id,enabled,require_moderation,auto_publish,allow_scheduling,"
        "max_text_length,max_photos,daily_limit,monthly_limit,min_interval_minutes,allow_links,allowed_categories_json,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(resource_id) DO UPDATE SET "
        "enabled=excluded.enabled,require_moderation=excluded.require_moderation,auto_publish=excluded.auto_publish,"
        "allow_scheduling=excluded.allow_scheduling,max_text_length=excluded.max_text_length,max_photos=excluded.max_photos,"
        "daily_limit=excluded.daily_limit,monthly_limit=excluded.monthly_limit,"
        "min_interval_minutes=excluded.min_interval_minutes,allow_links=excluded.allow_links,"
        "allowed_categories_json=excluded.allowed_categories_json,updated_at=excluded.updated_at",
        resource["id"], int(settings["enabled"]), int(settings["require_moderation"]), int(settings["auto_publish"]),
        int(settings["allow_scheduling"]), settings["max_text_length"], settings["max_photos"],
        settings["daily_limit"], settings["monthly_limit"], settings["min_interval_minutes"],
        int(settings["allow_links"]), json.dumps(settings["allowed_categories"]), db.now_iso(),
    )
    db.event(req.actor_user["id"], "community_autopost_settings_updated",
             f"Обновлены правила объявлений в «{resource['title']}»", resource["id"])
    return settings


@route("GET", "/api/v1/community-autopost/communities")
def member_autopost_communities(req):
    items = []
    seen = set()
    subscribed_resources = set()
    subscriptions = autopost_subscriptions(req.actor_user["id"])
    for subscription in subscriptions:
        resource_id = subscription["resource_id"]
        subscribed_resources.add(resource_id)
        if resource_id in seen or not bool(subscription["autopost_enabled"]):
            continue
        if json.loads(subscription["limits_json"] or "{}").get("autopost", True) is False:
            continue
        seen.add(resource_id)
        items.append({
            "subscription_id": subscription["subscription_id"], "resource_id": resource_id,
            "community": subscription["community"], "plan": subscription["plan_name"],
            "ends_at": subscription["ends_at"], "settings": _autopost_settings(subscription["resource_id"]),
        })
    ordinary_communities = db.q(
        "SELECT r.id resource_id,r.chat_id,r.title community FROM resources r "
        "LEFT JOIN community_autopost_settings a ON a.resource_id=r.id "
        "WHERE r.status='active' AND r.is_demo=0 AND r.type IN ('group','supergroup') "
        "AND COALESCE(a.enabled,1)=1 ORDER BY r.title,r.id"
    )
    telegram_user_id = req.actor_user["telegram_id"]
    for community in ordinary_communities[:60]:
        resource_id = community["resource_id"]
        if resource_id in subscribed_resources or resource_id in seen:
            continue
        if isinstance(telegram_user_id, bool) or not isinstance(telegram_user_id, int) or telegram_user_id <= 0:
            continue
        if not _is_group_member(community["chat_id"], telegram_user_id):
            continue  # a group is listed only after Telegram confirms the user is in it
        if db.one("SELECT 1 FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
                  resource_id, telegram_user_id):
            continue
        seen.add(resource_id)
        items.append({
            "subscription_id": None, "resource_id": resource_id, "community": community["community"],
            "plan": "Участник сообщества", "ends_at": None, "settings": _autopost_settings(resource_id),
        })
    return {"items": items, "categories": [{"id": key, "name": label} for key, label in AUTOPOST_CATEGORIES.items()]}


@route("GET", "/api/v1/community-autopost/submissions")
def member_autopost_submissions(req):
    rows = _submission_query("s.buyer_user_id=?", req.actor_user["id"])
    return {"items": [_submission_payload(row) for row in rows]}


@route("POST", "/api/v1/community-autopost/submissions")
def create_autopost_submission(req):
    subscription_id = req.body.get("subscription_id")
    subscription = None
    if subscription_id is not None:
        if isinstance(subscription_id, bool) or not isinstance(subscription_id, int) or subscription_id <= 0:
            raise ApiError(422, "validation", "Выберите сообщество")
        subscription = autopost_subscription(subscription_id, req.actor_user["id"])
        if subscription is None:
            raise ApiError(403, "autopost_subscription_required", "Нужна действующая подписка на сообщество")
        resource = subscription
    else:
        resource_id = req.body.get("resource_id")
        if isinstance(resource_id, bool) or not isinstance(resource_id, int) or resource_id <= 0:
            raise ApiError(422, "validation", "Выберите сообщество")
        resource = _autopost_member_resource(resource_id, req.actor_user["id"], req.actor_user["telegram_id"])
        if resource["subscription_id"] is not None:
            subscription = resource
    idempotency_key = str(req.body.get("idempotency_key") or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{16,80}", idempotency_key):
        raise ApiError(422, "validation", "Неверный ключ отправки объявления")
    existing = db.one("SELECT id FROM community_autopost_submissions WHERE buyer_user_id=? AND idempotency_key=?",
                      req.actor_user["id"], idempotency_key)
    if existing:
        row = _submission_query("s.id=?", existing["id"])[0]
        return _submission_payload(row)

    settings = _autopost_settings(resource["resource_id"])
    if not settings["enabled"]:
        raise ApiError(403, "autopost_disabled", "Владелец временно отключил объявления в этом сообществе")
    if subscription and json.loads(subscription["limits_json"] or "{}").get("autopost", True) is False:
        raise ApiError(403, "autopost_not_in_plan", "Автопостинг не входит в ваш тариф сообщества")
    blocked = db.one("SELECT 1 FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
                     resource["resource_id"], req.actor_user["telegram_id"])
    if blocked:
        raise ApiError(403, "autopost_blocked", "Владелец сообщества запретил вам отправлять объявления")
    text, category, media_ids, scheduled_at = _validate_autopost_content(req.body, settings)
    _validate_owned_media(req.actor_user["id"], media_ids)
    draft = req.body.get("draft", False)
    if not isinstance(draft, bool):
        raise ApiError(422, "validation", "Параметр черновика должен быть логическим")
    status = _initial_status(draft, settings)
    now = db.now_iso()
    created = False
    try:
        with db.tx():
            existing = db.one("SELECT id FROM community_autopost_submissions WHERE buyer_user_id=? AND idempotency_key=?",
                              req.actor_user["id"], idempotency_key)
            if existing:
                submission_id = existing["id"]
            else:
                if not draft:
                    _check_autopost_limits(resource, settings, req.actor_user["id"], scheduled_at)
                submission_id = db.insert(
                    "community_autopost_submissions", workspace_id=resource["workspace_id"],
                    resource_id=resource["resource_id"],
                    subscription_id=subscription["subscription_id"] if subscription else None,
                    buyer_user_id=req.actor_user["id"], category=category, text=text,
                    media_ids_json=json.dumps(media_ids), idempotency_key=idempotency_key,
                    scheduled_at=scheduled_at, status=status, created_at=now, updated_at=now,
                )
                created = True
    except sqlite3.IntegrityError:
        existing = db.one("SELECT id FROM community_autopost_submissions WHERE buyer_user_id=? AND idempotency_key=?",
                          req.actor_user["id"], idempotency_key)
        if existing is None:
            raise
        submission_id = existing["id"]
    if created and status == "pending":
        from .bot import notify_owner
        notice = f"Новое объявление на модерации в «{resource['community']}»"
        db.event(resource["owner_user_id"], "community_ad_pending", notice, resource["resource_id"])
        notify_owner(resource["owner_user_id"], notice, "tools")
    db.audit(req.actor_user["id"], "community_ad_submitted", method="POST", status=201,
             resource_id=resource["resource_id"], entity_id=submission_id,
             request_id=req.request_id, workspace_id=resource["workspace_id"])
    return 201, _submission_payload(_submission_query("s.id=?", submission_id)[0])


@route("PUT", "/api/v1/community-autopost/submissions/<int:id>")
def update_autopost_submission(req):
    row = db.one("SELECT * FROM community_autopost_submissions WHERE id=? AND buyer_user_id=?",
                 req.params["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Объявление не найдено")
    if row["status"] not in ("draft", "pending", "approved", "rejected", "revision", "scheduled"):
        raise ApiError(409, "bad_state", "Объявление уже отправляется или опубликовано")
    subscription = (autopost_subscription(row["subscription_id"], req.actor_user["id"])
                   if row["subscription_id"] is not None else None)
    if row["subscription_id"] is not None and subscription is None:
        raise ApiError(403, "autopost_subscription_required", "Нужна действующая подписка на сообщество")
    resource = subscription or _autopost_member_resource(
        row["resource_id"], req.actor_user["id"], req.actor_user["telegram_id"])
    if subscription and json.loads(subscription["limits_json"] or "{}").get("autopost", True) is False:
        raise ApiError(403, "autopost_not_in_plan", "Автопостинг не входит в ваш тариф сообщества")
    settings = _autopost_settings(row["resource_id"])
    text, category, media_ids, scheduled_at = _validate_autopost_content(req.body, settings)
    _validate_owned_media(req.actor_user["id"], media_ids)
    draft = req.body.get("draft", False)
    if not isinstance(draft, bool):
        raise ApiError(422, "validation", "Параметр черновика должен быть логическим")
    status = _initial_status(draft, settings)
    now = db.now_iso()
    with db.tx():
        if not draft:
            if not settings["enabled"]:
                raise ApiError(403, "autopost_disabled", "Владелец временно отключил объявления в этом сообществе")
            if db.one("SELECT 1 FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
                      row["resource_id"], req.actor_user["telegram_id"]):
                raise ApiError(403, "autopost_blocked", "Владелец сообщества запретил вам отправлять объявления")
            _check_autopost_limits(resource, settings, req.actor_user["id"], scheduled_at, row["id"])
        cur = db.run("UPDATE community_autopost_submissions SET category=?,text=?,media_ids_json=?,scheduled_at=?,status=?,"
                     "review_reason='',reviewed_by=NULL,error=NULL,updated_at=? WHERE id=? AND buyer_user_id=? "
                     "AND status IN ('draft','pending','approved','rejected','revision','scheduled')",
                     category, text, json.dumps(media_ids), scheduled_at, status, now, row["id"], req.actor_user["id"])
        if cur.rowcount != 1:
            raise ApiError(409, "bad_state", "Объявление уже нельзя изменить")
        _history_actor(row["id"], req.actor_user["id"])
    return _submission_payload(_submission_query("s.id=?", row["id"])[0])


@route("DELETE", "/api/v1/community-autopost/submissions/<int:id>")
def cancel_autopost_submission(req):
    row = db.one("SELECT * FROM community_autopost_submissions WHERE id=? AND buyer_user_id=?",
                 req.params["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Объявление не найдено")
    if row["status"] not in ("draft", "pending", "approved", "scheduled", "rejected", "revision"):
        raise ApiError(409, "bad_state", "Отменить объявление в этом статусе нельзя")
    with db.tx():
        cur = db.run("UPDATE community_autopost_submissions SET status='cancelled',updated_at=? WHERE id=? "
                     "AND status IN ('draft','pending','approved','scheduled','rejected','revision')",
                     db.now_iso(), row["id"])
        if cur.rowcount != 1:
            raise ApiError(409, "bad_state", "Объявление уже начало публиковаться")
        _history_actor(row["id"], req.actor_user["id"])
    return {"id": row["id"], "status": "cancelled"}


@route("GET", "/api/v1/community-autopost/owner/<int:id>")
def owner_autopost_submissions(req):
    require_role(req, req.workspace_id, "moderator")
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    status = req.query.get("status", "")
    if status and status not in {"pending", "approved", "rejected", "revision", "scheduled", "published", "failed", "cancelled", "unknown"}:
        raise ApiError(422, "validation", "Неизвестный статус объявления")
    where = "s.resource_id=?"
    args = [resource["id"]]
    if status:
        where += " AND s.status=?"
        args.append(status)
    rows = _submission_query(where, *args)
    counts = db.q("SELECT status,COUNT(*) n FROM community_autopost_submissions "
                  "WHERE resource_id=? GROUP BY status", resource["id"])
    return {"items": [_submission_payload(row, include_author=True) for row in rows],
            "stats": {row["status"]: row["n"] for row in counts}}


@route("POST", "/api/v1/community-autopost/owner/<int:id>/review")
def review_autopost_submission(req):
    require_role(req, req.workspace_id, "moderator")
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    decision = req.body.get("decision")
    reason = str(req.body.get("reason") or "").strip()[:300]
    if decision not in ("approve", "reject", "pending", "publish", "revision"):
        raise ApiError(422, "validation", "Выберите решение для объявления")
    submission_id = req.body.get("submission_id")
    if isinstance(submission_id, bool) or not isinstance(submission_id, int) or submission_id <= 0:
        raise ApiError(422, "validation", "Объявление не найдено")
    row = db.one("SELECT * FROM community_autopost_submissions WHERE id=? AND resource_id=?",
                 submission_id, resource["id"])
    if row is None:
        raise ApiError(404, "not_found", "Объявление не найдено")
    if row["status"] not in ("pending", "approved", "rejected", "revision", "scheduled"):
        raise ApiError(409, "bad_state", "Решение нельзя изменить после начала публикации")
    settings = _autopost_settings(resource["id"])
    if decision in ("reject", "revision"):
        if not reason:
            raise ApiError(422, "reason_required", "Укажите причину")
        next_status = "revision" if decision == "revision" else "rejected"
    elif decision == "pending":
        next_status = "pending"
    elif decision == "publish" or settings["auto_publish"]:
        next_status = "scheduled"
    else:
        next_status = "approved"
    with db.tx():
        cur = db.run("UPDATE community_autopost_submissions SET status=?,review_reason=?,reviewed_by=?,error=NULL,updated_at=? "
                     "WHERE id=? AND status IN ('pending','approved','rejected','revision','scheduled')",
                     next_status, reason if decision in ("reject", "revision") else "", req.actor_user["id"],
                     db.now_iso(), row["id"])
        if cur.rowcount != 1:
            raise ApiError(409, "bad_state", "Объявление уже начало публиковаться")
        _history_actor(row["id"], req.actor_user["id"], reason)
    notice = ("Объявление отклонено: " + reason if decision == "reject" else
              "Нужно исправить объявление: " + reason if decision == "revision" else
              "Объявление одобрено владельцем")
    db.event(row["buyer_user_id"], "community_ad_reviewed", notice, resource["id"])
    from .bot import notify_owner
    buyer = db.one("SELECT id FROM users WHERE id=?", row["buyer_user_id"])
    if buyer:
        notify_owner(buyer["id"], notice, "tools")
    return {"id": row["id"], "status": next_status, "review_reason": reason if decision in ("reject", "revision") else ""}


@route("GET", "/api/v1/community-autopost/submissions/<int:id>/history")
def member_submission_history(req):
    row = db.one("SELECT id FROM community_autopost_submissions WHERE id=? AND buyer_user_id=?",
                 req.params["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Объявление не найдено")
    return {"items": _history_items(row["id"])}


@route("GET", "/api/v1/community-autopost/owner/<int:id>/history")
def owner_submission_history(req):
    require_role(req, req.workspace_id, "moderator")
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    submission_id = req.int_param("submission_id", 0, 0, 2 ** 31)
    row = db.one("SELECT id FROM community_autopost_submissions WHERE id=? AND resource_id=?",
                 submission_id, resource["id"])
    if row is None:
        raise ApiError(404, "not_found", "Объявление не найдено")
    return {"items": _history_items(row["id"])}


def _history_items(submission_id: int) -> list:
    rows = db.q("SELECT h.from_status,h.to_status,h.reason,h.created_at,h.actor_user_id,u.first_name actor_name "
                "FROM community_autopost_history h LEFT JOIN users u ON u.id=h.actor_user_id "
                "WHERE h.submission_id=? ORDER BY h.id", submission_id)
    return [{"from": r["from_status"], "to": r["to_status"], "reason": r["reason"], "at": r["created_at"],
             "actor": r["actor_name"] if r["actor_user_id"] else "система"} for r in rows]


@route("GET", "/api/v1/community-autopost/owner/<int:id>/blocked")
def list_autopost_blocks(req):
    require_role(req, req.workspace_id, "moderator")
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    rows = db.q("SELECT b.telegram_user_id,b.reason,b.created_at,u.first_name,u.username "
                "FROM community_autopost_blocks b LEFT JOIN users u ON u.telegram_id=b.telegram_user_id "
                "WHERE b.resource_id=? ORDER BY b.created_at DESC", resource["id"])
    return {"items": [dict(row) for row in rows]}


@route("POST", "/api/v1/community-autopost/owner/<int:id>/blocked")
def block_autopost_member(req):
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    user_id = req.body.get("telegram_user_id")
    if isinstance(user_id, bool) or not isinstance(user_id, int) or user_id <= 0:
        raise ApiError(422, "validation", "Укажите Telegram ID участника")
    db.run("INSERT INTO community_autopost_blocks(resource_id,telegram_user_id,reason,created_at) VALUES(?,?,?,?) "
           "ON CONFLICT(resource_id,telegram_user_id) DO UPDATE SET reason=excluded.reason",
           resource["id"], user_id, str(req.body.get("reason") or "")[:300], db.now_iso())
    return {"telegram_user_id": user_id, "blocked": True}


@route("DELETE", "/api/v1/community-autopost/owner/<int:id>/blocked/<int:user>")
def unblock_autopost_member(req):
    resource = _resource_for_owner(req, req.params["id"], "moderator")
    db.run("DELETE FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
           resource["id"], req.params["user"])
    return {"telegram_user_id": req.params["user"], "blocked": False}


def recover_stuck_autopost_submissions() -> int:
    cutoff = db.iso(db.now() - timedelta(minutes=5))
    rows = db.q("SELECT s.id,s.buyer_user_id,s.resource_id,r.title community,COALESCE(c.owner_user_id,r.user_id) owner_user_id "
                "FROM community_autopost_submissions s JOIN resources r ON r.id=s.resource_id "
                "LEFT JOIN community_subscriptions c ON c.id=s.subscription_id "
                "WHERE s.status='publishing' AND s.started_at<?", cutoff)
    if not rows:
        return 0
    with db.tx():
        db.run("UPDATE community_autopost_submissions SET status='unknown',"
               "error='Отправка прервалась; сообщение могло быть опубликовано. Проверьте сообщество.',"
               "updated_at=? WHERE status='publishing' AND started_at<?", db.now_iso(), cutoff)
    from .bot import notify_owner
    for row in rows:
        db.event(row["buyer_user_id"], "community_ad_unknown",
                 "Не удалось подтвердить публикацию объявления. Проверьте сообщество.", row["resource_id"])
        notify_owner(row["buyer_user_id"], "Не удалось подтвердить публикацию объявления. Проверьте сообщество.", "tools")
        db.event(row["owner_user_id"], "community_ad_unknown",
                 f"Не удалось подтвердить публикацию объявления в «{row['community']}».", row["resource_id"])
        notify_owner(row["owner_user_id"], f"Не удалось подтвердить публикацию объявления в «{row['community']}».", "tools")
    return len(rows)


def process_autopost_submissions(limit: int = 20) -> int:
    now = db.now_iso()
    rows = db.q("SELECT id FROM community_autopost_submissions WHERE status IN ('approved','scheduled') "
                "AND scheduled_at<=? "
                "AND (next_attempt_at IS NULL OR next_attempt_at<=?) ORDER BY scheduled_at,id LIMIT ?",
                now, now, max(1, min(int(limit), 100)))
    claimed = []
    for row in rows:
        with db.tx():
            cur = db.run("UPDATE community_autopost_submissions SET status='publishing',started_at=?,"
                         "attempts=attempts+1,updated_at=? WHERE id=? AND status IN ('approved','scheduled')",
                         now, now, row["id"])
        if cur.rowcount == 1:
            claimed.append(row["id"])
    for submission_id in claimed:
        try:
            _deliver_autopost_submission(submission_id)
        except Exception:
            log.exception("community autopost submission %s crashed", submission_id)
            db.run("UPDATE community_autopost_submissions SET status='unknown',"
                   "error='Внутренняя ошибка при отправке; проверьте сообщество перед повтором',updated_at=? "
                   "WHERE id=? AND status='publishing'", db.now_iso(), submission_id)
            row = db.one("SELECT s.buyer_user_id,s.resource_id,r.title community,COALESCE(c.owner_user_id,r.user_id) owner_user_id "
                         "FROM community_autopost_submissions s JOIN resources r ON r.id=s.resource_id "
                         "LEFT JOIN community_subscriptions c ON c.id=s.subscription_id WHERE s.id=?",
                         submission_id)
            if row:
                _notify_autopost_failure(row, "Внутренняя ошибка при отправке. Проверьте сообщество.")
    return len(claimed)


def _deliver_autopost_submission(submission_id: int) -> None:
    row = db.one(
        "SELECT s.*,r.chat_id,r.type resource_type,r.title community,r.status resource_status,"
        "r.is_demo,r.capabilities,r.missing_rights,u.telegram_id buyer_telegram_id,"
        "COALESCE(c.owner_user_id,r.user_id) owner_user_id,c.status subscription_status,c.starts_at,c.ends_at,"
        "COALESCE(c.workspace_id,r.workspace_id) workspace_id,p.limits_json "
        "FROM community_autopost_submissions s JOIN resources r ON r.id=s.resource_id "
        "JOIN users u ON u.id=s.buyer_user_id LEFT JOIN community_subscriptions c ON c.id=s.subscription_id "
        "LEFT JOIN community_plans p ON p.id=c.plan_id "
        "WHERE s.id=? AND s.status='publishing'", submission_id,
    )
    if row is None:
        return
    settings = _autopost_settings(row["resource_id"])
    if row["is_demo"] or row["resource_status"] != "active" or not settings["enabled"]:
        db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
               "Сообщество недоступно для публикации", db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "Сообщество недоступно для публикации.")
    if row["subscription_id"] is not None and (
            row["subscription_status"] not in ("active", "cancelled") or not row["ends_at"] or
            row["ends_at"] <= db.now_iso() or (row["starts_at"] and row["starts_at"] > db.now_iso())):
        db.run("UPDATE community_autopost_submissions SET status='cancelled',error=?,updated_at=? WHERE id=?",
               "Подписка закончилась до публикации", db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "Подписка закончилась до публикации; объявление отменено.")
    if row["subscription_id"] is not None and json.loads(row["limits_json"] or "{}").get("autopost", True) is False:
        db.run("UPDATE community_autopost_submissions SET status='cancelled',error=?,updated_at=? WHERE id=?",
               "Автопостинг больше не входит в тариф", db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "Автопостинг больше не входит в тариф сообщества.")
    if db.one("SELECT 1 FROM community_autopost_blocks WHERE resource_id=? AND telegram_user_id=?",
              row["resource_id"], row["buyer_telegram_id"]):
        db.run("UPDATE community_autopost_submissions SET status='cancelled',error=?,updated_at=? WHERE id=?",
               "Участник заблокирован владельцем", db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "Публикация отменена: владелец заблокировал участие.")
    client = telegram.client()
    if client is None or not telegram.is_live():
        return _retry_autopost_submission(row, "Нет связи с Telegram", 30, counted=False)
    if row["subscription_id"] is None:
        try:
            author = client.chat_member(row["chat_id"], row["buyer_telegram_id"])
        except telegram.TelegramNetworkError as exc:
            return _retry_autopost_submission(row, str(exc), 30, counted=False)
        except telegram.TelegramError as exc:
            if _telegram_user_not_found(exc):
                author = {"status": "left"}
            elif exc.code == 429:
                return _retry_autopost_submission(row, str(exc), (exc.retry_after or 5) + 1, counted=False)
            else:
                db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
                       "Не удалось проверить участие автора: " + str(exc), db.now_iso(), submission_id)
                return _notify_autopost_failure(row, "Не удалось проверить участие автора в сообществе.")
        if author.get("status") in ("left", "kicked") or (
                author.get("status") == "restricted" and not author.get("is_member")):
            db.run("UPDATE community_autopost_submissions SET status='cancelled',error=?,updated_at=? WHERE id=?",
                   "Автор больше не состоит в сообществе", db.now_iso(), submission_id)
            return _notify_autopost_failure(row, "Объявление отменено: автор больше не состоит в сообществе.")
    try:
        member = client.chat_member(row["chat_id"], telegram.state["bot_id"])
    except telegram.TelegramNetworkError as exc:
        return _retry_autopost_submission(row, str(exc), 30, counted=False)
    except telegram.TelegramError as exc:
        if exc.code == 429:
            return _retry_autopost_submission(row, str(exc), (exc.retry_after or 5) + 1, counted=False)
        db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
               "Не удалось проверить права бота: " + str(exc), db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "Не удалось проверить права бота в сообществе.")
    capabilities, missing = telegram.evaluate_rights(row["resource_type"], member)
    if "publish" not in capabilities:
        db.run("UPDATE resources SET status='missing_rights',capabilities=?,missing_rights=?,last_checked_at=? WHERE id=?",
               json.dumps(capabilities), json.dumps(missing), db.now_iso(), row["resource_id"])
        db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
               "У бота нет прав на публикацию", db.now_iso(), submission_id)
        return _notify_autopost_failure(row, "У бота нет прав на публикацию в сообществе.")

    media_ids = json.loads(row["media_ids_json"] or "[]")
    media_rows = []
    if media_ids:
        marks = ",".join("?" for _ in media_ids)
        found = db.q(f"SELECT id,filename,mime,data FROM media_uploads WHERE user_id=? AND id IN ({marks})",
                     row["buyer_user_id"], *media_ids)
        by_id = {media["id"]: media for media in found}
        if len(by_id) != len(media_ids):
            db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
                   "Одно или несколько изображений больше недоступны", db.now_iso(), submission_id)
            return _notify_autopost_failure(row, "Изображения объявления больше недоступны.")
        media_rows = [by_id[media_id] for media_id in media_ids]

    try:
        if len(media_rows) > 1:
            result = client.send_media_group(row["chat_id"], [
                {"data": media["data"], "filename": media["filename"], "mime": media["mime"],
                 "caption": row["text"] if index == 0 else "",
                 "parse_mode": "HTML" if index == 0 and row["text"] else None}
                for index, media in enumerate(media_rows)
            ])
            message_id = result[0]["message_id"]
        elif media_rows:
            media = media_rows[0]
            result = client.send_photo_file(row["chat_id"], media["data"], media["filename"],
                                            media["mime"], row["text"])
            message_id = result["message_id"]
        else:
            result = client.send_message(row["chat_id"], row["text"])
            message_id = result["message_id"]
    except telegram.TelegramError as exc:
        if exc.code == 429:
            return _retry_autopost_submission(row, str(exc), (exc.retry_after or 5) + 1, counted=False)
        if exc.permanent or row["attempts"] >= 3:
            db.run("UPDATE community_autopost_submissions SET status='failed',error=?,updated_at=? WHERE id=?",
                   str(exc)[:300], db.now_iso(), submission_id)
            if exc.code == 403:
                db.run("UPDATE resources SET status='missing_rights' WHERE id=?", row["resource_id"])
            return _notify_autopost_failure(row, "Telegram отклонил публикацию: " + (exc.description or str(exc)))
        return _retry_autopost_submission(row, str(exc), 30 * row["attempts"], counted=True)
    except telegram.TelegramNetworkError as exc:
        if exc.ambiguous:
            db.run("UPDATE community_autopost_submissions SET status='unknown',error=?,updated_at=? WHERE id=?",
                   "Нет ответа от Telegram; публикация могла состояться. " + str(exc)[:200], db.now_iso(), submission_id)
            db.event(row["buyer_user_id"], "community_ad_unknown",
                     f"Не удалось подтвердить публикацию в «{row['community']}». Проверьте сообщество.",
                     row["resource_id"])
            from .bot import notify_owner
            notify_owner(row["buyer_user_id"],
                         f"Не удалось подтвердить публикацию в «{row['community']}». Проверьте сообщество.", "tools")
            return
        return _retry_autopost_submission(row, str(exc), 30, counted=False)
    db.run("UPDATE community_autopost_submissions SET status='published',target_message_id=?,published_at=?,"
           "error=NULL,updated_at=? WHERE id=?",
           message_id, db.now_iso(), db.now_iso(), submission_id)
    db.event(row["buyer_user_id"], "community_ad_published",
             f"Объявление опубликовано в «{row['community']}»", row["resource_id"])
    from .bot import notify_owner
    notify_owner(row["buyer_user_id"], f"Объявление опубликовано в «{row['community']}».", "tools")
    db.event(row["owner_user_id"], "community_ad_published",
             f"Объявление участника опубликовано в «{row['community']}»", row["resource_id"])


def _retry_autopost_submission(row, error: str, delay: int, counted: bool) -> None:
    attempts = row["attempts"] if counted else max(0, row["attempts"] - 1)
    db.run("UPDATE community_autopost_submissions SET status='scheduled',attempts=?,next_attempt_at=?,error=?,"
           "updated_at=? WHERE id=?",
           attempts, db.iso(db.now() + timedelta(seconds=delay)), error[:300], db.now_iso(), row["id"])


def _notify_autopost_failure(row, text: str) -> None:
    db.event(row["buyer_user_id"], "community_ad_failed", text, row["resource_id"])
    from .bot import notify_owner
    notify_owner(row["buyer_user_id"], text, "tools")
    db.event(row["owner_user_id"], "community_ad_failed",
             f"Ошибка публикации объявления в «{row['community']}»: {text}", row["resource_id"])
    notify_owner(row["owner_user_id"], f"Ошибка публикации объявления в «{row['community']}»: {text}", "tools")


def _telegram_user_not_found(exc) -> bool:
    return exc.code == 400 and "user not found" in exc.description.lower()


@route("GET", "/api/v1/communities/<int:id>/plans")
def list_community_plans(req):
    resource = db.one("SELECT id,title FROM resources WHERE id=? AND is_demo=0 AND status='active'", req.params["id"])
    if resource is None:
        raise ApiError(404, "not_found", "Сообщество не найдено")
    rows = db.q("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                "WHERE p.resource_id=? AND p.active=1 ORDER BY p.amount_minor", resource["id"])
    return {"items": [_plan_dict(row) for row in rows]}


@route("POST", "/api/v1/communities/<int:id>/plans")
def create_community_plan(req):
    resource = _resource_for_owner(req, req.params["id"])
    resource = _refresh_community_resource(resource)
    _ensure_paid_access_supported(resource)
    merchant = db.one("SELECT status,payout_phone,payout_bank FROM community_merchants WHERE resource_id=? AND owner_user_id=?",
                      resource["id"], req.user["id"])
    if (merchant is None or merchant["status"] != "active" or
            not merchant["payout_phone"] or not merchant["payout_bank"]):
        raise ApiError(409, "payout_details_missing", "Сначала укажите телефон и банк для ручных выплат")
    name = str(req.body.get("name") or "").strip()[:80]
    description = str(req.body.get("description") or "").strip()[:500]
    try:
        amount_minor = int(req.body.get("amount_minor"))
        duration_days = int(req.body.get("duration_days"))
        max_members = int(req.body["max_members"]) if req.body.get("max_members") not in (None, "") else None
    except (ValueError, TypeError):
        raise ApiError(422, "validation", "Цена, срок и лимит участников должны быть целыми числами")
    if not name or amount_minor < 100 or amount_minor > 100_000_000 or not 1 <= duration_days <= 3650:
        raise ApiError(422, "validation", "Цена должна быть от 1 до 1 000 000 ₽, срок — от 1 до 3650 дней")
    if max_members is not None and not 1 <= max_members <= 1_000_000:
        raise ApiError(422, "validation", "Лимит участников должен быть от 1 до 1 000 000")
    permissions = _validate_plan_permissions(req.body.get("permissions", {}))
    if _has_member_permissions(permissions) and resource["type"] != "supergroup":
        raise ApiError(409, "permissions_require_supergroup",
                       "Индивидуальные права тарифа поддерживаются только в супергруппах Telegram")
    plan_id = db.insert("community_plans", workspace_id=resource["workspace_id"], resource_id=resource["id"],
                        owner_user_id=req.user["id"], name=name,
                        description=description, amount_minor=amount_minor, duration_days=duration_days,
                        max_members=max_members, limits_json=json.dumps(permissions),
                        created_at=db.now_iso(), updated_at=db.now_iso())
    db.audit(req.actor_user["id"], "community_plan_created", method="POST", status=201,
             resource_id=resource["id"], entity_id=plan_id, request_id=req.request_id, workspace_id=req.workspace_id)
    row = db.one("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id WHERE p.id=?", plan_id)
    return 201, _plan_dict(row)


@route("PUT", "/api/v1/community-plans/<int:id>")
def update_community_plan(req):
    row = db.one("SELECT * FROM community_plans WHERE id=? AND owner_user_id=?", req.params["id"], req.user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Тариф не найден")
    resource = _resource_for_owner(req, row["resource_id"])
    name = str(req.body.get("name", row["name"])).strip()[:80]
    description = str(req.body.get("description", row["description"])).strip()[:500]
    try:
        amount = int(req.body.get("amount_minor", row["amount_minor"]))
        duration = int(req.body.get("duration_days", row["duration_days"]))
        max_members = int(req.body["max_members"]) if req.body.get("max_members") not in (None, "") else row["max_members"]
    except (ValueError, TypeError):
        raise ApiError(422, "validation", "Цена, срок и лимит участников должны быть целыми числами")
    active = int(bool(req.body.get("active", row["active"])))
    if not name or not 100 <= amount <= 100_000_000 or not 1 <= duration <= 3650:
        raise ApiError(422, "validation", "Неверная цена или срок тарифа")
    if max_members is not None and not 1 <= max_members <= 1_000_000:
        raise ApiError(422, "validation", "Лимит участников должен быть от 1 до 1 000 000")
    permissions = (json.dumps(_validate_plan_permissions(req.body["permissions"]))
                   if "permissions" in req.body else row["limits_json"])
    if ("permissions" in req.body and
            _has_member_permissions(json.loads(permissions)) and resource["type"] != "supergroup"):
        raise ApiError(409, "permissions_require_supergroup",
                       "Индивидуальные права тарифа поддерживаются только в супергруппах Telegram")
    db.run("UPDATE community_plans SET name=?,description=?,amount_minor=?,duration_days=?,max_members=?,limits_json=?,active=?,updated_at=? WHERE id=?",
           name, description, amount, duration, max_members, permissions, active, db.now_iso(), row["id"])
    if "permissions" in req.body:
        for sub in db.q("SELECT id FROM community_subscriptions WHERE plan_id=? AND status='active' AND ends_at>?",
                        row["id"], db.now_iso()):
            _queue_member_permission(sub["id"])
    db.audit(req.actor_user["id"], "community_plan_updated", method="PUT", status=200,
              resource_id=row["resource_id"], entity_id=row["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"ok": True}


@route("POST", "/api/v1/community-plans/<int:id>/checkout")
def create_checkout(req):
    _feature_ready()
    buyer_id = req.actor_user["id"]
    plan = db.one("SELECT p.*,r.title community,r.username,r.type,r.chat_id,r.status resource_status,"
                  "m.status merchant_status,m.payout_phone,m.payout_bank "
                  "FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                  "JOIN community_merchants m ON m.resource_id=p.resource_id "
                  "WHERE p.id=? AND p.active=1", req.params["id"])
    if plan is None or plan["merchant_status"] != "active":
        raise ApiError(404, "plan_unavailable", "Тариф недоступен")
    if not plan["payout_phone"] or not plan["payout_bank"]:
        raise ApiError(409, "payout_details_missing", "Владелец ещё не указал реквизиты для ручных выплат")
    plan = _refresh_community_resource(plan)
    if plan["resource_status"] != "active":
        raise ApiError(409, "community_unavailable", "Сообщество неактивно")
    _ensure_paid_access_supported(plan)
    if plan["owner_user_id"] == buyer_id:
        raise ApiError(409, "owner_cannot_buy", "Владелец не может купить собственный тариф")
    active = db.one("SELECT id FROM community_subscriptions WHERE buyer_user_id=? AND resource_id=? "
                    "AND status='active' AND ends_at>?", buyer_id, plan["resource_id"], db.now_iso())
    if active:
        raise ApiError(409, "already_subscribed", "У вас уже есть активный доступ к этому сообществу")
    if plan["max_members"] is not None:
        pending_cutoff = db.iso(db.now() - timedelta(minutes=20))
        count = db.one("SELECT COUNT(*) n FROM community_subscriptions WHERE plan_id=? AND "
                       "(status='active' AND ends_at>? OR (status='pending' AND created_at>?))",
                       plan["id"], db.now_iso(), pending_cutoff)["n"]
        if count >= plan["max_members"]:
            raise ApiError(409, "plan_full", "В этом тарифе больше нет мест")
    method = req.body.get("payment_method")
    if method not in (None, "yookassa"):
        raise ApiError(422, "payment_method_unavailable", "Сейчас доступна только оплата YooKassa в RUB")
    auto_renew = bool(req.body.get("auto_renew", False))
    sub_id = db.insert("community_subscriptions", workspace_id=plan["workspace_id"],
                       resource_id=plan["resource_id"], plan_id=plan["id"],
                       buyer_user_id=buyer_id, owner_user_id=plan["owner_user_id"], status="pending",
                       auto_renew=int(auto_renew), created_at=db.now_iso(), updated_at=db.now_iso())
    idempotency = "mp-community-" + secrets.token_urlsafe(24)
    fee = payments.commission(plan["amount_minor"])
    payment_id = db.insert("community_payments", workspace_id=plan["workspace_id"],
                           subscription_id=sub_id, plan_id=plan["id"],
                           resource_id=plan["resource_id"], buyer_user_id=buyer_id, owner_user_id=plan["owner_user_id"],
                           provider="yookassa", idempotency_key=idempotency, amount_minor=plan["amount_minor"],
                           commission_minor=fee, owner_amount_minor=plan["amount_minor"] - fee,
                           status="pending", is_recurring=0, created_at=db.now_iso())
    return_url = f"{cfg.PUBLIC_URL}/app/?payment={payment_id}"
    try:
        result = payments.create_payment(amount_minor=plan["amount_minor"], payment_id=payment_id,
                                          subscription_id=sub_id, return_url=return_url,
                                          save_payment_method=auto_renew, idempotency_key=idempotency)
    except payments.PaymentProviderError as exc:
        if exc.ambiguous:
            db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment_id)
            return 202, {"payment": _payment_dict(db.one("SELECT * FROM community_payments WHERE id=?", payment_id)),
                         "message": "Проверяем статус платежа. Повторное списание не выполняется."}
        db.run("UPDATE community_payments SET status='canceled' WHERE id=?", payment_id)
        db.run("UPDATE community_subscriptions SET status='payment_failed',auto_renew=0,updated_at=? WHERE id=?",
               db.now_iso(), sub_id)
        raise ApiError(502, "payment_rejected", str(exc))
    provider_id = result.get("id")
    confirmation_url = (result.get("confirmation") or {}).get("confirmation_url")
    if not provider_id:
        db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment_id)
        raise ApiError(502, "payment_provider_response", "YooKassa не вернула идентификатор платежа")
    db.run("UPDATE community_payments SET provider_payment_id=?,confirmation_url=?,status=? WHERE id=?",
           provider_id, confirmation_url, result.get("status", "pending"), payment_id)
    if result.get("status") == "succeeded":
        _settle_payment(result)
    db.audit(buyer_id, "community_checkout_created", method="POST", status=201,
             resource_id=plan["resource_id"], entity_id=payment_id, request_id=req.request_id, workspace_id=req.workspace_id)
    local = db.one("SELECT * FROM community_payments WHERE id=?", payment_id)
    return 201, {"payment": _payment_dict(local), "auto_renew_requested": auto_renew}


@route("GET", "/api/v1/marketplace/plans")
def marketplace_plans(req):
    _activate_pending_merchants()
    rows = db.q("SELECT p.*,r.title community FROM community_plans p JOIN resources r ON r.id=p.resource_id "
                "JOIN community_merchants m ON m.resource_id=p.resource_id "
                "WHERE p.active=1 AND m.status='active' AND r.status='active' AND r.is_demo=0 "
                "ORDER BY r.title,p.amount_minor")
    if not cfg.COMMUNITY_PAYMENTS_ENABLED:
        checkout_reason = "payments_disabled"
    elif not payments.configured():
        checkout_reason = "billing_unavailable"
    elif not cfg.PUBLIC_URL.startswith("https://"):
        checkout_reason = "https_required"
    else:
        checkout_reason = "ready"
    return {"items": [_plan_dict(row) for row in rows],
            "checkout_enabled": checkout_reason == "ready",
            "checkout_reason": checkout_reason}


@route("GET", "/api/v1/community-subscriptions")
def buyer_subscriptions(req):
    rows = db.q("SELECT s.*,r.title community,p.name plan_name,p.amount_minor,p.currency "
                "FROM community_subscriptions s JOIN resources r ON r.id=s.resource_id "
                "JOIN community_plans p ON p.id=s.plan_id WHERE s.buyer_user_id=? ORDER BY s.id DESC", req.actor_user["id"])
    return {"items": [{"id": row["id"], "community": row["community"], "plan": row["plan_name"],
                        "price": payments.money(row["amount_minor"]), "currency": row["currency"],
                        "status": row["status"], "starts_at": row["starts_at"], "ends_at": row["ends_at"],
                        "auto_renew": bool(row["auto_renew"])} for row in rows]}


@route("GET", "/api/v1/community-payments/<int:id>")
def community_payment_status(req):
    row = db.one("SELECT * FROM community_payments WHERE id=? AND (buyer_user_id=? OR owner_user_id=?)",
                 req.params["id"], req.actor_user["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Платёж не найден")
    if row["status"] in ("pending", "unknown"):
        row = _reconcile_payment(row)
    return _payment_dict(row)


@route("POST", "/api/v1/community-subscriptions/<int:id>/cancel")
def cancel_community_subscription(req):
    row = db.one("SELECT * FROM community_subscriptions WHERE id=? AND buyer_user_id=?",
                 req.params["id"], req.actor_user["id"])
    if row is None:
        raise ApiError(404, "not_found", "Подписка не найдена")
    db.run("UPDATE community_subscriptions SET auto_renew=0,status=CASE WHEN status='active' THEN 'cancelled' ELSE status END,updated_at=? WHERE id=?",
           db.now_iso(), row["id"])
    db.audit(req.actor_user["id"], "community_subscription_cancelled", method="POST", status=200,
             resource_id=row["resource_id"], entity_id=row["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"ok": True, "access_until": row["ends_at"], "auto_renew": False}


@route("POST", "/api/v1/community-subscriptions/<int:id>/refunds")
def request_community_refund(req):
    subscription = db.one("SELECT * FROM community_subscriptions WHERE id=? AND buyer_user_id=?",
                          req.params["id"], req.actor_user["id"])
    if subscription is None:
        raise ApiError(404, "not_found", "Подписка не найдена")
    payment = db.one("SELECT * FROM community_payments WHERE subscription_id=? AND status='succeeded' ORDER BY id DESC LIMIT 1",
                     subscription["id"])
    if payment is None:
        raise ApiError(409, "no_paid_payment", "Нет платежа, доступного для возврата")
    existing = db.one("SELECT id FROM community_refunds WHERE payment_id=? AND status IN ('requested','approved','pending','succeeded')",
                       payment["id"])
    if existing:
        raise ApiError(409, "refund_exists", "Возврат по этому платежу уже рассматривается")
    refund_id = db.insert("community_refunds", workspace_id=payment["workspace_id"],
                          owner_user_id=payment["owner_user_id"], payment_id=payment["id"],
                          requested_by=req.actor_user["id"],
                          amount_minor=payment["amount_minor"], idempotency_key="mp-refund-" + secrets.token_urlsafe(24),
                          status="requested", reason=str(req.body.get("reason") or "")[:300],
                          created_at=db.now_iso(), updated_at=db.now_iso())
    db.audit(req.actor_user["id"], "community_refund_requested", method="POST", status=201,
             resource_id=subscription["resource_id"], entity_id=refund_id,
             request_id=req.request_id, workspace_id=subscription["workspace_id"])
    db.event(subscription["owner_user_id"], "community_refund_requested", "Покупатель запросил возврат",
             subscription["resource_id"])
    return 201, {"id": refund_id, "status": "requested"}


@route("GET", "/api/v1/owner/community-billing")
def owner_billing(req):
    _activate_pending_merchants()
    rows = db.q("SELECT l.currency,l.kind,SUM(l.amount_minor) amount_minor,COUNT(*) n "
                "FROM community_ledger l WHERE l.owner_user_id=? GROUP BY l.currency,l.kind", req.user["id"])
    plans = db.q("SELECT p.id,p.resource_id,p.name,p.amount_minor,p.duration_days,p.active,p.limits_json,r.title community "
                 "FROM community_plans p JOIN resources r ON r.id=p.resource_id WHERE p.owner_user_id=? ORDER BY p.id DESC",
                 req.user["id"])
    refunds = db.q("SELECT f.id,f.status,f.amount_minor,f.reason,r.title community,p.name plan "
                   "FROM community_refunds f JOIN community_payments x ON x.id=f.payment_id "
                   "JOIN community_plans p ON p.id=x.plan_id JOIN resources r ON r.id=x.resource_id "
                   "WHERE x.owner_user_id=? ORDER BY f.id DESC", req.user["id"])
    subscriptions = db.q("SELECT s.id,s.status,s.starts_at,s.ends_at,s.auto_renew,u.first_name,u.username,"
                         "r.title community,p.name plan FROM community_subscriptions s "
                         "JOIN users u ON u.id=s.buyer_user_id JOIN resources r ON r.id=s.resource_id "
                         "JOIN community_plans p ON p.id=s.plan_id WHERE s.owner_user_id=? ORDER BY s.id DESC",
                         req.user["id"])
    payouts = db.q("SELECT status,COALESCE(SUM(amount_minor),0) amount_minor FROM community_manual_payouts "
                   "WHERE owner_user_id=? GROUP BY status", req.user["id"])
    plan_items = []
    for row in plans:
        item = dict(row)
        item["permissions"] = json.loads(item.pop("limits_json") or "{}")
        plan_items.append(item)
    payout_totals = {row["status"]: row["amount_minor"] for row in payouts}
    return {"ledger": [dict(row) for row in rows], "plans": plan_items,
            "refunds": [dict(row) for row in refunds], "subscriptions": [dict(row) for row in subscriptions],
            "payouts": {"pending_minor": payout_totals.get("pending", 0), "paid_minor": payout_totals.get("paid", 0),
                        "recovery_minor": payout_totals.get("recovery_required", 0)},
            "is_platform_admin": req.actor_user["telegram_id"] in cfg.PLATFORM_ADMIN_TELEGRAM_IDS}


@route("GET", "/api/v1/platform/payouts")
def platform_manual_payouts(req):
    _require_platform_admin(req)
    rows = db.q(
        "SELECT x.id payout_id,x.payment_id,x.owner_user_id,x.amount_minor,x.status,x.created_at,"
        "x.transfer_reference,u.first_name owner_name,u.username owner_username,"
        "x.payout_phone,x.payout_bank,r.title community,p.name plan,"
        "pay.amount_minor sale_amount,pay.commission_minor "
        "FROM community_manual_payouts x "
        "JOIN users u ON u.id=x.owner_user_id "
        "JOIN community_payments pay ON pay.id=x.payment_id "
        "JOIN resources r ON r.id=pay.resource_id "
        "JOIN community_plans p ON p.id=pay.plan_id "
        "WHERE x.status IN ('pending','recovery_required') ORDER BY x.id"
    )
    return {"items": [dict(row) for row in rows]}


@route("POST", "/api/v1/platform/payouts/<int:id>/paid")
def mark_manual_payout_paid(req):
    _require_platform_admin(req)
    reference = str(req.body.get("transfer_reference") or "").strip()[:120]
    with db.tx():
        payout = db.one("SELECT * FROM community_manual_payouts WHERE id=?", req.params["id"])
        if payout is None or payout["status"] != "pending":
            raise ApiError(409, "payout_not_pending", "Ручной перевод больше не ожидает выплаты")
        if not payout["payout_phone"] or not payout["payout_bank"]:
            raise ApiError(409, "payout_details_missing", "Владелец ещё не указал реквизиты для перевода")
        db.run("UPDATE community_manual_payouts SET status='paid',paid_at=?,paid_by=?,"
               "transfer_reference=?,updated_at=? WHERE id=? AND status='pending'",
               db.now_iso(), req.actor_user["id"], reference, db.now_iso(), payout["id"])
    db.audit(req.actor_user["id"], "community_manual_payout_paid", method="POST", status=200,
             entity_id=payout["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"id": payout["id"], "status": "paid"}


@route("POST", "/api/v1/community-refunds/<int:id>/approve")
def approve_community_refund(req):
    refund = db.one("SELECT f.*,p.provider_payment_id,p.id payment_local_id,p.owner_user_id,p.resource_id "
                    "FROM community_refunds f JOIN community_payments p ON p.id=f.payment_id WHERE f.id=? AND p.owner_user_id=?",
                    req.params["id"], req.user["id"])
    if refund is None or refund["status"] != "requested":
        raise ApiError(404, "not_found", "Запрос возврата не найден")
    _feature_ready()
    try:
        provider_refund = payments.create_refund(provider_payment_id=refund["provider_payment_id"],
                                                  amount_minor=refund["amount_minor"], payment_id=refund["payment_local_id"],
                                                  idempotency_key=refund["idempotency_key"])
    except payments.PaymentProviderError as exc:
        raise ApiError(503, "refund_pending", str(exc))
    db.run("UPDATE community_refunds SET approved_by=?,provider_refund_id=?,status=?,updated_at=? WHERE id=?",
            req.actor_user["id"], provider_refund.get("id"), "pending", db.now_iso(), refund["id"])
    db.run("UPDATE community_payments SET status='refund_pending' WHERE id=?", refund["payment_local_id"])
    if provider_refund.get("status") == "succeeded":
        _complete_refund(refund["id"], provider_refund)
    db.audit(req.actor_user["id"], "community_refund_approved", method="POST", status=200,
             resource_id=refund["resource_id"], entity_id=refund["id"],
             request_id=req.request_id, workspace_id=refund["workspace_id"])
    return {"id": refund["id"], "status": db.one("SELECT status FROM community_refunds WHERE id=?", refund["id"])["status"]}


@route("POST", "/api/v1/community-refunds/<int:id>/reject")
def reject_community_refund(req):
    refund = db.one("SELECT f.id,f.status,p.owner_user_id FROM community_refunds f "
                    "JOIN community_payments p ON p.id=f.payment_id WHERE f.id=? AND p.owner_user_id=?",
                    req.params["id"], req.user["id"])
    if refund is None or refund["status"] != "requested":
        raise ApiError(404, "not_found", "Запрос возврата не найден")
    db.run("UPDATE community_refunds SET approved_by=?,status='rejected',updated_at=? WHERE id=?",
           req.actor_user["id"], db.now_iso(), refund["id"])
    db.audit(req.actor_user["id"], "community_refund_rejected", method="POST", status=200,
             entity_id=refund["id"], request_id=req.request_id, workspace_id=req.workspace_id)
    return {"id": refund["id"], "status": "rejected"}


def _complete_refund(refund_id: int, provider_refund: dict) -> None:
    refund = db.one("SELECT f.*,p.owner_user_id,p.resource_id,p.id payment_local_id,p.subscription_id "
                    "FROM community_refunds f JOIN community_payments p ON p.id=f.payment_id WHERE f.id=?", refund_id)
    if refund is None or refund["status"] == "succeeded":
        return
    if provider_refund.get("status") != "succeeded":
        return
    payment = db.one("SELECT provider_payment_id FROM community_payments WHERE id=?", refund["payment_local_id"])
    provider_amount = provider_refund.get("amount") or {}
    if (provider_refund.get("payment_id") != payment["provider_payment_id"] or
            provider_amount.get("currency") != "RUB" or
            provider_amount.get("value") != payments.money(refund["amount_minor"])):
        raise ApiError(400, "refund_mismatch", "Возврат не совпадает с исходным платежом")
    with db.tx():
        db.run("UPDATE community_refunds SET status='succeeded',provider_refund_id=?,updated_at=? WHERE id=?",
               provider_refund.get("id"), db.now_iso(), refund_id)
        db.run("UPDATE community_payments SET status='refunded' WHERE id=?", refund["payment_local_id"])
        db.run("UPDATE community_subscriptions SET status='refunded',auto_renew=0,payment_method_id=NULL,updated_at=? WHERE id=?",
               db.now_iso(), refund["subscription_id"])
        db.run("UPDATE community_manual_payouts SET status=CASE status WHEN 'pending' THEN 'cancelled' "
               "WHEN 'paid' THEN 'recovery_required' ELSE status END,updated_at=? WHERE payment_id=?",
               db.now_iso(), refund["payment_local_id"])
        db.insert("community_ledger", workspace_id=refund["workspace_id"],
              owner_user_id=refund["owner_user_id"], resource_id=refund["resource_id"],
                  refund_id=refund_id, currency="RUB", kind="refund", amount_minor=-refund["amount_minor"],
                  created_at=db.now_iso())
        db.event(refund["requested_by"], "community_refund_succeeded", "Возврат подтверждён, привилегии тарифа отозваны",
             refund["resource_id"])
        db.event(refund["owner_user_id"], "community_refund_succeeded", "Возврат выполнен YooKassa",
             refund["resource_id"])
        _queue_access(refund["subscription_id"], "revoke")


def _handle_payment_canceled(object_id: str, event_type: str) -> None:
    row = db.one("SELECT * FROM community_payments WHERE provider_payment_id=?", object_id)
    if row is None:
        return
    db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
           "yookassa", "payment:" + object_id + ":canceled", event_type, db.now_iso())
    db.run("UPDATE community_payments SET status='canceled' WHERE id=? AND status!='succeeded'", row["id"])
    db.run("UPDATE community_subscriptions SET status=CASE WHEN ends_at IS NULL OR ends_at<=? "
           "THEN 'payment_failed' ELSE status END,auto_renew=0,payment_method_id=NULL,updated_at=? "
           "WHERE id=? AND status IN ('pending','active')", db.now_iso(), db.now_iso(), row["subscription_id"])


@route("POST", "/api/v1/webhooks/yookassa", public=True)
def yookassa_webhook(req):
    event_type = str(req.body.get("event") or "")
    obj = req.body.get("object") or {}
    object_id = str(obj.get("id") or "")
    if event_type == "payment.succeeded" and object_id:
        try:
            provider_payment = payments.get_payment(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        if (provider_payment.get("metadata") or {}).get("kind") == "platform":
            from . import billing
            billing.settle_platform_payment(provider_payment)
        elif provider_payment.get("status") == "succeeded":
            _settle_payment(provider_payment, "payment:" + object_id + ":succeeded")
    elif event_type == "payment.canceled" and object_id:
        try:
            provider_payment = payments.get_payment(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        if (provider_payment.get("metadata") or {}).get("kind") == "platform":
            from . import billing
            billing.settle_platform_payment(provider_payment)
        elif provider_payment.get("status") == "canceled":
            _handle_payment_canceled(object_id, event_type)
    elif event_type == "refund.succeeded" and object_id:
        try:
            provider_refund = payments.get_refund(object_id)
        except payments.PaymentProviderError as exc:
            raise ApiError(503, "provider_unavailable", str(exc))
        local_refund = db.one("SELECT id FROM community_refunds WHERE provider_refund_id=?", object_id)
        if local_refund:
            _complete_refund(local_refund["id"], provider_refund)
            db.run("INSERT OR IGNORE INTO billing_webhook_events(provider,event_key,event_type,processed_at) VALUES(?,?,?,?)",
                   "yookassa", "refund:" + object_id + ":succeeded", event_type, db.now_iso())
    return {"ok": True}


def expire_community_subscriptions() -> int:
    rows = db.q("SELECT id,resource_id FROM community_subscriptions WHERE status IN ('active','cancelled','payment_failed') "
                "AND ends_at IS NOT NULL AND ends_at<=? AND NOT EXISTS "
                "(SELECT 1 FROM community_payments p WHERE p.subscription_id=community_subscriptions.id "
                "AND p.is_recurring=1 AND p.status IN ('pending','unknown'))", db.now_iso())
    for row in rows:
        db.run("UPDATE community_subscriptions SET status='expired',auto_renew=0,payment_method_id=NULL,updated_at=? "
               "WHERE id=? AND status IN ('active','cancelled','payment_failed')", db.now_iso(), row["id"])
        _queue_access(row["id"], "revoke")
        db.run("INSERT OR IGNORE INTO community_subscription_notices(workspace_id,subscription_id,notice_type,ends_at,created_at) "
               "SELECT workspace_id,id,'expired',COALESCE(ends_at,''),? FROM community_subscriptions WHERE id=?",
               db.now_iso(), row["id"])
    return len(rows)


def renew_due_subscriptions() -> int:
    if not cfg.COMMUNITY_PAYMENTS_ENABLED or not payments.configured():
        return 0
    rows = db.q("SELECT s.*,p.amount_minor,p.owner_user_id,p.id plan_id,p.duration_days "
                "FROM community_subscriptions s JOIN community_plans p ON p.id=s.plan_id "
                "JOIN community_merchants m ON m.resource_id=s.resource_id AND m.status='active' "
                "WHERE s.status='active' AND s.auto_renew=1 AND s.payment_method_id IS NOT NULL "
                "AND s.ends_at IS NOT NULL AND s.ends_at<=? ORDER BY s.ends_at LIMIT 20", db.now_iso())
    attempted = 0
    for subscription in rows:
        cycle = hashlib.sha256(subscription["ends_at"].encode()).hexdigest()[:16]
        key = f"mp-renew-{subscription['id']}-{cycle}"
        payment = db.one("SELECT * FROM community_payments WHERE idempotency_key=?", key)
        if payment and payment["provider_payment_id"]:
            try:
                _reconcile_payment(payment)
            except ApiError:
                pass
            continue
        if payment is None:
            fee = payments.commission(subscription["amount_minor"])
            local_id = db.insert("community_payments", workspace_id=subscription["workspace_id"],
                                 subscription_id=subscription["id"], plan_id=subscription["plan_id"],
                                 resource_id=subscription["resource_id"], buyer_user_id=subscription["buyer_user_id"],
                                 owner_user_id=subscription["owner_user_id"], provider="yookassa", idempotency_key=key,
                                 amount_minor=subscription["amount_minor"], commission_minor=fee,
                                 owner_amount_minor=subscription["amount_minor"] - fee, status="pending",
                                 is_recurring=1, created_at=db.now_iso())
            payment = db.one("SELECT * FROM community_payments WHERE id=?", local_id)
        try:
            result = payments.create_payment(amount_minor=payment["amount_minor"], payment_id=payment["id"],
                subscription_id=subscription["id"], return_url=f"{cfg.PUBLIC_URL}/app/?payment={payment['id']}",
                save_payment_method=False, payment_method_id=subscription["payment_method_id"], idempotency_key=key)
        except payments.PaymentProviderError:
            db.run("UPDATE community_payments SET status='unknown' WHERE id=?", payment["id"])
            continue
        db.run("UPDATE community_payments SET provider_payment_id=?,status=? WHERE id=?",
               result.get("id"), result.get("status", "pending"), payment["id"])
        if result.get("status") == "succeeded":
            _settle_payment(result)
        elif result.get("status") == "canceled":
            db.run("UPDATE community_subscriptions SET auto_renew=0,updated_at=? WHERE id=?",
                   db.now_iso(), subscription["id"])
            db.event(subscription["buyer_user_id"], "community_renewal_failed",
                     "Автопродление не прошло. Доступ сохранится до даты окончания.", subscription["resource_id"])
        attempted += 1
    return attempted


def send_expiry_notices() -> int:
    if not telegram.is_live():
        return 0
    rows = db.q("SELECT s.id,s.buyer_user_id,s.resource_id,s.ends_at,u.telegram_id,r.title "
                "FROM community_subscriptions s JOIN users u ON u.id=s.buyer_user_id "
                "JOIN resources r ON r.id=s.resource_id WHERE s.status='active' "
                "AND s.ends_at>? AND s.ends_at<=?", db.now_iso(), db.iso(db.now() + timedelta(days=3)))
    sent = 0
    client = telegram.client()
    for row in rows:
        cur = db.run("INSERT OR IGNORE INTO community_subscription_notices(workspace_id,subscription_id,notice_type,ends_at,created_at) "
                 "SELECT workspace_id,id,'expiring',?,? FROM community_subscriptions WHERE id=?",
                 row["ends_at"], db.now_iso(), row["id"])
        if cur.rowcount:
            try:
                sub = db.one("SELECT auto_renew FROM community_subscriptions WHERE id=?", row["id"])
                note = ("В этот день запланировано автопродление. Отключите его в кабинете, если оно не нужно."
                        if sub["auto_renew"] else "Продлите тариф, чтобы сохранить его привилегии.")
                client.send_message(row["telegram_id"],
                    f"Срок привилегий тарифа в «{row['title']}» закончится {row['ends_at']}. "
                    f"Группа останется доступна. {note}", parse_mode=None)
                sent += 1
            except Exception:
                db.run("DELETE FROM community_subscription_notices WHERE subscription_id=? AND notice_type='expiring' AND ends_at=?",
                       row["id"], row["ends_at"])
    return sent


def maintenance_tick() -> None:
    if not _maintenance_lock.acquire(blocking=False):
        return
    try:
        expire_community_subscriptions()
        renew_due_subscriptions()
        send_expiry_notices()
        process_access_jobs()
        process_member_permission_jobs()
        recover_stuck_autopost_submissions()
        process_autopost_submissions(limit=5)
    finally:
        _maintenance_lock.release()


def process_access_jobs(limit: int = 20) -> int:
    client = telegram.client()
    if client is None or not telegram.is_live():
        return 0
    rows = db.q("SELECT j.*,s.resource_id,s.buyer_user_id,s.ends_at,u.telegram_id,r.title,r.chat_id,r.username "
                "FROM community_access_jobs j JOIN community_subscriptions s ON s.id=j.subscription_id "
                "JOIN users u ON u.id=s.buyer_user_id JOIN resources r ON r.id=s.resource_id "
                "WHERE j.status IN ('pending','failed','processing') ORDER BY j.id LIMIT ?", limit)
    completed = 0
    for row in rows:
        db.run("UPDATE community_access_jobs SET status='processing',attempts=attempts+1,updated_at=? WHERE id=?",
               db.now_iso(), row["id"])
        try:
            if row["action"] == "invite":
                if row["username"]:
                    link = "https://t.me/" + row["username"].lstrip("@")
                    client.send_message(row["telegram_id"],
                        f"Оплата подтверждена. Группа «{row['title']}» открыта для всех: {link}. "
                        "Привилегии вашего тарифа действуют после вступления.")
                else:
                    link = client.create_chat_invite_link(
                        row["chat_id"], int(db.now().timestamp()) + 3600, member_limit=1)
                    client.send_message(row["telegram_id"],
                        f"Оплата подтверждена. Ссылка для вступления в «{row['title']}»: {link}")
            else:
                if row["username"]:
                    member = client.chat_member(row["chat_id"], row["telegram_id"])
                    if member.get("status") in ("member", "restricted"):
                        chat = client.get_chat(row["chat_id"])
                        defaults = chat.get("permissions")
                        if not isinstance(defaults, dict):
                            raise RuntimeError("Telegram did not return the group's default permissions")
                        permissions = {key: bool(defaults.get(key, False))
                                       for key in telegram.CHAT_PERMISSION_FIELDS}
                        client.restrict_chat_member(row["chat_id"], row["telegram_id"], permissions)
                    client.send_message(row["telegram_id"],
                        f"Срок платных привилегий в «{row['title']}» завершён. "
                        "Группа остаётся открытой для вас и всех остальных участников.")
                else:
                    client.ban_chat_member(row["chat_id"], row["telegram_id"])
                    client.unban_chat_member(row["chat_id"], row["telegram_id"])
                    client.send_message(row["telegram_id"], f"Срок доступа к «{row['title']}» завершён.")
            db.run("UPDATE community_access_jobs SET status='done',last_error='',updated_at=? WHERE id=?", db.now_iso(), row["id"])
            completed += 1
        except Exception as exc:
            db.run("UPDATE community_access_jobs SET status='failed',last_error=?,updated_at=? WHERE id=?",
                   f"{type(exc).__name__}: {exc}"[:300], db.now_iso(), row["id"])
    return completed
