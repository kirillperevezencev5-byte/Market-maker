/* MarketPilot shell: boot, login, routing, navigation. */
(function () {
  'use strict';
  const MP = window.MP;
  const { h, $, clear, t, api, toast, fail, busy } = MP;
  const state = MP.state;
  const appEl = $('#app');
  const NAV = [['dashboard', 'Главная'], ['posts', 'Публикации'], ['resources', 'Сообщества'], ['tools', 'Инструменты'], ['settings', 'Профиль']];

  // ---------------------------------------------------------------- theme
  MP.setTheme = function (v) {
    try { localStorage.setItem('mp_theme', v); } catch (e) { /* private mode */ }
    applyTheme();
  };
  function applyTheme() {
    let v = 'auto';
    try { v = localStorage.getItem('mp_theme') || 'auto'; } catch (e) { /* ignore */ }
    if (v === 'auto') document.documentElement.removeAttribute('data-theme');
    else document.documentElement.setAttribute('data-theme', v);
  }
  applyTheme();

  // ---------------------------------------------------------------- session
  MP.onUnauthorized = function () {
    state.user = null;
    state.workspaceId = null; state.workspaces = [];
    showLogin();
  };
  MP.logout = async function () {
    try { await api('POST', '/auth/logout'); } catch (e) { /* ignore */ }
    state.user = null;
    state.workspaceId = null; state.workspaces = [];
    showLogin();
  };
  async function refreshStatus() {
    try { state.status = await api('GET', '/status'); } catch (e) { state.status = { demo_mode: true, telegram: { configured: false, connected: false } }; }
    return state.status;
  }
  function adopt(user) {
    state.user = user; state.lang = user.language; state.tz = user.timezone;
    document.documentElement.lang = user.language;
  }
  async function loadWorkspaces() {
    const previousId = state.workspaceId;
    state.workspaceId = null;
    try {
      const items = (await api('GET', '/workspaces')).items;
      const key = 'mp_workspace_' + state.user.id;
      let saved = null;
      try { saved = localStorage.getItem(key); } catch (e) { /* storage may be blocked */ }
      const selected = items.find((item) => String(item.id) === saved) ||
        items.find((item) => item.owner_user_id === state.user.id) || items[0];
      state.workspaces = items;
      state.workspaceId = selected ? selected.id : null;
      if (selected) { try { localStorage.setItem(key, String(selected.id)); } catch (e) { /* storage may be blocked */ } }
    } catch (e) {
      state.workspaceId = previousId;
      throw e;
    }
  }
  MP.loadWorkspaces = loadWorkspaces;

  // ---------------------------------------------------------------- login screen
  function showLogin(msg) {
    clear(appEl);
    let poll = null;
    const st = state.status || { telegram: {}, demo_mode: true };
    const tg = st.telegram || {};
    const box = h('div', { class: 'card box' });
    const stop = () => poll && clearInterval(poll);

    const startTelegram = async (btn) => {
      await busy(btn, async () => {
        try {
          const r = await api('POST', '/auth/web/start');
          clear(linkArea).append(
            h('div', { class: 'note' }, t('Откройте ссылку в Telegram и нажмите «Start» — вход подтвердится автоматически.')),
            h('a', { class: 'btn primary', href: r.deep_link, target: '_blank', rel: 'noopener' }, t('Открыть Telegram')),
            h('div', { class: 'linkbox' }, r.deep_link),
            h('div', { class: 'row', style: 'justify-content:center' }, h('div', { class: 'spinner', style: 'width:18px;height:18px;border-width:2px' }), h('span', { class: 'muted small' }, t('Жду подтверждения…'))));
          stop();
          const until = Date.now() + r.expires_in * 1000;
          poll = setInterval(async () => {
            if (Date.now() > until) { stop(); clear(linkArea).append(h('div', { class: 'note warn' }, t('Ссылка устарела. Нажмите «Войти через Telegram» ещё раз.'))); return; }
            try {
              const p = await api('POST', '/auth/web/poll', { token: r.token });
              if (p.status === 'confirmed') { stop(); adopt(p.user); await enter(); }
              else if (p.status === 'expired') { stop(); clear(linkArea).append(h('div', { class: 'note warn' }, t('Ссылка устарела. Нажмите «Войти через Telegram» ещё раз.'))); }
            } catch (e) { /* keep polling */ }
          }, 2000);
        } catch (e) { fail(e); }
      });
    };
    const startDemo = async (btn) => {
      await busy(btn, async () => {
        try { const r = await api('POST', '/auth/demo'); adopt(r.user); await enter(); } catch (e) { fail(e); }
      });
    };

    const linkArea = h('div', { class: 'stack' });
    const tgReady = tg.connected;
    box.append(
      h('div', { class: 'logo' }, MP.svgEl('svg', { viewBox: '0 0 32 32', width: 32, height: 32 }, MP.svgEl('path', { d: 'M8 21 14 8l3 7 3-4 4 10', fill: 'none', stroke: '#fff', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }))),
      h('h1', {}, 'MarketPilot'),
      h('div', { class: 'muted' }, t('Единое рабочее пространство для Telegram-каналов и групп: публикации, аналитика и команда в одном кабинете.')),
      msg ? h('div', { class: 'note warn', style: 'margin-top:14px' }, msg) : null,
      h('div', { class: 'stack' },
        h('button', { class: 'btn primary', disabled: !tgReady, onclick: (e) => startTelegram(e.currentTarget) }, t('Войти через Telegram')),
        !tgReady ? h('div', { class: 'note warn', style: 'text-align:left' }, tg.configured ? (tg.error ? tg.error : t('Подключаюсь к Telegram…')) : t('Telegram API не подключён: BOT_TOKEN не задан. Работает демо-режим — все функции доступны на демонстрационных данных.')) : null,
        linkArea,
        st.demo_mode ? h('button', { class: 'btn ' + (tgReady ? '' : 'primary'), onclick: (e) => startDemo(e.currentTarget) }, t('Попробовать демо')) : null,
        h('div', { class: 'small muted' }, t('Демо-режим создаёт тестовый аккаунт с примерами каналов и публикаций. Ничего не отправляется в Telegram.'))));
    appEl.append(h('div', { class: 'login' }, box));
    if (!tgReady && tg.configured) setTimeout(async () => { if (!state.user && $('.login')) { await refreshStatus(); if (state.status.telegram.connected) showLogin(msg); } }, 3000);
  }

  // ---------------------------------------------------------------- shell
  function navLinks(kind) {
    const cur = currentRoute();
    return NAV.map(([id, label]) => {
      const active = id === cur || (id === 'tools' && ['analytics', 'autopost'].includes(cur));
      return h('a', { href: '#/' + id, class: active ? 'active' : '', 'aria-current': active ? 'page' : null }, MP.icon(id), kind === 'bottom' ? h('span', {}, t(label)) : t(label));
    });
  }
  const currentRoute = () => { const r = (location.hash || '').replace(/^#\//, '').split('?')[0]; return r === 'notifications' || r === 'analytics' || r === 'autopost' || NAV.some(([id]) => id === r) ? r : 'dashboard'; };
  async function refreshNotificationBadge() {
    try {
      const { unread } = await api('GET', '/notifications?limit=1');
      state.unreadNotifications = unread;
      document.querySelectorAll('.header-notifications').forEach((button) => {
        const badge = button.querySelector('.badge-dot');
        if (unread && badge) { badge.textContent = unread > 9 ? '9+' : unread; badge.hidden = false; }
        else if (unread && !badge) button.append(h('span', { class: 'badge-dot' }, unread > 9 ? '9+' : unread));
        else if (!unread && badge) badge.remove();
      });
    } catch (e) { /* Notification availability does not block the rest of the app. */ }
  }
  MP.refreshNotificationBadge = refreshNotificationBadge;

  function modeBox() {
    const tg = state.status.telegram;
    return tg.connected
      ? h('div', { class: 'modebox live' }, '● Telegram: @' + tg.username)
      : h('div', { class: 'modebox', title: t('Telegram API не подключён') }, '◐ ' + t('ДЕМО-РЕЖИМ'), h('div', {}, t('Telegram API не подключён')));
  }
  function render() {
    if (!state.user) return;
    clear(appEl);
    const u = state.user, route = currentRoute();
    const main = h('main', { class: 'main', id: 'main' });
    const tg = state.status.telegram;
    appEl.append(h('div', { class: 'shell' },
      h('aside', { class: 'side' },
        h('div', { class: 'brand' }, h('div', { class: 'logo' }, MP.svgEl('svg', { viewBox: '0 0 32 32', width: 20, height: 20 }, MP.svgEl('path', { d: 'M8 21 14 8l3 7 3-4 4 10', fill: 'none', stroke: '#fff', 'stroke-width': 2.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }))), 'MarketPilot',
          h('button', { class: 'header-notifications right', type: 'button', 'aria-label': t('Уведомления'), onclick: () => { location.hash = '#/notifications'; } }, MP.icon('bell'))),
        h('nav', { class: 'nav' }, navLinks('side')), h('div', { class: 'grow' }), modeBox(),
        h('div', { class: 'userchip' }, h('div', { class: 'avatar' }, (u.first_name || '?').slice(0, 1).toUpperCase()), h('div', { style: 'min-width:0' }, h('div', { style: 'font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, u.first_name || '—'), h('div', { class: 'small muted' }, u.is_demo ? 'demo' : MP.planLabel(u.plan))), h('button', { class: 'btn sm ghost right', onclick: MP.logout, title: t('Выйти') }, '⎋'))),
      h('div', { style: 'flex:1;min-width:0;display:flex;flex-direction:column' },
        h('div', { class: 'topbar' }, h('div', { class: 'logo', style: 'width:28px;height:28px;border-radius:8px' }, MP.svgEl('svg', { viewBox: '0 0 32 32', width: 18, height: 18 }, MP.svgEl('path', { d: 'M8 21 14 8l3 7 3-4 4 10', fill: 'none', stroke: '#fff', 'stroke-width': 2.8, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }))), h('b', {}, 'MarketPilot'),
          tg.connected ? h('span', { class: 'badge ok right' }, '@' + tg.username) : h('span', { class: 'badge warn right' }, t('ДЕМО-РЕЖИМ')),
          h('button', { class: 'header-notifications', type: 'button', 'aria-label': t('Уведомления'),
            onclick: () => { location.hash = '#/notifications'; } }, MP.icon('bell'))),
        main),
      h('nav', { class: 'bottom' }, navLinks('bottom'))));
    if (!tg.connected) main.append(h('div', { class: 'banner' }, 'ⓘ ', h('div', {}, h('b', {}, t('Демо-режим: ')), t('Telegram API не подключён. Публикации в демо-ресурсы имитируются, ничего не отправляется в Telegram. Подключение: BOT_TOKEN в .env.'))));
    const page = MP.pages[route];
    page(main).catch((e) => { clear(main).append(h('div', { class: 'note err' }, e.message || String(e))); });
    refreshNotificationBadge();
    window.scrollTo(0, 0);
  }
  MP.render = render;
  window.addEventListener('hashchange', () => { if (state.user) render(); });

  async function enter() {
    await refreshStatus();
    await loadWorkspaces();
    if (!location.hash) location.hash = '#/dashboard';
    render();
  }

  // ---------------------------------------------------------------- boot (Mini App auto-login)
  function loadTelegramSdk() {
    return new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = 'https://telegram.org/js/telegram-web-app.js';
      const done = () => resolve(window.Telegram && window.Telegram.WebApp);
      s.onload = done; s.onerror = () => resolve(null);
      document.head.appendChild(s);
      setTimeout(() => resolve(null), 1500);
    });
  }
  async function boot() {
    await refreshStatus();
    if (state.status.authenticated) {
      try { adopt(await api('GET', '/me')); return enter(); } catch (e) { /* fall through to login */ }
    }
    const looksLikeMiniApp = /tgWebAppData|tgWebAppVersion/.test(location.hash + location.search);
    if (looksLikeMiniApp) {
      const wa = await loadTelegramSdk();
      if (wa && wa.initData) {
        try {
          wa.ready(); wa.expand();
          const r = await api('POST', '/auth/miniapp', { init_data: wa.initData });
          adopt(r.user); history.replaceState(null, '', location.pathname + '#/dashboard'); return enter();
        } catch (e) { return showLogin(e.message); }
      }
    }
    showLogin();
  }
  boot();
})();
