/* MarketPilot Mini App. Runs inside Telegram; authenticates by sending the signed initData to the server. */
(function () {
  'use strict';
  const MP = window.MP, TG = window.TG;
  const { h, $, clear, t, api, fmtNum, fmtDateTime, fmtTime, ago } = MP;
  const S = { user: null, status: null, tab: 'home', tools: '', toolCategory: 'automation', resources: [], unread: 0,
    work: { seg: 'posts', status: '', days: 30 }, postsView: 'list',
    calendar: { mode: 'month', cursor: null, resourceId: '' }, aiMessages: [], reauth: false };
  const root = $('#root');

  // ================================================================ local preferences (device only)
  const prefs = { theme: 'tg', haptics: true };
  try { Object.assign(prefs, JSON.parse(localStorage.getItem('mp_app_prefs') || '{}')); } catch (e) { /* storage may be blocked */ }
  function savePrefs() { try { localStorage.setItem('mp_app_prefs', JSON.stringify(prefs)); } catch (e) { /* ignore */ } }
  function applyPrefs() {
    const el = document.documentElement;
    if (prefs.theme === 'tg') el.removeAttribute('data-force'); else el.setAttribute('data-force', prefs.theme);
    TG.setHaptics(prefs.haptics);
  }

  // ================================================================ small helpers
  const SVG = {
    home: 'M3 11.5 12 4l9 7.5M5.5 10v9.5h5v-5.5h3v5.5h5V10',
    work: 'M4 7h16v12H4zM9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M4 12h16',
    bell: 'M6 16v-5a6 6 0 1 1 12 0v5l1.5 2h-15zM10 21h4',
    tools: 'M14.7 6.3a4 4 0 0 0-5-5L7.5 3.5l3 3L8 9l-3-3-2.2 2.2a4 4 0 0 0 5 5l8.7 8.7a2 2 0 0 0 2.8-2.8z',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20a7.5 7.5 0 0 1 15 0',
    posts: 'M4 5h16v11H8l-4 4zM8 9h8M8 12h5',
    gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  };
  const icon = (n) => MP.svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }, MP.svgEl('path', { d: SVG[n] }));
  const toast = (m, err) => { MP.toast(m, err); TG.haptic(err ? 'error' : 'success'); };
  const fail = (e) => toast(e && e.message ? e.message : String(e), true);
  const TABS = [['home', 'Главная', 'home'], ['posts', 'Публикации', 'posts'], ['resources', 'Сообщества', 'work'], ['tools', 'Инструменты', 'tools'], ['profile', 'Профиль', 'user']];
  const STATUS_PILL = { draft: ['Черновик', ''], scheduled: ['Запланирован', 'blue'], publishing: ['Отправляется', 'warn'], published: ['Опубликован', 'ok'], failed: ['Ошибка', 'bad'], cancelled: ['Отменён', ''], unknown: ['Не подтверждён', 'warn'] };
  const RES_PILL = { active: ['Подключён', 'ok'], missing_rights: ['Нет прав', 'warn'], disconnected: ['Отключён', ''], pending: ['Ожидает', ''] };
  const TYPES = { channel: 'Канал', group: 'Группа', supergroup: 'Супергруппа' };
  const CAPS = { publish: 'Публикация', edit_messages: 'Редактирование', delete_messages: 'Удаление', restrict_members: 'Ограничения', pin_messages: 'Закрепление' };
  const RIGHTS = { administrator: 'права администратора', can_post_messages: 'публиковать сообщения', can_edit_messages: 'редактировать', can_delete_messages: 'удалять сообщения', can_restrict_members: 'ограничивать участников', can_pin_messages: 'закреплять сообщения' };
  const splashStartedAt = Date.now();
  async function waitForSplash() {
    const remaining = 2600 - (Date.now() - splashStartedAt);
    if (remaining > 0) await new Promise((resolve) => setTimeout(resolve, remaining));
  }
  const KIND = { published: ['✅', 'ok'], publish_failed: ['⚠️', 'bad'], publish_unknown: ['❓', 'warn'], rights_changed: ['🔑', 'warn'], resource_connected: ['🔗', 'ok'], resource_disconnected: ['⛔', ''] };
  const pill = (map, k) => { const [l, c] = map[k] || [k, '']; return h('span', { class: 'pill ' + c }, t(l)); };
  const demoPill = () => h('span', { class: 'pill demo' }, 'DEMO');
  const busy = async (btn, fn) => { if (btn) btn.disabled = true; try { return await fn(); } finally { if (btn) btn.disabled = false; } };
  const skeleton = (n = 3) => h('div', {}, Array.from({ length: n }, () => h('div', { class: 'skel' })));
  const empty = (em, title, text, ...actions) => h('div', { class: 'card empty' }, h('div', { class: 'em' }, em), h('h3', {}, title), h('p', { class: 'small' }, text), actions.length ? h('div', { class: 'row wrap', style: 'justify-content:center;margin-top:14px' }, actions) : null);
  function errorBox(el, e, retry) {
    clear(el).append(h('div', { class: 'card' }, h('div', { class: 'note err' }, (e && e.message) || String(e)), retry ? h('button', { class: 'btn block', style: 'margin-top:12px', onclick: retry }, 'Повторить') : null));
  }
  async function loadResources() { S.resources = (await api('GET', '/resources')).items; return S.resources; }
  const activeResources = () => S.resources.filter((r) => r.status !== 'disconnected');
  const botLink = () => (S.status && S.status.telegram && S.status.telegram.username) || '';

  // ================================================================ sheets (bottom sheets with Back button support)
  const sheets = [];
  function openSheet({ title, body, full = false, onClose }) {
    const scrim = h('div', { class: 'scrim' });
    const bodyEl = h('div', { class: 'sheet-body' }, body);
    const sheet = h('div', { class: 'sheet' + (full ? ' full' : ''), role: 'dialog', 'aria-modal': 'true' },
      full ? null : h('div', { class: 'grabber' }),
      h('div', { class: 'sheet-head' }, h('h2', {}, title), h('button', { class: 'btn ghost sm right', 'aria-label': 'Закрыть', onclick: () => ctl.close() }, '✕')), bodyEl);
    const ctl = {
      el: sheet, body: bodyEl,
      close() {
        if (!sheet.isConnected) return;
        sheet.remove(); scrim.remove();
        const i = sheets.indexOf(ctl); if (i >= 0) sheets.splice(i, 1);
        if (sheets.length) TG.showBack(sheets[sheets.length - 1].close); else { TG.hideBack(); document.body.style.overflow = ''; }
        if (onClose) onClose();
      },
    };
    if (!full) scrim.addEventListener('click', () => ctl.close());
    document.body.append(scrim, sheet);
    document.body.style.overflow = 'hidden';
    sheets.push(ctl);
    TG.showBack(ctl.close);
    TG.haptic('light');
    return ctl;
  }

  // ================================================================ boot & auth
  function gate(emoji, title, text, ...actions) {
    clear(root).append(h('div', { class: 'gate' }, h('div', { class: 'box' },
      h('div', { class: 'logo' }, MP.svgEl('svg', { viewBox: '0 0 32 32', width: 36, height: 36 }, MP.svgEl('path', { d: 'M8 21 14 8l3 7 3-4 4 10', fill: 'none', stroke: '#fff', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }))),
      h('h1', { class: 'title' }, title), h('p', { class: 'muted' }, text), actions)));
  }
  function adopt(u) {
    S.user = u; MP.state.user = u; MP.state.lang = u.language; MP.state.tz = u.timezone; document.documentElement.lang = u.language;
  }
  async function loadWorkspaces() {
    const items = (await api('GET', '/workspaces')).items;
    const key = 'mp_workspace_' + S.user.id;
    let saved = null;
    try { saved = localStorage.getItem(key); } catch (e) { /* storage may be blocked */ }
    const selected = items.find((item) => String(item.id) === saved) || items.find((item) => item.owner_user_id === S.user.id) || items[0];
    MP.state.workspaces = items;
    MP.state.workspaceId = selected ? selected.id : null;
    if (selected) { try { localStorage.setItem(key, String(selected.id)); } catch (e) { /* storage may be blocked */ } }
  }
  async function authTelegram() {
    const r = await api('POST', '/auth/miniapp', { init_data: TG.initData });
    MP.token = r.token; adopt(r.user);
    await loadWorkspaces();
    // first launch on this account: align the time zone with the device
    try {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (tz && tz !== r.user.timezone && Date.now() - new Date(r.user.created_at).getTime() < 10 * 60 * 1000) adopt(await api('PUT', '/me', { timezone: tz }));
    } catch (e) { /* not critical */ }
  }
  MP.onUnauthorized = async () => { // session expired: initData is still valid for a while, so sign in again once
    if (S.reauth || !TG.inTelegram) return outsideGate();
    S.reauth = true;
    try { await authTelegram(); S.reauth = false; show(S.tab); } catch (e) { S.reauth = false; fatal(e); }
  };
  function fatal(e) {
    const expired = e && (e.code === 'bad_init_data');
    gate(expired ? '⏱' : '⚠️', expired ? 'Сессия устарела' : 'Не удалось открыть', expired ? 'Закройте приложение и откройте его снова из чата с ботом.' : (e && e.message) || 'Неизвестная ошибка',
      h('button', { class: 'btn primary', onclick: () => location.reload() }, 'Повторить'), expired ? h('button', { class: 'btn', onclick: () => TG.close() }, 'Закрыть') : null);
  }
  function outsideGate() {
    const bot = botLink();
    const acts = [];
    if (bot) acts.push(h('button', { class: 'btn primary', onclick: () => window.open('https://t.me/' + bot, '_blank', 'noopener') }, '🚀 Открыть бота в Telegram'));
    if (S.status && S.status.demo_mode) acts.push(h('button', { class: 'btn', onclick: async (e) => busy(e.currentTarget, async () => { try { const r = await api('POST', '/auth/demo'); MP.token = r.token; adopt(r.user); await loadWorkspaces(); enter(); } catch (err) { fail(err); } }) }, 'Предпросмотр с демо-данными'));
    gate('📱', 'Откройте из Telegram', 'Это мини-приложение работает внутри Telegram: отправьте боту /start и нажмите «🚀 Открыть приложение».', acts);
  }
  async function boot() {
    TG.init(); applyPrefs();
    try { S.status = await api('GET', '/status'); } catch (e) { await waitForSplash(); return fatal(e); }
    const paymentParam = new URLSearchParams(location.search).get('payment');
    const paymentId = /^\d+$/.test(paymentParam || '') && Number(paymentParam) > 0 ? Number(paymentParam) : null;
    if (!TG.inTelegram) {
      if (paymentId && S.status.authenticated) {
        try {
          adopt(await api('GET', '/me'));
          await loadWorkspaces();
          await waitForSplash();
          enter();
          await showPaymentResult(paymentId);
        } catch (e) { await waitForSplash(); fatal(e); }
        return;
      }
      await waitForSplash();
      return outsideGate();
    }
    try {
      await authTelegram();
      const invite = new URLSearchParams(location.search).get('invite');
      if (invite) {
        const joined = await api('POST', '/workspaces/join', { token: invite });
        MP.state.workspaceId = joined.workspace.id;
        MP.state.workspaces = (await api('GET', '/workspaces')).items;
        try { localStorage.setItem('mp_workspace_' + S.user.id, String(joined.workspace.id)); } catch (e) { /* storage may be blocked */ }
        history.replaceState(null, '', location.pathname + location.hash);
      }
    } catch (e) { await waitForSplash(); return fatal(e); }
    await waitForSplash();
    enter();
    if (paymentId) await showPaymentResult(paymentId);
  }

  async function showPaymentResult(paymentId) {
    const url = new URL(location.href);
    url.searchParams.delete('payment');
    history.replaceState(null, '', url.pathname + url.search + url.hash);

    const message = h('div', { class: 'note warn' }, 'Проверяем статус оплаты…');
    const amount = h('div', { class: 'muted small' });
    const refresh = h('button', { class: 'btn primary block' }, 'Проверить статус');
    openSheet({ title: 'Статус оплаты', body: h('div', { class: 'col' }, message, amount, refresh) });

    refresh.onclick = () => busy(refresh, async () => {
      try {
        const payment = await api('GET', `/community-payments/${paymentId}`);
        const states = {
          pending: ['Платёж ожидает подтверждения.', 'warn'],
          waiting_for_capture: ['Платёж обрабатывается.', 'warn'],
          succeeded: ['Оплата прошла. Привилегии тарифа активированы.', ''],
          canceled: ['Платёж отменён.', ''],
          refunded: ['Платёж возвращён.', ''],
          refund_pending: ['Возврат обрабатывается.', 'warn'],
          unknown: ['Статус уточняется. Не оплачивайте повторно; проверьте позже.', 'warn'],
        };
        const [label, style] = states[payment.status] || ['Статус платежа: ' + payment.status, 'warn'];
        message.className = 'note' + (style ? ' ' + style : '');
        message.textContent = label;
        amount.textContent = payment.amount ? `Сумма: ${payment.amount} ₽` : '';
      } catch (e) {
        message.className = 'note err';
        message.textContent = e && e.message ? e.message : 'Не удалось получить статус оплаты.';
      }
    });
    await refresh.onclick();
  }
  function enter() {
    const q = new URLSearchParams(location.search).get('p') || TG.startParam;
    const start = { notifications: 'notifications', profile: 'profile', settings: 'settings', work: 'posts', posts: 'posts',
      resources: 'resources', tools: 'tools' }[q] || 'home';
    S.tab = start;
    clear(root).append(h('div', { class: 'app' },
      h('header', { class: 'app-header' }, h('b', { class: 'app-brand' }, 'MarketPilot'), h('button', {
        id: 'notification-button', class: 'header-notifications', type: 'button', 'aria-label': 'Уведомления',
        onclick: () => show('notifications'),
      }, icon('bell'), h('span', { class: 'badge-dot', style: S.unread ? '' : 'display:none' }, S.unread > 9 ? '9+' : S.unread))),
      h('main', { class: 'view', id: 'view' }), h('nav', { class: 'nav', id: 'nav' })));
    show(start);
    refreshBadge();
  }

  // ================================================================ navigation
  function renderNav() {
    const nav = $('#nav'); if (!nav) return;
    clear(nav).append(h('div', { class: 'nav-inner' }, TABS.map(([id, label, ic]) => h('button', {
      class: S.tab === id || (id === 'profile' && S.tab === 'settings') ? 'on' : '',
      'aria-label': t(label), 'aria-current': S.tab === id || (id === 'profile' && S.tab === 'settings') ? 'page' : null,
      onclick: () => { TG.haptic('select'); show(id); },
    }, icon(ic), h('span', { class: 'nav-label' }, t(label))))));
  }
  function renderHeader() {
    const button = $('#notification-button');
    if (!button) return;
    clear(button).append(icon('bell'), S.unread ? h('span', { class: 'badge-dot' }, S.unread > 9 ? '9+' : S.unread) : null);
    button.classList.toggle('on', S.tab === 'notifications');
  }
  async function refreshBadge() {
    try { S.unread = (await api('GET', '/notifications?limit=1')).unread; renderNav(); renderHeader(); } catch (e) { /* ignore */ }
  }
  const VIEWS = {};
  async function show(tab) {
    if (S.tab === 'notifications' && tab !== 'notifications' && S.unread) {
      api('POST', '/notifications/read').then(() => { S.unread = 0; renderNav(); renderHeader(); }).catch(() => {});
    }
    S.tab = tab;
    const app = $('.app');
    if (app) app.classList.toggle('ai-mode', tab === 'assistant');
    TG.hideMain();
    renderNav();
    renderHeader();
    const view = $('#view'); if (!view) return;
    clear(view).classList.remove('view-enter'); void view.offsetWidth; view.classList.add('view-enter');
    view.scrollTop = 0; window.scrollTo(0, 0);
    view.append(skeleton(tab === 'home' ? 4 : 3));
    const holder = h('div');
    try { await VIEWS[tab](holder); clear(view).append(holder); }
    catch (e) { if (e && e.status === 401) return; errorBox(clear(view), e, () => show(tab)); }
  }
  const goWork = (seg, status) => {
    if (seg === 'resources') return show('resources');
    if (seg === 'analytics') { S.toolCategory = 'analytics'; S.tools = 'analytics'; return show('tools'); }
    S.postsView = 'list';
    if (status !== undefined) S.work.status = status;
    show('posts');
  };

  // ================================================================ HOME
  VIEWS.home = async (el) => {
    const [d] = await Promise.all([api('GET', '/dashboard?days=30'), loadResources()]);
    const notes = (await api('GET', '/notifications?limit=3')).items;
    const k = d.kpis, u = S.user;
    const photo = TG.user && TG.user.photo_url;
    const series = d.members_series.filter((v) => v !== null);
    let spark = null;
    if (series.length > 1) {
      const lo = Math.min(...series), hi = Math.max(...series), n = series.length;
      const pts = series.map((v, i) => `${(i / (n - 1)) * 100},${36 - ((v - lo) / (hi - lo || 1)) * 30}`);
      spark = MP.svgEl('svg', { class: 'spark', viewBox: '0 0 100 40', preserveAspectRatio: 'none' }, MP.svgEl('polyline', { points: pts.join(' '), fill: 'none', stroke: '#fff', 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round', 'vector-effect': 'non-scaling-stroke' }));
    }
    el.append(
      h('div', { class: 'greet' }, h('div', { class: 'avatar' }, photo ? h('img', { src: photo, alt: '', referrerpolicy: 'no-referrer', onerror: (e) => e.target.remove() }) : (u.first_name || '?').slice(0, 1).toUpperCase()),
        h('div', {}, h('div', { class: 'muted small' }, new Intl.DateTimeFormat(MP.state.lang === 'en' ? 'en-US' : 'ru-RU', { timeZone: MP.state.tz, weekday: 'long', day: 'numeric', month: 'long' }).format(new Date())), h('h1', { class: 'title', style: 'font-size:23px' }, 'Привет, ' + (u.first_name || '').split(' ')[0] + ' 👋')),
        u.is_demo ? h('span', { class: 'right' }, demoPill()) : null),
      u.is_demo ? h('div', { class: 'note warn', style: 'margin-bottom:12px' }, 'Предпросмотр: данные демонстрационные, в Telegram ничего не отправляется.') : null,
      h('div', { class: 'hero' }, spark, h('div', { class: 'lbl' }, 'Всего подписчиков'), h('div', { class: 'big' }, fmtNum(k.members.value)),
        k.members.delta !== null && k.members.delta !== undefined ? h('span', { class: 'delta' }, (k.members.delta >= 0 ? '▲ +' : '▼ ') + fmtNum(k.members.delta) + ' за 30 дн.') : h('span', { class: 'delta' }, 'динамика появится после первых снимков')),
      h('div', { class: 'kpis' },
        h('div', { class: 'kpi tap', onclick: () => goWork('posts', 'published') }, h('div', { class: 'v' }, fmtNum(k.published.value)), h('div', { class: 'l' }, 'Опубликовано')),
        h('div', { class: 'kpi tap', onclick: () => goWork('posts', 'scheduled') }, h('div', { class: 'v' }, fmtNum(k.scheduled.value)), h('div', { class: 'l' }, 'В очереди')),
        h('div', { class: 'kpi tap' + (k.attention.value ? ' attn' : ''), onclick: () => goWork('posts', 'failed') }, h('div', { class: 'v', style: k.attention.value ? 'color:var(--warn)' : '' }, fmtNum(k.attention.value)), h('div', { class: 'l' }, 'Внимание'))));
    if (!S.resources.length) {
      el.append(h('div', { class: 'h2' }, 'Начало работы'), h('div', { class: 'card' },
        [['Добавьте бота администратором в канал или группу'], ['Отправьте там команду /connect с кодом'], ['Планируйте публикации и смотрите аналитику']].map(([s], i) => h('div', { class: 'step' }, h('i', {}, i + 1), h('div', {}, s))),
        h('div', { class: 'row wrap', style: 'margin-top:8px' }, h('button', { class: 'btn primary', onclick: () => connectSheet(() => show('home')) }, '🔗 Подключить ресурс'),
          h('button', { class: 'btn', onclick: async (e) => busy(e.currentTarget, async () => { try { await api('POST', '/me/demo-data'); toast('Демо-данные загружены'); show('home'); } catch (err) { fail(err); } }) }, 'Загрузить демо-данные'))));
    }
    el.append(h('div', { class: 'h2' }, 'Быстрые действия'), h('div', { class: 'actions' },
      [['✍️', 'Новый пост', 'Текст, фото, расписание', () => composer({ onSaved: () => show('home') })], ['🔗', 'Подключить ресурс', 'Канал или группа', () => connectSheet(() => show('home'))],
        ['📅', 'Очередь', 'Запланированные посты', () => goWork('posts', 'scheduled')], ['📊', 'Аналитика', 'Рост и активность', () => goWork('analytics')]]
        .map(([e, b, s, fn]) => h('button', { class: 'action', onclick: () => { TG.haptic('light'); fn(); } }, h('div', { class: 'ico' }, e), h('b', {}, b), h('span', { class: 'muted small' }, s)))));
    el.append(h('div', { class: 'h2' }, 'Ближайшие публикации'), h('div', { class: 'card list' }, d.upcoming.length ? d.upcoming.map((x) => h('div', { class: 'item tap', onclick: () => openPostById(x.post_id, () => show('home')) },
      h('div', { class: 'ico' }, '🕒'), h('div', { style: 'min-width:0' }, h('div', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, x.text || '—'), h('div', { class: 'muted small' }, fmtDateTime(x.scheduled_at) + ' · ' + x.resource_title)))) : h('div', { class: 'muted', style: 'padding:6px 0' }, 'Нет запланированных публикаций')));
    if (notes.length) el.append(h('div', { class: 'h2' }, 'Последние события'), h('div', { class: 'card list tap', onclick: () => show('notifications') }, notes.map((n) => noteItem(n))));
    el.append(h('div', { class: 'note', style: 'margin-top:14px;font-size:13px' }, d.views_note));
  };
  function noteItem(n, onclick) {
    const [e, c] = KIND[n.kind] || ['🔔', ''];
    return h('div', { class: 'item' + (n.unread ? ' unread' : '') + (onclick ? ' tap' : ''), onclick }, h('div', { class: 'ico ' + c }, e),
      h('div', {}, h('div', {}, n.message), h('div', { class: 'muted small' }, ago(n.created_at) + ' · ' + fmtDateTime(n.created_at))));
  }

  // ================================================================ WORK
  VIEWS.work = async (el) => {
    await loadResources();
    const body = h('div');
    const seg = h('div', { class: 'seg', style: 'margin-bottom:14px' });
    const draw = () => clear(seg).append([['posts', 'Публикации'], ['resources', 'Ресурсы'], ['analytics', 'Аналитика']].map(([id, l]) => h('button', { class: S.work.seg === id ? 'on' : '', onclick: () => { TG.haptic('select'); S.work.seg = id; draw(); load(); } }, l)));
    el.append(h('h1', { class: 'title', style: 'margin-bottom:14px' }, t('Работа')), seg, body);
    const fab = h('button', { class: 'fab', style: 'display:none' }, '＋');
    async function load() {
      clear(body).append(skeleton(3));
      const seg_ = S.work.seg;
      fab.style.display = seg_ === 'analytics' ? 'none' : '';
      fab.setAttribute('aria-label', seg_ === 'posts' ? 'Новый пост' : 'Подключить ресурс');
      fab.onclick = seg_ === 'posts' ? () => composer({ onSaved: load }) : () => connectSheet(load);
      try {
        const next = h('div');
        await ({ posts: workPosts, resources: workResources, analytics: workAnalytics })[seg_](next);
        if (seg_ === S.work.seg) clear(body).append(next);
      } catch (e) { if (!(e && e.status === 401)) errorBox(clear(body), e, load); }
    }
    el.append(fab);
    draw(); await load();
  };

  VIEWS.posts = async (el) => {
    await loadResources();
    const body = h('div');
    const segment = h('div', { class: 'seg posts-segment', style: 'margin-bottom:14px' });
    const fab = h('button', { class: 'fab', 'aria-label': 'Новый пост' }, '＋');
    const draw = () => {
      clear(segment).append([['list', 'Список'], ['calendar', 'Календарь']].map(([id, label]) =>
        h('button', { class: S.postsView === id ? 'on' : '', onclick: () => { S.postsView = id; draw(); load(); } }, label)));
    };
    async function load() {
      clear(body).append(skeleton(3));
      try {
        const content = h('div');
        if (S.postsView === 'calendar') await workCalendar(content);
        else await workPosts(content);
        clear(body).append(content);
      } catch (e) { errorBox(clear(body), e, load); }
      fab.style.display = S.postsView === 'calendar' ? 'none' : '';
    }
    fab.onclick = () => composer({ onSaved: load });
    el.append(h('h1', { class: 'title', style: 'margin-bottom:14px' }, 'Публикации'), segment, body, fab);
    draw(); await load();
  };

  VIEWS.resources = async (el) => {
    await loadResources();
    const body = h('div');
    const fab = h('button', { class: 'fab', 'aria-label': 'Подключить сообщество' }, '＋');
    const load = async () => {
      clear(body).append(skeleton(3));
      try { await workResources(body); }
      catch (e) { errorBox(clear(body), e, load); }
    };
    fab.onclick = () => connectSheet(load);
    el.append(h('h1', { class: 'title', style: 'margin-bottom:14px' }, 'Сообщества'), body, fab);
    await load();
  };

  // ---------------------------------------------------------------- posts
  async function workPosts(el) {
    const list = h('div'), more = h('div', { style: 'text-align:center;margin-top:12px' });
    let offset = 0;
    const chips = h('div', { class: 'chips' }, [['', 'Все'], ['scheduled', 'Запланированные'], ['draft', 'Черновики'], ['published', 'Опубликованные'], ['failed', 'Ошибки'], ['unknown', 'Не подтверждены']].map(([v, l]) =>
      h('button', { class: 'chip' + (S.work.status === v ? ' on' : ''), onclick: (e) => { TG.haptic('select'); S.work.status = v; chips.querySelectorAll('.chip').forEach((c) => c.classList.remove('on')); e.currentTarget.classList.add('on'); load(true); } }, l)));
    el.append(chips, list, more);
    async function load(reset) {
      if (reset) { offset = 0; clear(list); }
      const q = new URLSearchParams({ limit: 15, offset }); if (S.work.status) q.set('status', S.work.status);
      const r = await api('GET', '/posts?' + q);
      r.items.forEach((p) => list.append(postCard(p, () => load(true))));
      offset += r.items.length; clear(more);
      if (!r.items.length && reset) list.append(empty('📝', 'Публикаций нет', S.work.status ? 'Измените фильтр или создайте новую публикацию.' : 'Создайте первую публикацию: черновик, по расписанию или сразу.', h('button', { class: 'btn primary', onclick: () => composer({ onSaved: () => load(true) }) }, 'Новый пост')));
      if (offset < r.total) more.append(h('button', { class: 'btn', onclick: () => load(false) }, `Показать ещё (${r.total - offset})`));
    }
    await load(true);
  }

  async function workCalendar(el) {
    const tz = MP.state.tz;
    if (!S.calendar.cursor) S.calendar.cursor = MP.todayKey();
    const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(t);
    const title = h('b', { class: 'cal-title' });
    const grid = h('div');
    const resource = h('select', { 'aria-label': 'Фильтр по сообществу' },
      h('option', { value: '' }, 'Все сообщества'),
      activeResources().map((r) => h('option', { value: r.id, selected: String(r.id) === S.calendar.resourceId }, r.title)));
    resource.onchange = () => { S.calendar.resourceId = resource.value; load(); };
    const shift = (delta) => {
      if (S.calendar.mode === 'week') S.calendar.cursor = MP.addDays(S.calendar.cursor, 7 * delta);
      else {
        const [year, month] = S.calendar.cursor.split('-').map(Number);
        S.calendar.cursor = new Date(Date.UTC(year, month - 1 + delta, 1)).toISOString().slice(0, 10);
      }
      load();
    };
    const mode = h('div', { class: 'seg' }, [['week', 'Неделя'], ['month', 'Месяц']].map(([id, label]) =>
      h('button', { class: S.calendar.mode === id ? 'on' : '', onclick: () => { S.calendar.mode = id; load(); } }, label)));
    const controls = h('div', { class: 'cal-controls' },
      h('button', { class: 'btn sm', 'aria-label': 'Предыдущий период', onclick: () => shift(-1) }, '‹'),
      title,
      h('button', { class: 'btn sm', 'aria-label': 'Следующий период', onclick: () => shift(1) }, '›'),
      h('button', { class: 'btn sm', onclick: () => { S.calendar.cursor = MP.todayKey(); load(); } }, 'Сегодня'),
      mode, resource);
    el.append(controls, grid);

    async function load() {
      const cursor = S.calendar.cursor;
      let start, end;
      if (S.calendar.mode === 'week') {
        start = MP.addDays(cursor, -MP.weekdayOf(cursor));
        end = MP.addDays(start, 7);
        title.textContent = `${MP.fmtDay(start)} — ${MP.fmtDay(MP.addDays(end, -1))}`;
      } else {
        const [year, month] = cursor.split('-').map(Number);
        const first = `${cursor.slice(0, 8)}01`;
        start = MP.addDays(first, -MP.weekdayOf(first));
        const nextFirst = new Date(Date.UTC(year, month, 1)).toISOString().slice(0, 10);
        const last = MP.addDays(nextFirst, -1);
        end = MP.addDays(last, 7 - MP.weekdayOf(last));
        title.textContent = new Intl.DateTimeFormat(MP.state.lang === 'en' ? 'en-US' : 'ru-RU', {
          timeZone: 'UTC', month: 'long', year: 'numeric',
        }).format(new Date(Date.UTC(year, month - 1, 1)));
      }
      const query = new URLSearchParams({
        from: MP.zonedToUtc(start + 'T00:00', tz).toISOString(),
        to: MP.zonedToUtc(end + 'T00:00', tz).toISOString(),
      });
      if (S.calendar.resourceId) query.set('resource_id', S.calendar.resourceId);
      clear(grid).append(skeleton(2));
      let items;
      try { items = (await api('GET', '/targets?' + query)).items; }
      catch (e) { errorBox(clear(grid), e, load); return; }
      const byDay = {};
      items.forEach((item) => {
        if (item.scheduled_at) (byDay[MP.dayKey(item.scheduled_at, tz)] ||= []).push(item);
      });
      const today = MP.todayKey();
      const chip = (item) => h('button', {
        class: 'cal-item ' + item.status, title: `${item.resource_title}: ${item.text}`,
        onclick: () => openPostById(item.post_id, load),
      }, `${fmtTime(item.scheduled_at)} ${item.text || item.resource_title}`);
      clear(grid);
      if (S.calendar.mode === 'week') {
        const week = h('div', { class: 'mini-cal-week' });
        for (let i = 0; i < 7; i++) {
          const day = MP.addDays(start, i);
          const list = byDay[day] || [];
          week.append(h('section', { class: 'mini-cal-day' + (day === today ? ' today' : '') },
            h('b', {}, `${weekdays[i]} ${MP.fmtDay(day)}`), list.length ? list.map(chip) : h('span', { class: 'muted small' }, 'Нет публикаций'),
            day >= today ? h('button', { class: 'btn sm ghost', onclick: () => composer({ date: day, onSaved: load }) }, '+ Пост') : null));
        }
        grid.append(week);
      } else {
        const month = h('div', { class: 'mini-cal-grid' }, weekdays.map((day) => h('div', { class: 'mini-cal-dow' }, day)));
        for (let day = start; day < end; day = MP.addDays(day, 1)) {
          const list = byDay[day] || [];
          month.append(h('section', { class: 'mini-cal-cell' + (day.slice(0, 7) !== cursor.slice(0, 7) ? ' other' : '') + (day === today ? ' today' : '') },
            h('span', { class: 'mini-cal-num' }, String(Number(day.slice(8)))),
            day >= today ? h('button', { class: 'mini-cal-add', title: 'Новый пост', onclick: () => composer({ date: day, onSaved: load }) }, '+') : null,
            list.slice(0, 2).map(chip),
            list.length > 2 ? h('span', { class: 'muted tiny' }, `+${list.length - 2} ещё`) : null));
        }
        grid.append(month);
      }
    }
    await load();
  }
  function postCard(p, reload) {
    const text = p.text.replace(/<[^>]+>/g, '').trim() || (p.image_url ? '🖼 Изображение' : '—');
    return h('div', { class: 'card post tap', onclick: () => postSheet(p, reload) }, h('div', { class: 'txt' }, text),
      p.targets.map((x) => h('div', { class: 'tline' }, pill(STATUS_PILL, x.status), h('b', {}, x.resource_title), h('span', { class: 'muted' }, x.status === 'published' ? fmtDateTime(x.published_at) : x.scheduled_at ? fmtDateTime(x.scheduled_at) : 'без даты'))),
      p.targets.filter((x) => x.error && ['failed', 'unknown'].includes(x.status)).slice(0, 1).map((x) => h('div', { class: 'err-text', style: 'margin-top:6px' }, x.error)));
  }
  async function openPostById(id, reload) {
    try { postSheet(await api('GET', '/posts/' + id), reload); } catch (e) { fail(e); }
  }
  function postSheet(p, reload) {
    let timer = null, cleanupPreview = () => {};
    const sh = openSheet({ title: 'Публикация', body: h('div'), onClose: () => { if (timer) clearInterval(timer); cleanupPreview(); } });
    const draw = (post) => {
      cleanupPreview();
      const preview = h('div');
      clear(sh.body).append(h('div', { class: 'col' }, preview,
          h('div', { class: 'card list' }, post.targets.map((x) => h('div', { class: 'item' }, h('div', { style: 'flex:1;min-width:0' },
            h('div', { class: 'row wrap' }, h('b', {}, x.resource_title), pill(STATUS_PILL, x.status)), h('div', { class: 'muted small' }, x.status === 'published' ? fmtDateTime(x.published_at) : x.scheduled_at ? fmtDateTime(x.scheduled_at) : 'без даты'),
            x.error && ['failed', 'unknown'].includes(x.status) ? h('div', { class: 'err-text' }, x.error) : null,
            h('div', { class: 'row wrap', style: 'margin-top:8px' },
              ['draft', 'scheduled', 'cancelled'].includes(x.status) ? h('button', { class: 'btn sm primary', onclick: (e) => act(e, () => api('POST', `/post-targets/${x.id}/publish-now`), 'Поставлено в очередь') }, 'Опубликовать сейчас') : null,
              ['draft', 'scheduled'].includes(x.status) ? h('button', { class: 'btn sm', onclick: (e) => act(e, () => api('POST', `/post-targets/${x.id}/cancel`), 'Отменено') }, 'Отменить') : null,
              ['failed', 'unknown'].includes(x.status) ? h('button', { class: 'btn sm', onclick: async (e) => { if (x.status === 'unknown' && !(await TG.confirm('Telegram не подтвердил отправку: возможно, сообщение уже опубликовано. Повторная отправка может создать дубль. Повторить?'))) return; act(e, () => api('POST', `/post-targets/${x.id}/retry`), 'Поставлено в очередь'); } }, 'Повторить') : null))))),
          h('div', { class: 'row wrap' },
            h('button', { class: 'btn', disabled: post.targets.some((x) => x.status === 'published' || x.status === 'publishing'), onclick: () => { sh.close(); composer({ post, onSaved: reload }); } }, '✏️ Изменить'),
            h('button', { class: 'btn', onclick: (e) => busy(e.currentTarget, async () => { try { await api('POST', `/posts/${p.id}/duplicate`); toast('Копия создана как черновик'); sh.close(); reload(); } catch (err) { fail(err); } }) }, '⧉ Копировать'),
            h('button', { class: 'btn danger right', onclick: async () => {
              const published = post.targets.some((x) => x.status === 'published' || x.status === 'publishing');
              if (await TG.confirm('Удалить пост из MarketPilot?' + (published ? ' Уже опубликованные сообщения в Telegram останутся.' : ''))) {
                try { await api('DELETE', '/posts/' + post.id); toast('Пост удалён'); sh.close(); reload(); } catch (err) { fail(err); }
              }
            } }, 'Удалить'))));
      cleanupPreview = MP.postPreview(preview, post.text, post.image_url);
      p = post;
    };
    async function act(e, fn, msg) { await busy(e.currentTarget, async () => { try { await fn(); toast(msg); const fresh = await api('GET', '/posts/' + p.id); p = fresh; draw(fresh); reload(); } catch (err) { fail(err); } }); }
    draw(p);
    timer = setInterval(async () => {
      if (!sh.el.isConnected || !p.targets.some((x) => x.status === 'publishing' ||
        (x.status === 'scheduled' && x.scheduled_at && new Date(x.scheduled_at).getTime() <= Date.now() + 60_000))) return;
      try { draw(await api('GET', '/posts/' + p.id)); reload(); } catch (e) { /* Keep the last confirmed state visible. */ }
    }, 3000);
  }

  // ---------------------------------------------------------------- composer
  function composer({ post, date, onSaved }) {
    const tz = MP.state.tz, targets = post ? post.targets : [];
    const ed = { text: post ? post.text : '', image: post ? post.image_url || '' : '', imagePreview: '', ids: new Set(targets.map((x) => x.resource_id)), mode: 'draft', when: '' };
    const nextSlot = () => { const d = new Date(Date.now() + 3600e3); d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0); return MP.utcToInput(d.toISOString(), tz); };
    if (post) {
      const sched = targets.find((x) => x.status === 'scheduled');
      if (targets.length && targets.every((x) => x.status === 'draft')) ed.mode = 'draft'; else { ed.mode = 'schedule'; ed.when = sched ? MP.utcToInput(sched.scheduled_at, tz) : nextSlot(); }
    } else { ed.when = nextSlot(); if (activeResources().length === 1) ed.ids.add(activeResources()[0].id); }
    const counter = h('div', { class: 'counter' }), prev = h('div'), err = h('div', { class: 'note err', style: 'display:none;margin-top:12px' });
    const clearError = () => { err.textContent = ''; err.style.display = 'none'; };
    const ta = h('textarea', { placeholder: 'Текст публикации. Поддерживается HTML-форматирование Telegram.', oninput: (e) => { clearError(); ed.text = e.target.value; refresh(); } }); ta.value = ed.text;
    const uploadStatus = h('div', { class: 'muted small' });
    const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', style: 'display:none' });
    const urlInput = h('input', { type: 'url', placeholder: 'https://…/image.jpg', value: ed.image.startsWith('upload:') ? '' : ed.image });
    const uploadButton = h('button', { class: 'btn sm' }, 'Выбрать файл');
    const removeImageButton = h('button', { class: 'btn sm ghost', style: ed.image ? '' : 'display:none' }, 'Убрать изображение');
    const whenField = h('div', { class: 'field' }, h('label', { class: 'f' }, `Дата и время (${tz})`), h('input', { type: 'datetime-local', value: ed.when, oninput: (e) => { clearError(); ed.when = e.target.value; } }));
    const label = () => (ed.mode === 'now' ? 'Опубликовать' : ed.mode === 'schedule' ? 'Запланировать' : 'Сохранить черновик');
    const inPageBtn = h('button', { class: 'btn primary block', style: 'margin-top:6px' }, label());
    let nativeMain = false;
    const refresh = () => {
      const len = MP.visibleLength(ed.text), lim = ed.image.trim() ? 1024 : 4096;
      counter.textContent = `${len} / ${lim}`; counter.className = 'counter' + (len > lim ? ' over' : '');
      const imageSource = ed.imagePreview || (/^https?:\/\//i.test(ed.image.trim()) ? ed.image.trim() : '');
      clear(prev).append(ed.text.trim() || imageSource ? MP.tgBubble(ed.text, imageSource) : h('div', { class: 'muted small' }, 'Здесь появится предпросмотр'));
      removeImageButton.style.display = ed.image ? '' : 'none';
      whenField.style.display = ed.mode === 'schedule' ? '' : 'none';
      inPageBtn.textContent = label(); if (nativeMain) TG.showMain(label(), submit);
    };
    fileInput.onchange = async () => {
      const file = fileInput.files && fileInput.files[0];
      fileInput.value = '';
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) { uploadStatus.className = 'note err'; uploadStatus.textContent = 'Файл больше 10 MiB'; return; }
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) { uploadStatus.className = 'note err'; uploadStatus.textContent = 'Выберите JPEG, PNG или WebP'; return; }
      uploadButton.disabled = true; uploadStatus.className = 'muted small'; uploadStatus.textContent = 'Загрузка…';
      try {
        const uploaded = await MP.upload('/media', file);
        if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
        ed.image = uploaded.image_url;
        ed.imagePreview = URL.createObjectURL(file);
        urlInput.value = '';
        clearError();
        uploadStatus.className = 'note ok';
        uploadStatus.textContent = `${uploaded.filename} · ${(uploaded.size / 1024 / 1024).toFixed(2)} MiB`;
        refresh();
      } catch (e) {
        uploadStatus.className = 'note err'; uploadStatus.textContent = e.message || 'Не удалось загрузить файл';
      } finally { uploadButton.disabled = false; }
    };
    uploadButton.onclick = () => fileInput.click();
    urlInput.oninput = () => {
      clearError();
      if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
      ed.imagePreview = ''; ed.image = urlInput.value.trim(); uploadStatus.textContent = ''; refresh();
    };
    removeImageButton.onclick = () => {
      clearError();
      if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview);
      ed.imagePreview = ''; ed.image = ''; urlInput.value = ''; uploadStatus.textContent = ''; refresh();
    };
    const wrap = (o, c) => { clearError(); const s = ta.selectionStart, e = ta.selectionEnd; ta.value = ta.value.slice(0, s) + o + ta.value.slice(s, e) + c + ta.value.slice(e); ed.text = ta.value; ta.focus(); ta.setSelectionRange(s + o.length, e + o.length); refresh(); };
    const linkRow = h('div', { class: 'row', style: 'display:none;margin-bottom:8px' }), linkInput = h('input', { type: 'url', placeholder: 'https://…' });
    linkRow.append(linkInput, h('button', { class: 'btn sm', onclick: () => { const u = linkInput.value.trim(); if (/^https?:\/\//i.test(u)) { wrap(`<a href="${u.replace(/"/g, '&quot;')}">`, '</a>'); linkRow.style.display = 'none'; linkInput.value = ''; } else toast('Введите ссылку, начинающуюся с http(s)://', true); } }, 'Вставить'));
    const tb = h('div', { class: 'toolbar' }, [['<b>', '</b>', 'B', 'font-weight:800'], ['<i>', '</i>', 'I', 'font-style:italic'], ['<u>', '</u>', 'U', 'text-decoration:underline'], ['<s>', '</s>', 'S', 'text-decoration:line-through'], ['<code>', '</code>', '</>', ''], ['<tg-spoiler>', '</tg-spoiler>', '◼', '']].map(([o, c, l, st]) => h('button', { class: 'btn sm', style: st, onclick: () => { TG.haptic('select'); wrap(o, c); } }, l)),
      h('button', { class: 'btn sm', onclick: () => { linkRow.style.display = linkRow.style.display === 'none' ? 'flex' : 'none'; } }, '🔗'));
    const tplSelect = h('select', {}, h('option', { value: '' }, 'Шаблоны…')); let tpls = [];
    api('GET', '/templates').then((r) => { tpls = r.items; tplSelect.append(tpls.map((x) => h('option', { value: x.id }, x.name))); }).catch(() => {});
    tplSelect.onchange = () => { const x = tpls.find((y) => String(y.id) === tplSelect.value); if (x) { clearError(); ta.value = ed.text = x.text; refresh(); } };
    const resList = h('div', { class: 'reslist' }, activeResources().length ? activeResources().map((r) => { const bad = r.status !== 'active'; return h('label', { class: bad ? 'dis' : '' }, h('input', { type: 'checkbox', checked: ed.ids.has(r.id), onchange: (e) => { clearError(); TG.haptic('select'); e.target.checked ? ed.ids.add(r.id) : ed.ids.delete(r.id); } }), h('span', { style: 'flex:1' }, r.title), r.is_demo ? demoPill() : null, bad ? h('span', { class: 'pill warn' }, 'нет прав') : null); }) : h('div', { class: 'muted', style: 'padding:12px 0' }, 'Нет ресурсов. Подключите ресурс на вкладке «Работа».'));
    const modeSeg = h('div', { class: 'seg' });
    const drawMode = () => clear(modeSeg).append([['draft', 'Черновик'], ['schedule', 'По расписанию'], ['now', 'Сейчас']].map(([v, l]) => h('button', { class: ed.mode === v ? 'on' : '', onclick: () => { clearError(); TG.haptic('select'); ed.mode = v; drawMode(); refresh(); } }, l)));
    drawMode();

    if (ed.image.startsWith('upload:')) {
      const mediaId = ed.image.slice('upload:'.length);
      api('GET', `/media/${mediaId}`).then((media) => {
        const binary = atob(media.data), bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
        ed.imagePreview = URL.createObjectURL(new Blob([bytes], { type: media.mime })); refresh();
      }).catch(() => { uploadStatus.className = 'note warn'; uploadStatus.textContent = 'Загруженное изображение сохранено, но предпросмотр недоступен.'; });
    }

    async function submit() {
      clearError();
      const payload = { text: ed.text, image_url: ed.image.trim() || null, resource_ids: [...ed.ids], mode: ed.mode };
      if (ed.mode === 'schedule') { if (!ed.when) { err.textContent = 'Укажите дату и время'; err.style.display = ''; return; } payload.scheduled_at = MP.zonedToUtc(ed.when, tz).toISOString(); }
      if (ed.mode === 'now' && !(await TG.confirm('Опубликовать сразу? Пост будет отправлен в выбранные ресурсы.'))) return;
      inPageBtn.disabled = true; TG.setMainBusy(true);
      try {
        await api(post ? 'PUT' : 'POST', post ? '/posts/' + post.id : '/posts', payload);
        toast(ed.mode === 'draft' ? 'Черновик сохранён' : ed.mode === 'now' ? 'Пост поставлен в очередь' : 'Публикация запланирована');
        sh.close(); if (onSaved) onSaved();
      } catch (e) { err.textContent = e.message; err.style.display = ''; TG.haptic('error'); inPageBtn.disabled = false; TG.setMainBusy(false); }
    }
    inPageBtn.onclick = submit;
    const sh = openSheet({ title: post ? 'Редактирование' : 'Новый пост', full: true, onClose: () => { TG.hideMain(); if (ed.imagePreview) URL.revokeObjectURL(ed.imagePreview); },
      body: h('div', {}, h('div', { class: 'field' }, h('label', { class: 'f' }, 'Текст'), tb, linkRow, ta, counter, h('div', { style: 'margin-top:8px' }, tplSelect)),
        h('div', { class: 'field' }, h('label', { class: 'f' }, 'Изображение'),
          h('div', { class: 'row wrap' }, uploadButton, removeImageButton), fileInput,
          h('div', { class: 'muted small', style: 'margin:6px 0' }, 'Выберите файл с устройства: JPEG, PNG или WebP, до 10 MiB.'), uploadStatus,
          h('details', { style: 'margin-top:8px' }, h('summary', { class: 'small muted', style: 'cursor:pointer' }, 'Или указать ссылку'), urlInput)),
        h('div', { class: 'field' }, h('label', { class: 'f' }, 'Куда публиковать'), resList), h('div', { class: 'field' }, h('label', { class: 'f' }, 'Когда'), modeSeg), whenField,
        h('div', { class: 'field' }, h('label', { class: 'f' }, 'Предпросмотр'), prev), err, inPageBtn) });
    nativeMain = TG.showMain(label(), submit);
    if (nativeMain) inPageBtn.style.display = 'none';
    refresh();
  }

  // ---------------------------------------------------------------- resources
  async function workResources(el) {
    await loadResources();
    if (!S.resources.length) return el.append(empty('📡', 'Ресурсов пока нет', 'Подключите канал или группу через бота либо добавьте демо-данные.', h('button', { class: 'btn primary', onclick: () => connectSheet(() => show('resources')) }, '🔗 Подключить'), h('button', { class: 'btn', onclick: async (e) => busy(e.currentTarget, async () => { try { await api('POST', '/me/demo-data'); toast('Демо-данные загружены'); show('resources'); } catch (err) { fail(err); } }) }, 'Демо-данные')));
    const reload = () => show('resources');
    S.resources.forEach((r) => {
      const dis = r.status === 'disconnected', d = r.members_delta_7d;
      el.append(h('div', { class: 'card', style: dis ? 'opacity:.7' : '' },
        h('div', { class: 'row wrap' }, h('b', { style: 'font-size:17px' }, r.title), r.is_demo ? demoPill() : null, h('span', { class: 'right' }, pill(RES_PILL, r.status))),
        h('div', { class: 'muted small' }, TYPES[r.type] + (r.username ? ' · @' + r.username : '')),
        h('div', { class: 'row', style: 'align-items:baseline;margin-top:8px' }, h('span', { class: 'big-num' }, fmtNum(r.members)), h('span', { class: 'muted small' }, 'подписчиков'), d !== null && d !== undefined ? h('span', { class: 'small ' + (d >= 0 ? 'up' : 'down') }, (d >= 0 ? '▲ +' : '▼ ') + fmtNum(d) + ' за 7 дн.') : null),
        r.missing_rights.length ? h('div', { class: 'note warn', style: 'margin-top:10px' }, 'Не хватает прав: ' + r.missing_rights.map((x) => RIGHTS[x] || x).join(', ')) : null,
        h('div', { class: 'rights' }, r.capabilities.map((c) => h('span', { class: 'pill blue' }, CAPS[c] || c))),
        h('div', { class: 'muted tiny', style: 'margin-top:8px' }, `Опубликовано: ${r.published_total} · В очереди: ${r.scheduled_count} · Проверено: ${ago(r.last_checked_at)}`),
        h('div', { class: 'row wrap', style: 'margin-top:12px' }, dis ? [
          r.is_demo ? h('button', { class: 'btn sm', onclick: (e) => busy(e.currentTarget, async () => { try { await api('POST', `/resources/${r.id}/reconnect`); toast('Ресурс подключён'); reload(); } catch (err) { fail(err); } }) }, 'Подключить заново') : null,
          h('button', { class: 'btn sm danger', onclick: async () => { if (await TG.confirm('Удалить ресурс и всю его историю из MarketPilot?')) { try { await api('DELETE', `/resources/${r.id}/forget`); toast('Удалено'); reload(); } catch (err) { fail(err); } } } }, 'Удалить')] : [
          h('button', { class: 'btn sm', onclick: (e) => busy(e.currentTarget, async () => { try { await api('POST', `/resources/${r.id}/check`); toast('Права проверены'); reload(); } catch (err) { fail(err); } }) }, 'Проверить права'),
          r.username && !r.is_demo ? h('button', { class: 'btn sm', onclick: () => TG.openTelegramLink('https://t.me/' + r.username) }, 'Открыть') : null,
          r.is_demo ? h('button', { class: 'btn sm', onclick: (e) => busy(e.currentTarget, async () => { try { await api('POST', `/resources/${r.id}/simulate-rights`); toast('Права изменены (демо)'); reload(); } catch (err) { fail(err); } }) }, r.status === 'active' ? 'Отозвать права (демо)' : 'Вернуть права (демо)') : null,
          h('button', { class: 'btn sm danger', onclick: async () => { if (await TG.confirm(`Отключить «${r.title}»? Будущие публикации в него будут отменены.`)) { try { await api('DELETE', `/resources/${r.id}`); toast('Ресурс отключён'); reload(); } catch (err) { fail(err); } } } }, 'Отключить')])));
    });
  }
  function connectSheet(reload) {
    let poll = null; const known = new Set(S.resources.map((r) => r.id));
    const live = h('div', { class: 'col' }), demo = { title: '', type: 'channel', members: 1500 }, derr = h('div', { class: 'err-text' });
    const trialInfo = h('div', { class: 'col' });
    const connectButton = h('button', { class: 'btn primary block', onclick: (e) => start(e.currentTarget) }, 'Получить код');
    const start = (btn) => busy(btn, async () => {
      try {
        const r = await api('POST', '/resources/link-code');
        if (!r.live) return clear(live).append(h('div', { class: 'note warn' }, r.message));
        const cmd = '/connect ' + r.code;
        const bot = r.bot_username;
        clear(live).append(
          h('div', { class: 'card flat', style: 'text-align:center;background:var(--soft)' }, h('div', { class: 'muted small' }, 'Ваш код подключения (15 минут)'), h('div', { style: 'font:800 30px ui-monospace,Menlo,monospace;letter-spacing:.08em;margin:6px 0' }, r.code),
            h('button', { class: 'btn sm', onclick: async () => { toast((await TG.copy(cmd)) ? 'Команда скопирована' : cmd); } }, '⧉ Скопировать ' + cmd)),
          h('div', { class: 'step' }, h('i', {}, 1), h('div', {}, 'Добавьте бота администратором:', h('div', { class: 'row wrap', style: 'margin-top:8px' },
            h('button', { class: 'btn sm primary', onclick: () => TG.openTelegramLink(`https://t.me/${bot}?startchannel&admin=post_messages+edit_messages+delete_messages`) }, 'В канал'),
            h('button', { class: 'btn sm primary', onclick: () => TG.openTelegramLink(`https://t.me/${bot}?startgroup&admin=delete_messages+restrict_members+pin_messages`) }, 'В группу')))),
          h('div', { class: 'step' }, h('i', {}, 2), h('div', {}, 'Отправьте в этом чате сообщение ', h('b', {}, cmd))),
          h('div', { class: 'row muted small' }, h('div', { class: 'spinner', style: 'width:18px;height:18px;border-width:2px' }), 'Жду подключения — экран обновится сам…'));
        poll = setInterval(async () => {
          try { const s = await api('GET', '/resources/link-status'); const fresh = s.items.find((x) => !known.has(x.id)); if (fresh) { clearInterval(poll); toast(`Подключён «${fresh.title}»`); sh.close(); reload(); } } catch (e) { /* keep polling */ }
        }, 3000);
      } catch (e) { clear(live).append(h('div', { class: 'note err' }, e.message)); }
    });
    const sh = openSheet({ title: 'Подключить ресурс', onClose: () => poll && clearInterval(poll), body: h('div', { class: 'col' },
      trialInfo,
      h('div', { class: 'card' }, h('b', {}, 'Через Telegram-бота'), h('p', { class: 'muted small', style: 'margin:4px 0 12px' }, 'Бот проверит свои права и добавит ресурс в ваше пространство.'), connectButton, h('div', { style: 'margin-top:12px' }, live)),
      h('div', { class: 'card' }, h('b', {}, 'Демо-ресурс'), h('p', { class: 'muted small', style: 'margin:4px 0 12px' }, 'Ничего не отправляет в Telegram: удобно проверить планировщик и аналитику.'),
        h('div', { class: 'field' }, h('input', { type: 'text', maxlength: 80, placeholder: 'Название', oninput: (e) => (demo.title = e.target.value) })),
        h('div', { class: 'row', style: 'margin-bottom:12px' }, h('select', { onchange: (e) => (demo.type = e.target.value) }, ['channel', 'group', 'supergroup'].map((v) => h('option', { value: v }, TYPES[v]))), h('input', { type: 'number', min: 0, value: demo.members, oninput: (e) => (demo.members = +e.target.value) })),
        derr, h('button', { class: 'btn block', onclick: (e) => busy(e.currentTarget, async () => { derr.textContent = ''; try { await api('POST', '/resources/demo', { ...demo, title: demo.title.trim() }); toast('Демо-ресурс добавлен'); sh.close(); reload(); } catch (err) { derr.textContent = err.message; TG.haptic('error'); } }) }, 'Добавить демо-ресурс'))) });
    api('GET', '/premium/summary').then((summary) => {
      if (summary.trial_available) {
        const button = h('button', { class: 'btn primary block', onclick: (e) => busy(e.currentTarget, async () => {
          try {
            await api('POST', '/subscriptions/trial');
            adopt(await api('GET', '/me'));
            toast('Тариф BUSINESS активирован на 7 дней');
            clear(trialInfo).append(h('div', { class: 'note ok' }, 'Пробный BUSINESS активирован на 7 дней. Автопродления нет.'));
            await start(connectButton);
          } catch (err) { fail(err); }
        }) }, 'Попробовать BUSINESS 7 дней бесплатно');
        trialInfo.append(h('div', { class: 'card' }, h('b', {}, 'Попробуйте максимум возможностей'), h('p', { class: 'muted small', style: 'margin:4px 0 12px' }, '7 дней тарифа BUSINESS бесплатно: больше ресурсов и все функции. Пробный доступ можно активировать один раз, автопродления нет.'), button));
      } else if (summary.trial_active) {
        trialInfo.append(h('div', { class: 'note ok' }, 'У вас активен пробный тариф BUSINESS до ' + fmtDateTime(summary.next_renewal) + '.'));
      }
    }).catch((err) => trialInfo.append(h('div', { class: 'note err' }, 'Не удалось проверить пробный доступ: ' + err.message)));
  }

  // ---------------------------------------------------------------- analytics
  async function workAnalytics(el) {
    const days = S.work.days;
    const d = await api('GET', '/analytics?days=' + days);
    if (!d.table.length) return el.append(empty('📊', 'Нет данных для аналитики', 'Подключите ресурс или загрузите демо-данные.'));
    el.append(h('div', { class: 'seg', style: 'margin-bottom:12px' }, [7, 30, 90].map((n) => h('button', { class: n === days ? 'on' : '', onclick: () => { S.work.days = n; show('tools'); } }, `${n} дн.`))),
      h('div', { class: 'kpis', style: 'margin:0 0 12px' }, h('div', { class: 'kpi' }, h('div', { class: 'v ' + (d.growth.delta >= 0 ? 'up' : 'down') }, (d.growth.delta >= 0 ? '+' : '') + fmtNum(d.growth.delta)), h('div', { class: 'l' }, 'Прирост' + (d.growth.pct !== null ? ` · ${d.growth.pct}%` : ''))),
        h('div', { class: 'kpi' }, h('div', { class: 'v' }, fmtNum(d.published_series.reduce((a, b) => a + b, 0))), h('div', { class: 'l' }, 'Публикаций')),
        h('div', { class: 'kpi' }, h('div', { class: 'v' }, (d.published_series.reduce((a, b) => a + b, 0) / days).toFixed(1)), h('div', { class: 'l' }, 'В день'))),
      h('div', { class: 'card' }, h('b', {}, 'Динамика подписчиков'), h('div', { style: 'margin-top:10px' }, MP.lineChart({ labels: d.labels, series: [{ name: 'Подписчики', values: d.members_series }], height: 200 })), h('div', { class: 'muted tiny', style: 'margin-top:6px' }, 'Источник: ' + d.source)),
      h('div', { class: 'card' }, h('b', {}, 'Публикации по дням'), h('div', { style: 'margin-top:10px' }, MP.barChart({ labels: d.labels, values: d.published_series, height: 170 }))),
      h('div', { class: 'card' }, h('b', {}, 'Ресурсы'), h('div', { class: 'list', style: 'margin-top:8px' }, d.table.map((r) => h('div', { class: 'item' }, h('div', { style: 'flex:1;min-width:0' }, h('div', { class: 'row wrap' }, h('b', {}, r.title), r.is_demo ? demoPill() : null), h('div', { class: 'muted small' }, `${TYPES[r.type]} · опубликовано ${r.published} · ошибок ${r.failed + r.unknown}`)),
        h('div', { style: 'text-align:right' }, h('b', {}, fmtNum(r.members)), r.delta !== null ? h('div', { class: 'small ' + (r.delta >= 0 ? 'up' : 'down') }, (r.delta >= 0 ? '+' : '') + fmtNum(r.delta)) : null))))),
      d.group_activity ? h('div', { class: 'card' }, h('b', {}, 'Активность групп'), h('div', { style: 'margin-top:10px' }, MP.lineChart({ labels: d.labels, zeroBase: true, height: 190, series: [{ name: 'Сообщения', values: d.group_activity.messages }, { name: 'Вступления', values: d.group_activity.joins }, { name: 'Выходы', values: d.group_activity.leaves }] })), h('div', { class: 'muted tiny', style: 'margin-top:6px' }, 'Источник: ' + d.group_activity.source)) : null,
      d.tips.length ? h('div', { class: 'card' }, h('b', {}, 'Рекомендации'), d.tips.map((x) => h('div', { class: 'row', style: 'align-items:flex-start;margin-top:8px' }, h('span', {}, '💡'), h('div', { class: 'small' }, x)))) : null,
      h('div', { class: 'note warn', style: 'margin-top:12px' }, d.limitations.map((x) => h('div', { class: 'small', style: 'margin:2px 0' }, '• ' + x))));
  }

  // ================================================================ TOOLS
  const toolCategories = [
    ['protection', 'Защита'], ['content', 'Контент'], ['analytics', 'Аналитика'],
    ['monetization', 'Монетизация'], ['automation', 'Автоматизация'],
  ];
  const toolModules = [
    ['assistant', 'AI Assistant', 'Получайте краткие ответы и идеи для контента сообщества. Промпты не сохраняются в журнале MarketPilot.', 'content'],
    ['moderation', 'Модерация', 'Задайте условия, строгость и действие: предупреждение, удаление или блокировка автора. Администраторы чата исключаются.', 'protection'],
    ['antiscam', 'Anti-scam', 'Проверяйте каждую ссылку, принимайте решение по неизвестным доменам и автоматически удаляйте ссылки из стоп-листа.', 'protection'],
    ['autoclean', 'Автоочистка', 'Автоматически удаляйте сообщения по словам, повторам и ссылкам. Настройте правила отдельно для каждой группы.', 'protection'],
    ['limits', 'Лимиты сообщений', 'Ограничивайте число сообщений каждого участника за календарный день в часовом поясе владельца; задавайте действие при превышении.', 'protection'],
    ['templates', 'Шаблоны', 'Храните типовые тексты и вставляйте их в редактор публикаций; отмечайте избранное и указывайте переменные.', 'content'],
    ['autopost', 'Объявления сообщества', 'Отправляйте объявления в сообщества по подписке и управляйте очередью модерации своего сообщества.', 'automation'],
    ['analytics', 'Аналитика', 'Показывает доступные счётчики и снимки Telegram; просмотры публикаций через Bot API недоступны.', 'analytics'],
    ['export', 'Экспорт', 'Выгружайте доступные данные в CSV для анализа или переноса. Состав файла зависит от выбранного раздела.', 'analytics'],
    ['ads', 'Кампании', 'Ведите бюджет, статус и сроки рекламных кампаний. Этот раздел не покупает и не размещает рекламу.', 'monetization'],
    ['billing', 'Подписки сообществ', 'Управляйте платным доступом к закрытым сообществам и расчётами своего сообщества.', 'monetization'],
    ['autoreplies', 'Автоответы', 'Автоматически отвечайте на сообщения по ключевым словам или фразам; задавайте приоритет и паузу между ответами.', 'automation'],
    ['postlimits', 'Лимиты публикаций', 'Ограничивайте число постов, которые владелец рабочего пространства планирует или отправляет в канал за сутки.', 'automation'],
  ];
  const toolField = (label, control) => h('div', { class: 'field' }, h('label', { class: 'f' }, label), control);
  function toolControl(field, value) {
    if (field.type === 'select') return h('select', {}, field.options.map(([v, label]) => h('option', { value: v, selected: String(value) === String(v) }, label)));
    if (field.type === 'textarea') { const el = h('textarea', { rows: field.rows || 3, placeholder: field.placeholder || '' }); el.value = value || ''; return el; }
    if (field.type === 'checkbox') return h('label', { class: 'row', style: 'min-height:42px' }, h('input', { type: 'checkbox', checked: Boolean(value), style: 'width:auto;min-height:0' }), field.checkLabel || 'Включено');
    return h('input', { type: field.type || 'text', placeholder: field.placeholder || '', value: value ?? '' });
  }
  function toolResourceField(value) {
    return toolField('Ресурс', h('select', {}, h('option', { value: '' }, 'Выберите ресурс'), activeResources().map((r) => h('option', { value: r.id, selected: String(value || '') === String(r.id) }, r.title))));
  }
  function toolForm(title, controls, onSave) {
    const error = h('div', { class: 'note err', style: 'display:none;margin-bottom:12px' });
    const clearError = () => { error.textContent = ''; error.style.display = 'none'; };
    const save = h('button', { class: 'btn primary block' }, 'Сохранить');
    const sheet = openSheet({ title, full: true, body: h('div', {}, controls, error, save) });
    controls.filter(Boolean).forEach((control) => {
      control.addEventListener('input', clearError);
      control.addEventListener('change', clearError);
    });
    save.onclick = (e) => busy(e.currentTarget, async () => {
      clearError();
      try { await onSave(); sheet.close(); toast('Изменения сохранены'); await show('tools'); }
      catch (err) { error.textContent = err.message || String(err); error.style.display = ''; TG.haptic('error'); }
    });
    return sheet;
  }
  function toolActions(items, reload) {
    const list = h('div', { class: 'card list' });
    if (!items.length) list.append(h('div', { class: 'muted small' }, 'Пока нет записей.'));
    items.forEach((item) => list.append(item));
    return list;
  }
  async function toolAssistant(el) {
    let status;
    try {
      status = await api('GET', '/ai/status');
    } catch (e) {
      errorBox(el, e);
      return;
    }

    const screen = h('section', { class: 'ai-screen', 'aria-label': 'AI Assistant' });
    const thread = h('div', { class: 'ai-thread', 'aria-live': 'polite' });
    const prompt = h('textarea', {
      class: 'ai-input', rows: 1, maxlength: 2000, 'aria-label': 'Сообщение для AI Assistant',
      placeholder: 'Спросите что-нибудь о контенте…',
    });
    const usage = h('span', { class: 'ai-usage' });
    const send = h('button', { class: 'ai-send', type: 'button', 'aria-label': 'Отправить сообщение' }, '↑');
    const settingsNote = !status.configured
      ? h('div', { class: 'ai-notice' }, 'AI пока не подключён. Владелец сервера может настроить его в параметрах приложения.')
      : null;
    const composer = h('div', { class: 'ai-composer' },
      h('div', { class: 'ai-input-wrap' }, prompt, send),
      h('div', { class: 'ai-composer-caption' }, usage,
        h('span', {}, 'Ответы создаются ИИ и могут содержать неточности')));
    const suggestions = [
      ['↗', 'Моя аналитика', 'Проанализируй публикации и активность за последние 30 дней'],
      ['✎', 'Подготовить пост', 'Подготовь пост для публикации в моём сообществе'],
      ['⚙', 'Настроить группу', 'Помоги настроить автоответы или правила модерации'],
    ];
    const welcome = () => h('div', { class: 'ai-welcome' },
      h('div', { class: 'ai-orb', 'aria-hidden': 'true' },
        h('div', { class: 'ai-orb-core' }, '✦'),
        h('i', { class: 'ai-orb-dot ai-orb-dot-one' }),
        h('i', { class: 'ai-orb-dot ai-orb-dot-two' })),
      h('span', { class: 'ai-eyebrow' }, 'ВАШ AI-ПОМОЩНИК'),
      h('h1', {}, 'Привет! Чем помочь?'),
      h('p', {}, 'Проверю аналитику, подготовлю пост или помогу настроить группу. Любые изменения — только после вашего подтверждения.'),
      h('div', { class: 'ai-suggestions' }, suggestions.map(([symbol, title, text]) =>
        h('button', { class: 'ai-suggestion', type: 'button', disabled: !status.configured || status.remaining <= 0, onclick: () => {
          prompt.value = text;
          prompt.dispatchEvent(new Event('input'));
          prompt.focus();
        } }, h('span', { class: 'ai-suggestion-icon' }, symbol),
        h('span', {}, h('b', {}, title), h('small', {}, text))))));
    const renderUsage = () => {
      usage.textContent = `${status.remaining} из ${status.daily_limit} запросов осталось`;
      send.disabled = !status.configured || status.remaining <= 0;
      prompt.disabled = !status.configured || status.remaining <= 0;
      if (!status.configured) prompt.placeholder = 'AI пока не подключён';
      else if (status.remaining <= 0) prompt.placeholder = 'Лимит запросов на сегодня исчерпан';
    };
    let waiting = false;
    const renderAction = (action) => {
      const preview = action.preview || {};
      const fields = [
        preview.community && ['Сообщество', preview.community],
        preview.resources && ['Каналы', preview.resources.join(', ')],
        preview.demo && ['Режим', 'Демо — изменения не попадут в Telegram'],
        preview.demo_resources && preview.demo_resources.length && ['Демо-ресурсы', preview.demo_resources.join(', ')],
        preview.mode && ['Действие', ({ draft: 'Черновик', schedule: 'Запланировать', now: 'Опубликовать сейчас' })[preview.mode]],
        preview.scheduled_at && ['Время', preview.scheduled_at],
        preview.condition && ['Условие', preview.condition],
        preview.reply && ['Ответ', preview.reply],
        preview.action && ['Модерация', preview.action === 'delete' ? 'Удалять сообщения' : 'Предупреждать'],
      ].filter(Boolean);
      const controls = action.status === 'pending'
        ? h('div', { class: 'ai-action-controls' },
          h('button', { class: 'btn primary sm', type: 'button', disabled: action.busy,
            onclick: async () => {
              action.busy = true; renderThread();
              try {
                const result = await api('POST', `/ai/actions/${action.id}/confirm`, {});
                action.status = 'confirmed';
                action.message = result.message;
              } catch (err) {
                action.error = err.message || String(err);
              } finally {
                action.busy = false; renderThread();
              }
            } }, action.busy ? 'Выполняем…' : 'Подтвердить'),
          h('button', { class: 'btn sm ghost', type: 'button', disabled: action.busy,
            onclick: async () => {
              action.busy = true; renderThread();
              try {
                await api('POST', `/ai/actions/${action.id}/cancel`, {});
                action.status = 'cancelled';
                action.message = 'Действие отменено.';
              } catch (err) {
                action.error = err.message || String(err);
              } finally {
                action.busy = false; renderThread();
              }
            } }, 'Отмена'))
        : h('div', { class: 'ai-action-status' }, action.message ||
          ({ confirmed: 'Выполнено', cancelled: 'Отменено' })[action.status] || action.status);
      return h('div', { class: 'ai-action' },
        h('b', {}, action.summary),
        preview.text ? h('div', { class: 'ai-action-text' }, preview.text) : null,
        fields.map(([label, value]) => h('div', { class: 'ai-action-detail' }, h('span', {}, label + ': '), value)),
        h('div', { class: 'ai-action-hint' }, 'Будет выполнено только после подтверждения. Запрос действует 15 минут.'),
        action.error ? h('div', { class: 'ai-action-error' }, action.error) : null,
        controls);
    };
    const renderThread = () => {
      clear(thread);
      if (!S.aiMessages.length) thread.append(welcome());
      else {
        thread.append(h('div', { class: 'ai-messages' }, S.aiMessages.map((message) =>
          h('div', { class: 'ai-message-row ' + (message.role === 'user' ? 'from-user' : 'from-assistant') },
            message.role === 'assistant' ? h('span', { class: 'ai-avatar', 'aria-hidden': 'true' }, '✦') : null,
            h('div', { class: 'ai-message' + (message.error ? ' ai-error' : '') }, message.text,
              message.actions ? message.actions.map(renderAction) : null)))));
      }
      if (waiting) thread.append(h('div', { class: 'ai-message-row from-assistant' },
        h('span', { class: 'ai-avatar', 'aria-hidden': 'true' }, '✦'),
        h('div', { class: 'ai-message ai-typing', role: 'status', 'aria-label': 'ИИ формирует ответ' },
          h('i'), h('i'), h('i'))));
      thread.scrollTop = thread.scrollHeight;
    };
    screen.append(h('header', { class: 'ai-topbar' },
      h('button', { class: 'ai-back', type: 'button', 'aria-label': 'Назад к инструментам', onclick: () => show('tools') }, '‹'),
      h('div', { class: 'ai-brand-mark', 'aria-hidden': 'true' }, '✦'),
      h('div', { class: 'ai-topbar-copy' }, h('b', {}, 'AI Assistant'), h('span', {}, 'Помощник сообщества')),
      h('div', { class: 'ai-online' + (status.configured ? '' : ' offline') }, h('i'), status.configured ? 'Онлайн' : 'Не подключён')),
      settingsNote,
      thread,
      composer);
    el.append(screen);
    renderUsage();
    renderThread();

    prompt.addEventListener('input', () => {
      prompt.style.height = 'auto';
      prompt.style.height = Math.min(prompt.scrollHeight, 140) + 'px';
      send.classList.toggle('ready', Boolean(prompt.value.trim()));
    });
    prompt.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        send.click();
      }
    });
    send.onclick = async () => {
      const message = prompt.value.trim();
      if (!message || send.disabled) return;
      send.disabled = true;
      prompt.value = '';
      prompt.style.height = 'auto';
      send.classList.remove('ready');
      S.aiMessages.push({ role: 'user', text: message });
      waiting = true;
      renderThread();
      try {
        const history = S.aiMessages.slice(0, -1).slice(-12)
          .filter((item) => item.role === 'user' || item.role === 'assistant')
          .map((item) => ({ role: item.role, content: item.text }));
        const result = await api('POST', '/ai/chat', { message, history });
        S.aiMessages.push({ role: 'assistant', text: result.reply, actions: result.actions || [] });
        status.remaining = Math.max(0, status.remaining - 1);
      } catch (err) {
        S.aiMessages.push({ role: 'assistant', text: err.message || String(err), error: true });
      } finally {
        waiting = false;
        renderUsage();
        renderThread();
      }
    };
  }
  VIEWS.assistant = toolAssistant;
  VIEWS.tools = async (el) => {
    await loadResources();
    const tabs = h('div', { class: 'tool-categories' });
    const description = h('div', { class: 'note', style: 'margin-bottom:12px' });
    const body = h('div');
    el.append(h('h1', { class: 'title', style: 'margin-bottom:6px' }, 'Инструменты'),
      h('div', { class: 'muted small', style: 'margin-bottom:12px' }, 'Инструменты сгруппированы по задачам сообщества.'), tabs, body);
    const drawTabs = () => clear(tabs).append(toolCategories.map(([id, label]) => h('button', {
      class: 'chip' + (S.toolCategory === id ? ' on' : ''), onclick: () => { S.toolCategory = id; S.tools = ''; drawTabs(); draw(); },
    }, label)));
    async function draw() {
      const selected = toolModules.find(([id]) => id === S.tools);
      if (!selected) {
        const modules = toolModules.filter(([, , , category]) => category === S.toolCategory);
        description.textContent = (toolCategories.find(([id]) => id === S.toolCategory) || toolCategories[0])[1];
        clear(body).append(description, h('div', { class: 'tool-module-list' }, modules.map(([id, label, detail]) =>
          h('button', { class: 'card tool-module', onclick: () => {
            if (id === 'assistant') { S.tools = ''; show('assistant'); return; }
            S.tools = id; draw();
          } },
            h('b', {}, label), h('span', { class: 'muted small' }, detail), h('span', { class: 'tool-module-arrow' }, '›')))));
        return;
      }
      clear(body).append(h('button', { class: 'btn sm ghost', onclick: () => { S.tools = ''; draw(); } }, '‹ Категории'),
        h('div', { class: 'note', style: 'margin:10px 0 12px' }, selected[2]), skeleton(2));
      try {
        const view = h('div');
        await ({ assistant: toolAssistant, autoreplies: toolAutoreplies, autoclean: toolAutoclean, moderation: toolModeration,
          antiscam: toolAntiScam, limits: toolLimits, postlimits: toolPublicationLimits, templates: toolTemplates, ads: toolAds,
          autopost: toolAutopost, billing: toolBilling, export: toolExport, analytics: workAnalytics })[S.tools](view);
        body.replaceChildren(body.children[0], body.children[1], view);
      } catch (e) { errorBox(clear(body), e, draw); }
    }
    drawTabs(); await draw();
  };

  async function toolRules(el, cfg) {
    const resourceById = new Map(S.resources.map((r) => [r.id, r.title]));
    const result = await api('GET', cfg.endpoint);
    const rows = result.items || [];
    const actions = [];
    rows.forEach((r) => actions.push(h('div', { class: 'item' }, h('div', { class: 'grow' },
      h('div', { class: 'row wrap' }, h('b', {}, r.name || cfg.title), h('span', { class: 'pill ' + (r.enabled ? 'ok' : '') }, r.enabled ? 'Включено' : 'Выключено')),
      h('div', { class: 'muted small' }, `${resourceById.get(r.resource_id) || 'Ресурс'} · ${cfg.describe(r)}`)),
      h('div', { class: 'row wrap' },
        h('button', { class: 'btn sm ghost', title: 'Изменить', onclick: () => edit(r) }, '✎'),
        h('button', { class: 'btn sm ghost', title: r.enabled ? 'Выключить' : 'Включить', onclick: async () => { try { await api('PUT', `${cfg.endpoint}/${r.id}`, { enabled: !r.enabled }); toast(r.enabled ? 'Правило выключено' : 'Правило включено'); await show('tools'); } catch (e) { fail(e); } } }, r.enabled ? 'Выключить' : 'Включить'),
        h('button', { class: 'btn sm danger', title: 'Удалить', onclick: async () => { if (!(await TG.confirm('Удалить правило?'))) return; try { await api('DELETE', `${cfg.endpoint}/${r.id}`); toast('Правило удалено'); await show('tools'); } catch (e) { fail(e); } } }, 'Удалить')))));
    const open = h('button', { class: 'btn primary block', style: 'margin-bottom:12px' }, '+ Добавить правило');
    open.onclick = () => edit(null);
    el.append(h('div', { class: 'row', style: 'margin-bottom:10px' }, h('div', { class: 'grow' }, h('b', {}, cfg.title), h('div', { class: 'muted small' }, cfg.help)), h('span', { class: 'pill blue' }, String(rows.length))),
      activeResources().length ? open : empty('📡', 'Сначала подключите ресурс', 'Правила привязываются к конкретному каналу или группе.', h('button', { class: 'btn primary', onclick: () => show('resources') }, 'Открыть сообщества')),
      activeResources().length ? toolActions(actions) : null);
    if (!activeResources().length) return;

    function edit(rule) {
      const controls = cfg.fields.map((f) => {
        const v = rule ? rule[f.key] : f.defaultValue;
        return f.key === 'resource_id' ? toolResourceField(v) : toolField(f.label, toolControl(f, v));
      });
      const values = () => Object.fromEntries(cfg.fields.map((f, i) => {
        const node = f.key === 'resource_id' ? controls[i].querySelector('select') : controls[i].querySelector('input,textarea,select');
        let value = f.type === 'checkbox' ? node.checked : node.value;
        if (f.type === 'number' || f.key === 'resource_id') value = Number(value || 0);
        return [f.key, value];
      }));
      toolForm(rule ? 'Изменить правило' : 'Новое правило', controls, async () => {
        const payload = values();
        if (!payload.resource_id) throw new Error('Выберите ресурс');
        await api(rule ? 'PUT' : 'POST', rule ? `${cfg.endpoint}/${rule.id}` : cfg.endpoint, payload);
      });
    }
    if (cfg.testPath) {
      const resource = h('select', {}, activeResources().map((r) => h('option', { value: r.id }, r.title)));
      const text = toolControl({ type: 'textarea', placeholder: 'Вставьте пример сообщения' }, '');
      const output = h('div', { class: 'muted small' });
      const run = h('button', { class: 'btn sm' }, 'Проверить');
      run.onclick = (e) => busy(e.currentTarget, async () => {
        try {
          const r = await api('POST', cfg.testPath, { resource_id: Number(resource.value), text: text.value });
          output.className = 'note ' + (r.matched || r.status === 'delete' || r.status === 'ban' || r.status === 'warn' ? 'warn' : 'ok');
          output.textContent = cfg.testResult(r);
        } catch (err) { output.className = 'note err'; output.textContent = err.message; }
      });
      el.append(h('div', { class: 'h2' }, 'Проверка сообщения'), h('div', { class: 'card' }, toolField('Ресурс', resource), toolField('Текст сообщения', text), run, output));
    }
  }

  const matchOptions = [['keyword', 'Слово'], ['phrase', 'Фраза'], ['exact', 'Полное совпадение']];
  async function toolAutoreplies(el) {
    await toolRules(el, { title: 'Автоответы', help: 'Ответы бота на сообщения по заданному условию.', endpoint: '/autoreplies', testPath: '/autoreplies/test',
      fields: [{ key: 'name', label: 'Название', defaultValue: '' }, { key: 'resource_id', label: 'Ресурс' }, { key: 'match_type', label: 'Условие', type: 'select', options: matchOptions, defaultValue: 'keyword' }, { key: 'match_text', label: 'Искомый текст', defaultValue: '' }, { key: 'reply_text', label: 'Ответ', type: 'textarea', defaultValue: '' }, { key: 'priority', label: 'Приоритет', type: 'number', defaultValue: 0 }, { key: 'cooldown_minutes', label: 'Пауза между ответами (мин.)', type: 'number', defaultValue: 0 }, { key: 'enabled', label: 'Состояние', type: 'checkbox', defaultValue: true }],
      describe: (r) => `${r.match_text} → ${r.reply_text}`, testResult: (r) => r.matched ? `Совпало правил: ${r.rules.length} (${r.rules.map((x) => x.name).join(', ')})` : 'Совпадений нет.' });
  }
  async function toolAutoclean(el) {
    await toolRules(el, { title: 'Автоочистка', help: 'Правила для удаления ссылок, дублей или сообщений с ключевыми словами.', endpoint: '/autoclean/rules', testPath: '/autoclean/test',
      fields: [{ key: 'name', label: 'Название', defaultValue: '' }, { key: 'resource_id', label: 'Ресурс' }, { key: 'match_type', label: 'Тип правила', type: 'select', options: [['keyword', 'Слово'], ['phrase', 'Фраза'], ['link', 'Ссылки'], ['duplicate', 'Дубликаты']], defaultValue: 'keyword' }, { key: 'match_text', label: 'Искомый текст', defaultValue: '' }, { key: 'enabled', label: 'Состояние', type: 'checkbox', defaultValue: true }],
      describe: (r) => `${r.match_type}${r.match_text ? ' · ' + r.match_text : ''}`, testResult: (r) => r.matched ? `Совпало правил: ${r.rules.length}` : 'Совпадений нет.' });
  }
  async function toolModeration(el) {
    await toolRules(el, { title: 'Модерация', help: 'Правила проверки сообщений; результат зависит от уровня и действия.', endpoint: '/moderation/rules', testPath: '/moderation/scan',
      fields: [{ key: 'name', label: 'Название', defaultValue: '' }, { key: 'resource_id', label: 'Ресурс' }, { key: 'level', label: 'Строгость', type: 'select', options: [['soft', 'Мягкий'], ['standard', 'Стандартный'], ['strict', 'Строгий']], defaultValue: 'standard' }, { key: 'match_type', label: 'Тип проверки', type: 'select', options: [['keyword', 'Слово'], ['phrase', 'Фраза'], ['link', 'Ссылка'], ['repeated', 'Повторы'], ['suspicious_link', 'Подозрительная ссылка']], defaultValue: 'keyword' }, { key: 'match_text', label: 'Искомый текст', defaultValue: '' }, { key: 'action', label: 'Действие', type: 'select', options: [['warn', 'Предупредить'], ['delete', 'Удалить'], ['ban', 'Заблокировать']], defaultValue: 'warn' }, { key: 'enabled', label: 'Состояние', type: 'checkbox', defaultValue: true }],
      describe: (r) => `${r.match_type} · ${r.action} · ${r.level}`, testResult: (r) => `Результат: ${r.status}; риск ${r.score}; совпадений: ${r.matches.length}` });
  }

  async function toolAntiScam(el) {
    const [domains, history] = await Promise.all([api('GET', '/anti-scam/domains'), api('GET', '/anti-scam/history')]);
    const domainKinds = new Map(domains.items.map((d) => [d.domain, d.kind]));
    const manageDomain = async (value, kind) => {
      try { await api('POST', '/anti-scam/domains', { domain: value, kind }); toast(`${value}: ${kind === 'blocked' ? 'добавлен в блок-лист' : kind === 'trusted' ? 'отмечен как доверенный' : 'возвращён на проверку'}`); await show('tools'); }
      catch (e) { fail(e); }
    };
    const domainChoices = (value, current) => h('div', { class: 'row wrap' },
      [['trusted', 'Доверять'], ['review', 'Проверять'], ['blocked', 'Блокировать']].map(([kind, label]) => h('button', {
        class: 'btn sm' + (kind === 'blocked' ? ' danger' : '') + (kind === current ? ' ghost' : ''),
        disabled: kind === current, onclick: () => manageDomain(value, kind),
      }, label)));
    const domain = h('input', { placeholder: 'example.com' });
    const kind = h('select', {}, [['blocked', 'Блокировать'], ['trusted', 'Доверенный'], ['review', 'Проверять']].map(([v, l]) => h('option', { value: v }, l)));
    const save = h('button', { class: 'btn primary block' }, 'Добавить домен');
    save.onclick = (e) => busy(e.currentTarget, async () => manageDomain(domain.value, kind.value));
    el.append(h('div', { class: 'h2' }, 'Добавить домен'), h('div', { class: 'card' },
      h('div', { class: 'muted small', style: 'margin-bottom:10px' }, 'Заблокированные домены удаляются автоматически. Доверенные ссылки не отмечаются как риск. Неизвестные домены попадают в очередь проверки.'),
      toolField('Домен или адрес ссылки', domain), toolField('Решение', kind), save));
    const domainList = domains.items.length ? domains.items.map((d) => h('div', { class: 'item wrap' }, h('div', { class: 'grow' }, h('b', {}, d.domain), h('div', { class: 'small muted' }, d.kind === 'blocked' ? 'Автоматически удалять' : d.kind === 'trusted' ? 'Считать безопасным' : 'Проверять и уведомлять')), domainChoices(d.domain, d.kind))) : [h('div', { class: 'muted small' }, 'Список пока пуст.')];
    el.append(h('div', { class: 'h2' }, 'Списки доменов'), h('div', { class: 'card list' }, domainList));
    if (activeResources().length) {
      const resource = h('select', {}, activeResources().map((r) => h('option', { value: r.id }, r.title)));
      const text = toolControl({ type: 'textarea', placeholder: 'Вставьте сообщение со ссылкой' }, '');
      const result = h('div', { class: 'muted small' });
      const check = h('button', { class: 'btn' }, 'Проверить сообщение');
      check.onclick = (e) => busy(e.currentTarget, async () => { try {
        const r = await api('POST', '/anti-scam/check', { resource_id: Number(resource.value), text: text.value });
        clear(result).append(h('div', { class: 'note ' + (r.status === 'safe' ? 'ok' : 'warn') }, `Статус: ${r.status}; риск: ${r.risk_score}; сигналов: ${r.threats.length}`),
          r.threats.filter((x) => x.domain).map((x) => h('div', { class: 'item' }, h('div', { class: 'grow' }, h('b', {}, x.domain), h('div', { class: 'muted small' }, x.severity)), domainChoices(x.domain, 'review'))));
      } catch (err) { result.className = 'note err'; result.textContent = err.message; } });
      el.append(h('div', { class: 'h2' }, 'Проверка ссылки'), h('div', { class: 'card' }, toolField('Ресурс', resource), toolField('Текст сообщения', text), check, result));
    }
    el.append(h('div', { class: 'h2' }, 'Подозрительные ссылки и скам'), history.items.length ? h('div', { class: 'card list' }, history.items.slice(0, 30).map((x) => {
      const domains = [...new Set((x.threats || []).map((t) => t.domain).filter(Boolean))];
      return h('div', { class: 'item' },
        h('div', { class: 'grow' },
          h('div', { class: 'row wrap' }, h('span', { class: 'pill ' + (x.status === 'safe' ? 'ok' : 'warn') }, x.status), h('b', {}, `${x.risk_score} баллов`)),
          h('div', { class: 'small' }, domains.length ? domains.join(', ') : x.message),
          h('div', { class: 'muted tiny' }, `${x.resource_title || 'Ресурс'} · ${fmtDateTime(x.created_at)}`),
          domains.map((d) => h('div', { class: 'row wrap', style: 'margin-top:6px' }, h('span', { class: 'grow small' }, d), domainChoices(d, domainKinds.get(d) || 'review')))));
    })) : h('div', { class: 'card muted small' }, 'Подозрительных ссылок пока нет. Новые URL автоматически проверяются в подключённых группах.'));
  }

  async function toolLimits(el) {
    const groups = activeResources().filter((r) => ['group', 'supergroup'].includes(r.type) && !r.is_demo);
    const [data, log] = await Promise.all([api('GET', '/message-limits'), api('GET', '/message-limits/log')]);
    const edit = (item) => {
      const resource = h('select', {}, groups.map((r) => h('option', { value: r.id, selected: item && item.resource_id === r.id }, r.title)));
      const maximum = h('input', { type: 'number', min: 1, max: 10000, value: item ? item.max_messages : 20 });
      const action = h('select', {}, [['delete', 'Удалять каждое сообщение сверх лимита'], ['delete_warn', 'Удалять и один раз предупредить в группе'], ['warn', 'Только предупредить, не удалять']].map(([v, l]) => h('option', { value: v, selected: (item ? item.action : 'delete') === v }, l)));
      const excludeAdmins = toolControl({ type: 'checkbox', checkLabel: 'Не ограничивать администраторов и владельца' }, item ? item.exclude_admins : true);
      const notifyOwner = toolControl({ type: 'checkbox', checkLabel: 'Уведомить владельца при первом превышении за день' }, item ? item.notify_owner : true);
      const enabled = item ? toolControl({ type: 'checkbox', checkLabel: 'Правило включено' }, item.enabled) : null;
      const controls = [toolField('Группа', resource), toolField('Максимум сообщений на участника за день', maximum),
        toolField('Что делать при превышении', action), toolField('Исключения', excludeAdmins), toolField('Уведомления', notifyOwner),
        enabled ? toolField('Состояние', enabled) : null,
        h('div', { class: 'note' }, 'Считаются все сообщения участника, включая медиа и подписи. Квота отдельная для каждой группы и сбрасывается в полночь часового пояса владельца. Содержимое не сохраняется. Для удаления сообщений дайте боту право администратора на удаление сообщений.')];
      toolForm(item ? 'Настроить квоту группы' : 'Новая квота группы', controls, async () => {
        if (!resource.value) throw new Error('Подключите реальную группу');
        const payload = { resource_id: Number(resource.value), max_messages: Number(maximum.value), action: action.value,
          exclude_admins: excludeAdmins.querySelector('input').checked, notify_owner: notifyOwner.querySelector('input').checked,
          enabled: enabled ? enabled.querySelector('input').checked : true };
        if (!Number.isInteger(payload.max_messages) || payload.max_messages < 1) throw new Error('Лимит должен быть целым числом не меньше 1');
        await api(item ? 'PUT' : 'POST', item ? `/message-limits/${item.id}` : '/message-limits', payload);
      });
    };
    el.append(h('div', { class: 'row wrap', style: 'margin-bottom:12px' }, h('div', { class: 'grow' }, h('b', {}, 'Квота сообщений участников'), h('div', { class: 'muted small' }, 'Например, при лимите 2 третье и последующие сообщения участника удаляются.')), h('button', { class: 'btn primary', onclick: () => edit(null) }, '+ Добавить')));
    if (!groups.length) el.append(empty('👥', 'Нужна подключённая группа', 'Квоты применяются к участникам реальных групп и супергрупп, не к каналам и демо-ресурсам.', h('button', { class: 'btn primary', onclick: () => show('resources') }, 'Подключить группу')));
    else if (!data.items.length) el.append(empty('🔢', 'Квоты пока не настроены', 'Создайте правило и выберите, удалять превышение, предупреждать участника или делать и то и другое.', h('button', { class: 'btn primary', onclick: () => edit(null) }, 'Настроить лимит')));
    else el.append(toolActions(data.items.map((x) => h('div', { class: 'item' }, h('div', { class: 'grow' }, h('div', { class: 'row wrap' }, h('b', {}, x.resource_title), h('span', { class: 'pill ' + (x.enabled ? 'ok' : '') }, x.enabled ? 'Включено' : 'Выключено')),
      h('div', { class: 'small' }, `До ${x.max_messages} сообщений на участника в сутки`),
      h('div', { class: 'muted small' }, `${x.action === 'delete' ? 'Удалять превышение' : x.action === 'delete_warn' ? 'Удалять и предупреждать' : 'Только предупреждать'} · ${x.exclude_admins ? 'администраторы исключены' : 'учитывать всех'}`)),
      h('button', { class: 'btn sm', onclick: () => edit(x) }, 'Настроить'),
      h('button', { class: 'btn sm danger', onclick: async () => { if (!(await TG.confirm('Удалить квоту для этой группы?'))) return; try { await api('DELETE', `/message-limits/${x.id}`); await show('tools'); } catch (e) { fail(e); } } }, 'Удалить')))));
    el.append(h('div', { class: 'h2' }, 'Срабатывания'), log.items.length ? h('div', { class: 'card list' }, log.items.slice(0, 30).map((x) => h('div', { class: 'item' },
      h('div', { class: 'grow' }, h('b', {}, x.resource_title), h('div', { class: 'small' }, `Участник ${x.sender_id} · ${x.message_count}-е сообщение · ${x.action}`)),
      h('span', { class: 'muted tiny' }, fmtDateTime(x.created_at))))) : h('div', { class: 'card muted small' }, 'Срабатываний пока нет.'));
  }

  async function toolPublicationLimits(el) {
    const data = await api('GET', '/publication-limits');
    const title = h('div', { class: 'row', style: 'margin-bottom:12px' }, h('div', { class: 'grow' }, h('b', {}, 'Лимиты публикаций'), h('div', { class: 'muted small' }, 'Максимум сообщений в сутки для выбранного ресурса.')));
    const add = h('button', { class: 'btn primary block', style: 'margin-bottom:12px' }, '+ Настроить лимит');
    add.onclick = () => {
      const resource = h('select', {}, activeResources().map((r) => h('option', { value: r.id }, r.title)));
      const value = h('input', { type: 'number', min: 1, value: 10 });
      toolForm('Лимит публикаций', [toolField('Ресурс', resource), toolField('Сообщений в сутки', value)], async () => {
        if (!resource.value) throw new Error('Сначала подключите ресурс');
        await api('POST', '/publication-limits', { resource_id: Number(resource.value), kind: 'messages_per_day', value: Number(value.value) });
      });
    };
    title.append(h('span', { class: 'pill blue' }, String(data.items.length)));
    el.append(title, activeResources().length ? add : empty('📡', 'Нет ресурсов', 'Подключите ресурс, чтобы задать лимит.', h('button', { class: 'btn primary', onclick: () => show('resources') }, 'Сообщества')));
    if (activeResources().length) el.append(toolActions(data.items.map((x) => {
      const resource = S.resources.find((r) => r.id === x.resource_id);
      return h('div', { class: 'item' }, h('div', { class: 'grow' }, h('b', {}, resource ? resource.title : 'Ресурс'), h('div', { class: 'muted small' }, `${x.value} сообщений в сутки`)),
        h('button', { class: 'btn sm danger', onclick: async () => { if (!(await TG.confirm('Удалить лимит?'))) return; try { await api('DELETE', `/publication-limits/${x.id}`); await show('tools'); } catch (e) { fail(e); } } }, 'Удалить'));
    })));
  }

  async function toolTemplates(el) {
    const data = await api('GET', '/templates');
    const add = h('button', { class: 'btn primary block', style: 'margin-bottom:12px' }, '+ Новый шаблон');
    add.onclick = () => edit(null);
    el.append(h('div', { class: 'row', style: 'margin-bottom:12px' }, h('div', { class: 'grow' }, h('b', {}, 'Шаблоны сообщений'), h('div', { class: 'muted small' }, 'Сохраняйте заготовки и вставляйте их в редактор публикации.')), h('span', { class: 'pill blue' }, String(data.items.length))), add);
    el.append(toolActions(data.items.map((x) => h('div', { class: 'item' }, h('div', { class: 'grow' }, h('div', { class: 'row wrap' }, h('b', {}, x.name), x.is_favorite ? h('span', { class: 'pill warn' }, '★') : null), h('div', { class: 'muted small' }, x.category || 'general'), h('div', { class: 'small', style: 'white-space:pre-wrap;margin-top:5px' }, x.text)),
      h('button', { class: 'btn sm ghost', title: 'Изменить', onclick: () => edit(x) }, '✎'), h('button', { class: 'btn sm danger', title: 'Удалить', onclick: async () => { if (!(await TG.confirm('Удалить шаблон?'))) return; try { await api('DELETE', `/templates/${x.id}`); await show('tools'); } catch (e) { fail(e); } } }, 'Удалить')))));
    function edit(item) {
      const name = h('input', { value: item ? item.name : '', placeholder: 'Например, приветствие' });
      const text = toolControl({ type: 'textarea', rows: 5, placeholder: 'Текст шаблона' }, item ? item.text : '');
      const category = h('input', { value: item ? item.category : 'general', placeholder: 'Категория' });
      const favorite = toolControl({ type: 'checkbox', checkLabel: 'Избранный шаблон' }, item ? item.is_favorite : false);
      toolForm(item ? 'Изменить шаблон' : 'Новый шаблон', [toolField('Название', name), toolField('Категория', category), toolField('Текст', text), toolField('Избранное', favorite)], async () => {
        const payload = { name: name.value, text: text.value, category: category.value, is_favorite: favorite.querySelector('input').checked,
          variables: [...new Set((text.value.match(/\{([a-zA-Z0-9_-]+)\}/g) || []).map((v) => v.slice(1, -1)))] };
        await api(item ? 'PUT' : 'POST', item ? `/templates/${item.id}` : '/templates', payload);
      });
    }
  }

  async function toolAds(el) {
    const [data] = await Promise.all([api('GET', '/ads')]);
    const add = h('button', { class: 'btn primary block', style: 'margin-bottom:12px' }, '+ Кампания');
    add.onclick = () => edit(null);
    el.append(h('div', { class: 'note warn' }, 'Кабинет ведёт учёт кампаний и бюджета. Публикация рекламы и списание средств не подключены.'), add);
    el.append(toolActions(data.items.map((x) => {
      const resource = S.resources.find((r) => r.id === x.resource_id);
      return h('div', { class: 'item' }, h('div', { class: 'grow' }, h('b', {}, x.title), h('div', { class: 'muted small' }, `${resource ? resource.title : 'Ресурс'} · ${x.status}`), h('div', { class: 'small' }, `Бюджет ${fmtNum(x.budget)} · расход ${fmtNum(x.spend)}`)),
        h('button', { class: 'btn sm ghost', title: 'Изменить', onclick: () => edit(x) }, '✎'), h('button', { class: 'btn sm danger', onclick: async () => { if (!(await TG.confirm('Удалить кампанию?'))) return; try { await api('DELETE', `/ads/${x.id}`); await show('tools'); } catch (e) { fail(e); } } }, 'Удалить'));
    })));
    function edit(item) {
      const title = h('input', { value: item ? item.title : '', placeholder: 'Название кампании' });
      const resource = h('select', {}, activeResources().map((r) => h('option', { value: r.id, selected: item && item.resource_id === r.id }, r.title)));
      const budget = h('input', { type: 'number', min: 0, step: '0.01', value: item ? item.budget : 0 });
      const status = h('select', {}, [['draft', 'Черновик'], ['scheduled', 'Запланирована'], ['running', 'Активна'], ['paused', 'На паузе'], ['completed', 'Завершена']].map(([v, l]) => h('option', { value: v, selected: (item ? item.status : 'draft') === v }, l)));
      toolForm(item ? 'Кампания' : 'Новая кампания', [toolField('Название', title), toolField('Ресурс', resource), toolField('Бюджет', budget), toolField('Статус', status)], async () => {
        if (!resource.value) throw new Error('Сначала подключите ресурс');
        await api(item ? 'PUT' : 'POST', item ? `/ads/${item.id}` : '/ads', { title: title.value, resource_id: Number(resource.value), budget: Number(budget.value), status: status.value });
      });
    }
  }

  async function toolAutopost(el) {
    await loadResources();
    const [available, own] = await Promise.all([
      api('GET', '/community-autopost/communities'),
      api('GET', '/community-autopost/submissions'),
    ]);
    const statusNames = {
      draft: 'Черновик', pending: 'Ожидает публикации', approved: 'Готово к публикации',
      rejected: 'Отклонено', revision: 'Нужно исправить', scheduled: 'Запланировано', publishing: 'Публикуется',
      published: 'Опубликовано', failed: 'Ошибка', unknown: 'Не подтверждено', cancelled: 'Отменено',
    };
    const workspace = (MP.state.workspaces || []).find((item) => Number(item.id) === Number(MP.state.workspaceId));
    const canReview = workspace && ['owner', 'admin', 'moderator'].includes(workspace.role);
    const canManage = workspace && ['owner', 'admin'].includes(workspace.role);
    const content = h('div');
    el.append(h('div', { class: 'row wrap', style: 'margin-bottom:10px' },
      h('div', { class: 'grow' }, h('h2', { style: 'margin:0' }, 'Объявления сообщества'),
        h('div', { class: 'muted small' }, 'Публикуйте объявления в доступные сообщества и следите за их статусом.'))), content);

    if (!available.items.length) {
      content.append(empty('📣', 'Пока нет доступных сообществ',
        'В сообществах, где включён автопост, объявления доступны их участникам. Вступите в сообщество или проверьте настройки владельца.',
        h('button', { class: 'btn primary', onclick: () => { S.tools = 'billing'; show('tools'); } }, 'Подписки сообществ')));
    } else {
      content.append(h('div', { class: 'h2' }, 'Новое объявление'));
      for (const community of available.items) {
        const rules = community.settings;
        const categories = available.categories.filter((item) => rules.allowed_categories.includes(item.id));
        const category = h('select', {}, categories.map((item) => h('option', { value: item.id }, item.name)));
        const text = h('textarea', { rows: 5,
          placeholder: `До ${rules.max_text_length} символов` });
        const wrapText = (openTag, closeTag) => {
          const start = text.selectionStart, end = text.selectionEnd;
          text.value = text.value.slice(0, start) + openTag + text.value.slice(start, end) +
            closeTag + text.value.slice(end);
          text.focus();
          text.setSelectionRange(start + openTag.length, end + openTag.length);
        };
        const formatToolbar = h('div', { class: 'toolbar' },
          [['<b>', '</b>', 'B', 'Жирный', 'font-weight:800'],
            ['<i>', '</i>', 'I', 'Курсив', 'font-style:italic'],
            ['<u>', '</u>', 'U', 'Подчёркнутый', 'text-decoration:underline'],
            ['<s>', '</s>', 'S', 'Зачёркнутый', 'text-decoration:line-through'],
            ['<code>', '</code>', '</>', 'Моноширинный', '']]
            .map(([openTag, closeTag, label, title, style]) => h('button', {
              class: 'btn sm', type: 'button', title, style, onclick: () => wrapText(openTag, closeTag),
            }, label)));
        const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp',
          multiple: true, 'aria-label': 'Фотографии объявления' });
        const mediaIds = [];
        const mediaList = h('div', { class: 'small muted' });
        const schedule = rules.allow_scheduling
          ? h('input', { type: 'datetime-local', 'aria-label': 'Дата публикации' }) : null;
        const error = h('div', { class: 'note err', style: 'display:none' });
        const submit = h('button', { class: 'btn primary', type: 'button' }, 'Отправить');
        const saveDraft = h('button', { class: 'btn', type: 'button' }, 'Сохранить черновик');
        let editing = null;
        let idempotencyKey = submissionKey();
        const showError = (message) => { error.textContent = message; error.style.display = ''; };
        const drawMedia = () => {
          clear(mediaList);
          if (!mediaIds.length) {
            mediaList.textContent = `Можно добавить до ${rules.max_photos} фото`;
            return;
          }
          mediaIds.forEach((media, index) => mediaList.append(h('div', { class: 'row wrap' },
            h('span', { class: 'grow' }, media.filename),
            h('button', { class: 'btn sm ghost', type: 'button', onclick: () => {
              mediaIds.splice(index, 1);
              drawMedia();
            } }, 'Убрать'))));
        };
        fileInput.onchange = async () => {
          error.style.display = 'none';
          const files = Array.from(fileInput.files || []);
          if (mediaIds.length + files.length > rules.max_photos) {
            showError(`Владелец разрешил не больше ${rules.max_photos} фото`);
            fileInput.value = '';
            return;
          }
          fileInput.disabled = true;
          try {
            for (const file of files) {
              const uploaded = await MP.upload('/media', file);
              mediaIds.push({ id: uploaded.id, filename: uploaded.filename });
            }
            drawMedia();
          } catch (e) {
            showError(e.message);
          } finally {
            fileInput.disabled = false;
            fileInput.value = '';
          }
        };
        const send = async (draft, button) => busy(button, async () => {
          error.style.display = 'none';
          const scheduledAt = schedule && schedule.value
            ? new Date(schedule.value).toISOString().replace(/\.\d{3}Z$/, 'Z') : undefined;
          const payload = {
            category: category.value, text: text.value,
            media_ids: mediaIds.map((media) => media.id), draft,
          };
          if (schedule && scheduledAt) payload.scheduled_at = scheduledAt;
          try {
            if (editing) {
              await api('PUT', `/community-autopost/submissions/${editing}`, payload);
            } else {
              if (community.subscription_id) payload.subscription_id = community.subscription_id;
              else payload.resource_id = community.resource_id;
              payload.idempotency_key = idempotencyKey;
              await api('POST', '/community-autopost/submissions', payload);
            }
            toast(draft ? 'Черновик сохранён' : 'Объявление отправлено');
            show('tools');
          } catch (e) { showError(e.message); fail(e); }
        });
        submit.onclick = () => send(false, submit);
        saveDraft.onclick = () => send(true, saveDraft);
        const communityForm = h('div', { class: 'card stack' },
          h('div', { class: 'row wrap' }, h('b', { class: 'grow' }, community.community),
            h('span', { class: 'pill blue' }, community.plan || 'Общее разрешение группы')),
          h('label', { class: 'field' }, h('span', { class: 'f' }, 'Категория'), category),
          h('label', { class: 'field' }, h('span', { class: 'f' }, 'Текст объявления'),
            formatToolbar, text),
          h('label', { class: 'field' }, h('span', { class: 'f' }, 'Фотографии'), fileInput), mediaList,
          schedule ? h('label', { class: 'field' }, h('span', { class: 'f' }, 'Запланировать публикацию'), schedule) : null,
          h('div', { class: 'muted tiny' }, `Лимит: ${rules.daily_limit || 'без лимита'} в день, ${rules.monthly_limit || 'без лимита'} в месяц. Объявление публикуется автоматически. Его можно изменить до начала отправки.`),
          error, h('div', { class: 'row wrap' }, submit, saveDraft));
        drawMedia();
        communityForm._autopostSubscriptionId = community.subscription_id;
        communityForm._autopostResourceId = community.resource_id;
        content.append(communityForm);
        communityForm._autopostEdit = (item) => {
          editing = item.id;
          text.value = item.text || '';
          category.value = item.category;
          mediaIds.splice(0, mediaIds.length, ...(item.media || []).map((media) => ({ id: media.id, filename: media.filename })));
          if (schedule && item.scheduled_at && new Date(item.scheduled_at) > new Date()) {
            const date = new Date(item.scheduled_at);
            schedule.value = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
          }
          submit.textContent = item.status === 'draft' || item.status === 'rejected' ? 'Отправить' : 'Сохранить';
          drawMedia();
          communityForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
        };
      }
    }

    content.append(h('div', { class: 'h2' }, 'Мои объявления'));
    if (!own.items.length) {
      content.append(h('div', { class: 'card muted small' }, 'Вы ещё не отправляли объявления.'));
    } else {
      content.append(h('div', { class: 'card list' }, own.items.map((item) => {
        const matching = Array.from(content.querySelectorAll('.card.stack')).find((card) =>
          item.subscription_id !== null
            ? card._autopostSubscriptionId === item.subscription_id
            : card._autopostSubscriptionId === null && card._autopostResourceId === item.resource_id);
        const canEdit = ['draft', 'pending', 'approved', 'rejected', 'revision', 'scheduled'].includes(item.status);
        return h('div', { class: 'item', style: 'align-items:flex-start' },
          h('div', { class: 'grow', style: 'min-width:0' },
            h('div', { class: 'row wrap' }, h('b', {}, item.community),
              h('span', { class: `pill ${item.status === 'published' ? 'ok' : item.status === 'rejected' || item.status === 'failed' ? 'bad' : 'blue'}` },
                statusNames[item.status] || item.status)),
            h('div', { class: 'small', style: 'white-space:pre-wrap;overflow-wrap:anywhere;margin-top:5px' }, item.text),
            item.review_reason ? h('div', { class: 'note warn', style: 'margin-top:6px' }, item.review_reason) : null,
            h('div', { class: 'muted tiny', style: 'margin-top:5px' }, fmtDateTime(item.created_at)),
            item.media.length ? h('div', { class: 'muted tiny' }, item.media.map((media) => media.filename).join(' · ')) : null),
          canEdit && matching ? h('button', { class: 'btn sm', onclick: () => matching._autopostEdit(item) }, 'Изменить') : null,
          ['draft', 'pending', 'approved', 'scheduled', 'rejected', 'revision'].includes(item.status)
            ? h('button', { class: 'btn sm danger', onclick: async () => {
              if (!(await TG.confirm('Отменить объявление?'))) return;
              try { await api('DELETE', `/community-autopost/submissions/${item.id}`); toast('Объявление отменено'); show('tools'); }
              catch (e) { fail(e); }
            } }, 'Отменить') : null);
      })));
    }

    const groups = S.resources.filter((resource) => !resource.is_demo &&
      ['group', 'supergroup'].includes(resource.type) && resource.status === 'active');
    if (!groups.length || !canReview) return;
    content.append(h('div', { class: 'h2' }, 'Кабинет владельца'));
    for (const resource of groups) {
      const section = h('div', { class: 'card stack' }, h('b', {}, resource.title),
        h('div', { class: 'muted small' }, 'Загружаем настройки и очередь…'));
      content.append(section);
      try {
        const [settings, blocked] = await Promise.all([
          api('GET', `/communities/${resource.id}/autopost`),
          api('GET', `/community-autopost/owner/${resource.id}/blocked`),
        ]);
        let statusFilter = 'scheduled';
        const queue = h('div');
        const enabled = toolControl({ type: 'checkbox', checkLabel: 'Разрешить объявления' }, settings.enabled);
        const allowScheduling = toolControl({ type: 'checkbox', checkLabel: 'Разрешить участникам планировать публикации' }, settings.allow_scheduling);
        const allowLinks = toolControl({ type: 'checkbox', checkLabel: 'Разрешить ссылки' }, settings.allow_links);
        const maxLength = toolControl({ type: 'number' }, settings.max_text_length);
        maxLength.min = 1; maxLength.max = 4096;
        const maxPhotos = toolControl({ type: 'number' }, settings.max_photos);
        maxPhotos.min = 0; maxPhotos.max = 10;
        const dailyLimit = toolControl({ type: 'number' }, settings.daily_limit);
        dailyLimit.min = 0; dailyLimit.max = 1000;
        const monthlyLimit = toolControl({ type: 'number' }, settings.monthly_limit);
        monthlyLimit.min = 0; monthlyLimit.max = 10000;
        const interval = toolControl({ type: 'number' }, settings.min_interval_minutes);
        interval.min = 0; interval.max = 10080;
        const categoryChecks = settings.categories.map((item) => [
          item.id, toolControl({ type: 'checkbox', checkLabel: item.name },
            settings.allowed_categories.includes(item.id)),
        ]);
        const saveSettings = h('button', { class: 'btn primary', type: 'button' }, 'Сохранить правила');
        if (canManage) saveSettings.onclick = async (e) => busy(e.currentTarget, async () => {
          try {
            await api('PUT', `/communities/${resource.id}/autopost`, {
              enabled: enabled.querySelector('input').checked,
              allow_scheduling: allowScheduling.querySelector('input').checked,
              allow_links: allowLinks.querySelector('input').checked,
              max_text_length: Number(maxLength.value), max_photos: Number(maxPhotos.value),
              daily_limit: Number(dailyLimit.value), monthly_limit: Number(monthlyLimit.value),
              min_interval_minutes: Number(interval.value),
              allowed_categories: categoryChecks.filter(([, control]) => control.querySelector('input').checked)
                .map(([id]) => id),
            });
            toast('Правила автопостинга сохранены');
            show('tools');
          } catch (err) { fail(err); }
        });
        const settingsPanel = h('div', { class: 'stack' },
          canManage ? h('div', { class: 'stack' },
            enabled, allowScheduling, allowLinks,
            toolField('Максимальная длина текста', maxLength),
            toolField('Максимум фотографий (до 10)', maxPhotos),
            toolField('Максимум объявлений на одного участника за сутки (0 — без лимита)', dailyLimit),
            toolField('Максимум объявлений на одного участника за месяц (0 — без лимита)', monthlyLimit),
            toolField('Интервал между публикациями, минут (0 — без интервала)', interval),
            h('div', { class: 'small muted' }, 'Допустимые категории'),
            ...categoryChecks.map(([, control]) => control), saveSettings)
            : h('div', { class: 'note' }, 'Настройки доступны владельцу и администраторам рабочего пространства.'));
        const filter = h('select', { onchange: async () => loadQueue() },
          [['scheduled', 'Ожидают отправки'], ['', 'Вся история'], ['pending', 'Ожидают публикации (старые объявления)'],
            ['approved', 'Готово к публикации'],
            ['published', 'Опубликовано'], ['rejected', 'Отклонено'], ['revision', 'Нужно исправить'], ['failed', 'Ошибки']]
            .map(([value, label]) => h('option', { value }, label)));
        async function loadQueue() {
          clear(queue).append(h('div', { class: 'muted small' }, 'Загружаем очередь…'));
          try {
            const result = await api('GET', `/community-autopost/owner/${resource.id}` +
              (filter.value ? `?status=${encodeURIComponent(filter.value)}` : ''));
            clear(queue);
            const statNames = Object.keys(result.stats || {}).map((status) =>
              `${statusNames[status] || status}: ${result.stats[status]}`);
            if (statNames.length) queue.append(h('div', { class: 'muted tiny' }, statNames.join(' · ')));
            if (!result.items.length) {
              queue.append(h('div', { class: 'muted small' }, 'Объявлений в этом разделе нет.'));
              return;
            }
            queue.append(h('div', { class: 'card list' }, result.items.map((item) => {
              return h('div', { class: 'item', style: 'align-items:flex-start' },
                h('div', { class: 'grow', style: 'min-width:0' },
                  h('div', { class: 'row wrap' }, h('b', {}, item.author.first_name || `ID ${item.author.telegram_id}`),
                    h('span', { class: 'pill' }, statusNames[item.status] || item.status),
                    item.author.username ? h('span', { class: 'muted tiny' }, '@' + item.author.username) : null),
                  h('div', { class: 'muted tiny' }, `${item.category} · ${fmtDateTime(item.created_at)}`),
                  h('div', { class: 'small', style: 'white-space:pre-wrap;overflow-wrap:anywhere;margin-top:5px' }, item.text),
                  item.media.length ? h('div', { class: 'muted tiny' }, item.media.map((media) => media.filename).join(' · ')) : null,
                  item.review_reason ? h('div', { class: 'note warn', style: 'margin-top:5px' }, item.review_reason) : null,
                  h('div', { class: 'muted tiny', style: 'margin-top:5px' }, `Опубликовано ранее: ${item.author.published_count}`),
                  !blocked.items.some((entry) => entry.telegram_user_id === item.author.telegram_id)
                    ? h('button', { class: 'btn sm danger', style: 'margin-top:6px', onclick: async () => {
                      try {
                        await api('POST', `/community-autopost/owner/${resource.id}/blocked`, {
                          telegram_user_id: item.author.telegram_id, reason: 'Заблокирован из очереди объявлений',
                        });
                        toast('Участник заблокирован');
                        show('tools');
                      } catch (err) { fail(err); }
                    } }, 'Заблокировать автора') : null),
                h('span', { class: 'muted tiny' }, `#${item.id}`));
            })));
          } catch (err) { clear(queue).append(h('div', { class: 'note err' }, err.message)); }
        }
        const blockedPanel = h('div', { class: 'stack' });
        if (blocked.items.length) {
          blockedPanel.append(h('div', { class: 'small muted' }, 'Заблокированные участники'));
          blockedPanel.append(...blocked.items.map((item) => h('div', { class: 'row wrap' },
            h('span', { class: 'grow small' }, `${item.first_name || item.telegram_user_id} · ${item.reason || 'без причины'}`),
            canManage ? h('button', { class: 'btn sm', onclick: async () => {
              try { await api('DELETE', `/community-autopost/owner/${resource.id}/blocked/${item.telegram_user_id}`); show('tools'); }
              catch (err) { fail(err); }
            } }, 'Разблокировать') : null)));
        }
        clear(section).append(h('b', {}, resource.title), settingsPanel,
          h('div', { class: 'h2' }, 'Публикации участников'),
          h('label', { class: 'small muted' }, 'Показать', filter), queue, blockedPanel);
        await loadQueue();
      } catch (err) {
        clear(section).append(h('b', {}, resource.title),
          h('div', { class: 'note warn' }, `Кабинет объявлений недоступен: ${err.message}`));
      }
    }
  }

  function submissionKey() {
    return window.crypto && typeof window.crypto.randomUUID === 'function'
      ? window.crypto.randomUUID() : `mp${Date.now()}${Math.random().toString(36).slice(2)}`;
  }

  async function toolBilling(el) {
    await loadResources();
    const [catalog, subscriptions, owner] = await Promise.all([
      api('GET', '/marketplace/plans'), api('GET', '/community-subscriptions'), api('GET', '/owner/community-billing'),
    ]);
    const platformPayouts = owner.is_platform_admin ? await api('GET', '/platform/payouts') : null;
    const money = (minor) => (Number(minor || 0) / 100).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₽';
    const permissionOptions = [
      ['can_send_messages', 'Текстовые сообщения'],
      ['can_send_audios', 'Аудиофайлы'],
      ['can_send_documents', 'Документы и файлы'],
      ['can_send_photos', 'Фото'],
      ['can_send_videos', 'Видео'],
      ['can_send_video_notes', 'Видеосообщения'],
      ['can_send_voice_notes', 'Голосовые сообщения'],
      ['can_send_polls', 'Опросы'],
      ['can_send_other_messages', 'Стикеры, GIF и встроенные приложения'],
      ['can_add_web_page_previews', 'Предпросмотр ссылок'],
      ['can_invite_users', 'Приглашать участников'],
      ['can_pin_messages', 'Закреплять сообщения'],
      ['can_manage_topics', 'Управлять темами'],
      ['can_change_info', 'Изменять информацию группы'],
    ];
    const permissionNames = Object.fromEntries(permissionOptions);
    const autoRenew = h('input', { type: 'checkbox' });
    const checkoutMessages = {
      ready: 'Оплата только в рублях через YooKassa. Автопродление выключено по умолчанию. Telegram Stars пока не принимаются.',
      payments_disabled: 'Оплата временно отключена настройкой COMMUNITY_PAYMENTS_ENABLED.',
      billing_unavailable: 'Оплата недоступна: в .env не настроены YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY.',
      https_required: 'Оплата недоступна: PUBLIC_URL должен начинаться с https://.',
    };
    el.append(h('div', { class: 'note warn' }, checkoutMessages[catalog.checkout_reason] || checkoutMessages.payments_disabled),
      h('div', { class: 'h2' }, 'Сообщества'),
      catalog.checkout_enabled
        ? h('div', { class: 'setrow', style: 'margin-bottom:10px' }, h('label', { class: 'row' }, autoRenew, h('span', { class: 'small' }, 'Включить автопродление. Следующая оплата будет списана в дату окончания.')))
        : null,
      catalog.items.length ? h('div', { class: 'card list' }, catalog.items.map((plan) => h('div', { class: 'item' },
        h('div', { class: 'grow' }, h('b', {}, plan.community + ' · ' + plan.name), h('div', { class: 'muted small' },
          `${money(plan.amount_minor)} · ${plan.duration_days} дней${plan.max_members ? ' · мест: ' + plan.max_members : ''}`),
          plan.permissions && plan.permissions.max_messages_per_day
            ? h('div', { class: 'small' }, `Лимит участника: ${plan.permissions.max_messages_per_day} сообщений в сутки`)
            : null,
          h('div', { class: 'small' }, plan.permissions && plan.permissions.autopost
            ? 'Включён автопост объявлений' : 'Автопост объявлений не входит в тариф'),
          h('div', { class: 'small' }, permissionOptions.some(([key]) => key in (plan.permissions || {}))
            ? 'Разрешено: ' + permissionOptions.filter(([key]) => plan.permissions[key]).map(([, label]) => label).join(', ')
            : 'Действуют права группы по умолчанию.'),
          plan.description ? h('div', { class: 'small' }, plan.description) : null),
        h('button', { class: 'btn sm primary', disabled: !catalog.checkout_enabled, onclick: async (e) => busy(e.currentTarget, async () => {
          try {
            const result = await api('POST', `/community-plans/${plan.id}/checkout`, { auto_renew: autoRenew.checked });
            if (result.payment.confirmation_url) TG.openLink(result.payment.confirmation_url);
            else if (result.payment.status === 'succeeded') toast('Платёж подтверждён');
            else toast('Проверяем статус платежа. Повторно оплачивать пока не нужно.');
          } catch (err) { fail(err); }
        }) }, 'Оплатить')))) : h('div', { class: 'card muted small' }, 'Активных тарифов пока нет.'),
      h('div', { class: 'h2' }, 'Мои подписки'),
      subscriptions.items.length ? h('div', { class: 'card list' }, subscriptions.items.map((sub) => h('div', { class: 'item' },
        h('div', { class: 'grow' }, h('b', {}, sub.community + ' · ' + sub.plan), h('div', { class: 'muted small' },
          `${sub.status} · ${money(sub.price)} · до ${fmtDateTime(sub.ends_at)}`),
          h('div', { class: 'small' }, sub.auto_renew ? 'Автопродление включено' : 'Автопродление выключено')),
        sub.auto_renew ? h('button', { class: 'btn sm', onclick: async () => {
          try { await api('POST', `/community-subscriptions/${sub.id}/cancel`); toast('Автопродление отменено'); await show('tools'); }
          catch (err) { fail(err); }
        } }, 'Отключить') : null,
        ['active', 'cancelled'].includes(sub.status) ? h('button', { class: 'btn sm danger', onclick: async () => {
          if (!(await TG.confirm('Отправить владельцу запрос на полный возврат? После подтверждения возврата доступ отключится.'))) return;
          try { await api('POST', `/community-subscriptions/${sub.id}/refunds`, { reason: 'Запрос покупателя' }); toast('Запрос отправлен владельцу'); await show('tools'); }
          catch (err) { fail(err); }
        } }, 'Запросить возврат') : null))) : h('div', { class: 'card muted small' }, 'У вас пока нет подписок.'),
      h('div', { class: 'h2' }, 'Кабинет владельца'),
      h('div', { class: 'kpis' }, [
        ['sale', 'Оборот'], ['commission', 'Комиссия'], ['payout', 'Выплачено'],
        ].map(([kind, label]) => h('div', { class: 'kpi' }, h('div', { class: 'v' }, money(kind === 'payout'
          ? owner.payouts.paid_minor
          : Math.abs((owner.ledger.find((entry) => entry.kind === kind) || {}).amount_minor || 0))), h('div', { class: 'l' }, label)))),
        h('div', { class: 'muted small', style: 'margin-bottom:10px' }, `К выплате вручную: ${money(owner.payouts.pending_minor)}. Платформа удерживает комиссию 1,5%; перевод владельцу выполняется вручную после оплаты.`),
        owner.payouts.recovery_minor
          ? h('div', { class: 'note warn' }, `Требует сверки после возврата уже выплаченного платежа: ${money(owner.payouts.recovery_minor)}.`)
          : null,
      h('div', { class: 'h2' }, 'Покупатели'),
      owner.subscriptions.length ? h('div', { class: 'card list' }, owner.subscriptions.map((sub) => h('div', { class: 'item' },
        h('div', { class: 'grow' }, h('b', {}, sub.community + ' · ' + sub.plan),
          h('div', { class: 'muted small' }, `${sub.first_name || 'Участник'}${sub.username ? ' · @' + sub.username : ''} · ${sub.status}`),
          h('div', { class: 'small' }, `Привилегии тарифа до ${fmtDateTime(sub.ends_at)} · автопродление ${sub.auto_renew ? 'вкл.' : 'выкл.'}`))))):
        h('div', { class: 'card muted small' }, 'Покупателей пока нет.'),
      owner.refunds.filter((refund) => refund.status === 'requested').length ? h('div', { class: 'card list' }, owner.refunds.filter((refund) => refund.status === 'requested').map((refund) => h('div', { class: 'item' },
        h('div', { class: 'grow' }, h('b', {}, refund.community + ' · ' + refund.plan), h('div', { class: 'muted small' }, `${money(refund.amount_minor)} · ${refund.reason || 'без комментария'}`)),
        h('button', { class: 'btn sm primary', onclick: async () => { try { await api('POST', `/community-refunds/${refund.id}/approve`); toast('Возврат отправлен в YooKassa'); await show('tools'); } catch (err) { fail(err); } } }, 'Вернуть'),
        h('button', { class: 'btn sm', onclick: async () => { try { await api('POST', `/community-refunds/${refund.id}/reject`); toast('Запрос отклонён'); await show('tools'); } catch (err) { fail(err); } } }, 'Отклонить')))) : null);

    el.append(h('div', { class: 'card' },
      h('b', {}, 'Настройка выплат владельцу'),
      h('ol', { class: 'small', style: 'padding-left:20px;line-height:1.6' },
        h('li', {}, 'Укажите номер телефона, привязанный к СБП, и банк для получения ручных переводов.'),
        h('li', {}, 'Для индивидуальных привилегий переведите обычную группу в супергруппу в Telegram. Бот обновит подключённый ресурс после сообщения о миграции.'),
        h('li', {}, 'Выберите активную группу или супергруппу и сохраните реквизиты. Участники могут вступать в группу бесплатно.'),
        h('li', {}, 'Настройте стандартные права группы — они действуют для всех участников. В тарифе можно отдельно задать привилегии подписчика (для супергрупп), дневной лимит сообщений и доступ подписчиков к объявлениям.'),
        h('li', {}, 'Создайте тариф: укажите название, описание, цену в рублях, срок, лимит участников и нужные функции, включая автопост объявлений.'),
        h('li', {}, 'Убедитесь, что бот — администратор группы с правом ограничивать участников. Право приглашать нужно только для закрытой группы.')),
      h('div', { class: 'note warn', style: 'margin-top:10px' },
        'Укажите телефон, привязанный к СБП, и банк для ручного перевода. Эти реквизиты доступны владельцу и администратору платформы. Платежи покупателей поступают на счёт платформы; перевод владельцу выполняется вручную за вычетом комиссии 1,5%. В публичной группе тариф даёт привилегии, но не закрывает вход: после окончания тарифа участник остаётся в группе с её обычными правами. Права тарифа не могут быть шире прав группы.')));

    if (platformPayouts) {
      el.append(h('div', { class: 'h2' }, 'Ручные выплаты владельцам'),
        platformPayouts.items.length
          ? h('div', { class: 'card list' }, platformPayouts.items.map((payout) => {
            const reference = h('input', { maxlength: 120, placeholder: 'Комментарий или номер перевода (необязательно)' });
            return h('div', { class: 'item' },
              h('div', { class: 'grow' },
                h('b', {}, `${payout.community} · ${payout.plan}`),
                h('div', { class: 'muted small' }, `${payout.owner_name}${payout.owner_username ? ' · @' + payout.owner_username : ''}`),
                h('div', { class: 'small' }, `${payout.payout_phone} · ${payout.payout_bank}`),
                h('div', { class: 'small' }, `Получено ${money(payout.sale_amount)} · комиссия ${money(payout.commission_minor)} · перевести ${money(payout.amount_minor)}`),
                !payout.payout_phone || !payout.payout_bank
                  ? h('div', { class: 'note warn' }, 'Владелец ещё не указал реквизиты для перевода.')
                  : null,
                payout.status === 'recovery_required' ? h('div', { class: 'note err' }, 'Платёж возвращён после выплаты владельцу; требуется ручная сверка.') : null),
              payout.status === 'pending'
                ? h('div', { class: 'col' }, reference, h('button', { class: 'btn sm primary',
                  disabled: !payout.payout_phone || !payout.payout_bank, onclick: async (e) => busy(e.currentTarget, async () => {
                  try {
                    await api('POST', `/platform/payouts/${payout.payout_id}/paid`, { transfer_reference: reference.value });
                    toast('Перевод отмечен выплаченным');
                    await show('tools');
                  } catch (err) { fail(err); }
                }) }, 'Отметить перевод выполненным'))
                : null);
          }))
          : h('div', { class: 'card muted small' }, 'Ожидающих выплат нет.'));
    }

    const resources = S.resources.filter((resource) => !resource.is_demo && resource.status === 'active');
    if (!resources.length) return;
    const resourceSelect = h('select', {}, resources.map((resource) => h('option', { value: resource.id }, resource.title)));
    const groupPermissionControls = Object.fromEntries(permissionOptions.map(([key]) => [
      key, toolControl({ type: 'checkbox', checkLabel: permissionNames[key] }, true),
    ]));
    const groupAutopostControl = toolControl({ type: 'checkbox',
      checkLabel: 'Разрешить объявления подписчикам тарифов' }, true);
    const groupPermissionsBox = h('div', { class: 'card flat' },
      h('b', {}, 'Стандартные права группы'),
      h('div', { class: 'muted small', style: 'margin:4px 0 8px' },
        'Эти разрешения Telegram применит ко всем участникам группы, а не только к подписчикам. Работает для обычных групп и супергрупп.'),
      permissionOptions.map(([key]) => groupPermissionControls[key]),
      h('button', { class: 'btn primary block', style: 'margin-top:8px', onclick: async (e) => busy(e.currentTarget, async () => {
        try {
          const permissions = Object.fromEntries(permissionOptions.map(([key]) => [
            key, groupPermissionControls[key].querySelector('input').checked,
          ]));
          await api('PUT', `/communities/${resourceSelect.value}/permissions`, { permissions });
          toast('Стандартные права группы обновлены');
        } catch (err) { fail(err); }
      }) }, 'Применить права ко всей группе'),
      h('hr'),
      h('div', { class: 'muted small', style: 'margin:4px 0 8px' },
        'Это общее разрешение сообщества. Объявления будут доступны только подписчикам тарифов, где автопост также включён.'),
      groupAutopostControl,
      h('button', { class: 'btn block', style: 'margin-top:8px', onclick: async (e) => busy(e.currentTarget, async () => {
        try {
          await api('PUT', `/communities/${resourceSelect.value}/autopost`,
            { enabled: groupAutopostControl.querySelector('input').checked });
          toast('Общее разрешение автопоста обновлено');
        } catch (err) { fail(err); }
      }) }, 'Сохранить общее разрешение'));
    const payoutPhone = h('input', { type: 'tel', inputmode: 'tel', placeholder: '+7 900 000-00-00' });
    const payoutBank = h('input', { maxlength: 80, placeholder: 'Например, Сбербанк' });
    const merchantState = h('span', { class: 'pill' }, 'Не подключён');
    const connect = h('button', { class: 'btn sm' }, 'Сохранить реквизиты');
    const planList = h('div');
    async function refreshOwner() {
      try {
        const selectedResource = resources.find((resource) => String(resource.id) === resourceSelect.value);
        const supportsGroupPermissions = ['group', 'supergroup'].includes(selectedResource?.type);
        const [merchant, billing, chatPermissions, autopostSettings] = await Promise.all([
          api('GET', `/communities/${resourceSelect.value}/merchant`), api('GET', '/owner/community-billing'),
          supportsGroupPermissions
            ? api('GET', `/communities/${resourceSelect.value}/permissions`)
            : Promise.resolve(null),
          supportsGroupPermissions
            ? api('GET', `/communities/${resourceSelect.value}/autopost`)
            : Promise.resolve(null),
        ]);
        if (chatPermissions) permissionOptions.forEach(([key]) => {
          groupPermissionControls[key].querySelector('input').checked = chatPermissions.permissions[key] !== false;
        });
        if (autopostSettings) {
          groupAutopostControl.querySelector('input').checked = autopostSettings.enabled;
        }
        groupPermissionsBox.hidden = !supportsGroupPermissions;
        payoutPhone.value = merchant.payout_phone || '';
        payoutBank.value = merchant.payout_bank || '';
        merchantState.textContent = merchant.status;
        merchantState.className = 'pill ' + (merchant.status === 'active' ? 'ok' : 'warn');
        clear(planList).append(billing.plans.filter((plan) => String(plan.resource_id) === resourceSelect.value).map((plan) => h('div', { class: 'item' },
          h('div', { class: 'grow' }, h('b', {}, plan.name), h('div', { class: 'muted small' }, `${money(plan.amount_minor)} · ${plan.duration_days} дней · ${plan.active ? 'активен' : 'выключен'}`),
            h('div', { class: 'small' }, `${Object.values(plan.permissions || {}).filter((value) => value === true).length} прав Telegram`),
                plan.permissions && plan.permissions.max_messages_per_day
                  ? h('div', { class: 'small' }, `Лимит сообщений: ${plan.permissions.max_messages_per_day} в сутки`)
                  : null,
            h('div', { class: 'small' }, plan.permissions && plan.permissions.autopost
              ? 'Автопост объявлений включён' : 'Автопост объявлений выключен')),
          h('button', { class: 'btn sm', onclick: () => editPlan(plan) }, 'Изменить'),
          h('button', { class: 'btn sm', onclick: async () => { try { await api('PUT', `/community-plans/${plan.id}`, { active: !plan.active }); await refreshOwner(); } catch (err) { fail(err); } } }, plan.active ? 'Выключить' : 'Включить'))));
      } catch (err) { fail(err); }
    }
    resourceSelect.onchange = refreshOwner;
    connect.onclick = async () => { try { const result = await api('PUT', `/communities/${resourceSelect.value}/merchant`, { payout_phone: payoutPhone.value, payout_bank: payoutBank.value }); merchantState.textContent = result.status; toast('Реквизиты сохранены'); await refreshOwner(); } catch (err) { fail(err); } };
    function editPlan(plan) {
      const supportsMemberPermissions = resources.find((resource) => String(resource.id) === resourceSelect.value)?.type === 'supergroup';
      const name = h('input', { maxlength: 80, placeholder: 'Название тарифа', value: plan ? plan.name : '' });
      const description = h('textarea', { rows: 2, maxlength: 500, placeholder: 'Описание доступа' });
      description.value = plan ? plan.description : '';
      const price = h('input', { type: 'number', min: 1, step: '0.01', placeholder: 'Цена, ₽', value: plan ? plan.amount_minor / 100 : '' });
      const days = h('input', { type: 'number', min: 1, max: 3650, value: plan ? plan.duration_days : 30 });
      const members = h('input', { type: 'number', min: 1, placeholder: 'Без лимита', value: plan && plan.max_members ? plan.max_members : '' });
      const messageQuota = h('input', { type: 'number', min: 1, max: 10000, placeholder: 'Без лимита',
        value: plan && plan.permissions && plan.permissions.max_messages_per_day
          ? plan.permissions.max_messages_per_day : '' });
      const rights = Object.fromEntries(permissionOptions.map(([key]) => [
        key, toolControl({ type: 'checkbox', checkLabel: permissionNames[key] },
          plan ? (plan.permissions || {})[key] !== false : true),
      ]));
      const autopost = toolControl({ type: 'checkbox', checkLabel: 'Разрешить участникам отправлять объявления' },
        plan ? (plan.permissions || {}).autopost !== false : true);
      const rightsBox = supportsMemberPermissions
        ? h('div', { class: 'card flat' },
          h('b', {}, 'Привилегии участника Telegram'),
          h('div', { class: 'muted small', style: 'margin:4px 0 8px' },
            'Снимите отметку, чтобы запретить действие. Выбранные возможности должны быть разрешены настройками самой группы.'),
          permissionOptions.map(([key]) => rights[key]))
        : h('div', { class: 'note warn' }, 'Для индивидуальных прав переведите группу в супергруппу в Telegram. Бот не может выполнить перевод, но обновит подключённый ресурс, когда получит уведомление о миграции.');
      toolForm(plan ? 'Изменить тариф' : 'Новый тариф сообщества', [
        toolField('Название', name), toolField('Описание', description), toolField('Цена, ₽', price),
        toolField('Срок, дней', days), toolField('Максимум участников', members),
        toolField('Сообщений участнику в сутки (превышение удаляется)', messageQuota),
        h('div', { class: 'muted small' }, 'Лимит считается отдельно для каждого платного участника; пустое поле — без лимита. Администраторы группы не ограничиваются.'),
        h('div', { class: 'card flat' }, h('b', {}, 'Функции тарифа'),
          h('div', { class: 'muted small', style: 'margin:4px 0 8px' },
            'Если отключить автопост, подписчики этого тарифа не смогут отправлять объявления в сообщество.'),
          autopost),
        rightsBox,
      ], async () => {
        const quota = messageQuota.value ? Number(messageQuota.value) : null;
        if (quota !== null && (!Number.isInteger(quota) || quota < 1 || quota > 10000)) {
          throw new Error('Лимит сообщений должен быть от 1 до 10000 или пустым');
        }
        const payload = {
          name: name.value, description: description.value,
          amount_minor: Math.round(Number(price.value) * 100), duration_days: Number(days.value),
          max_members: members.value ? Number(members.value) : null,
          permissions: {
            ...(supportsMemberPermissions
              ? Object.fromEntries(permissionOptions.map(([key]) => [key, rights[key].querySelector('input').checked]))
              : {}),
            autopost: autopost.querySelector('input').checked,
            max_messages_per_day: quota,
          },
        };
        await api(plan ? 'PUT' : 'POST',
          plan ? `/community-plans/${plan.id}` : `/communities/${resourceSelect.value}/plans`, payload);
        await refreshOwner();
      });
    }
    const createPlan = h('button', { class: 'btn primary block' }, 'Создать тариф');
    createPlan.onclick = () => editPlan(null);
    el.append(h('div', { class: 'card' }, h('div', { class: 'setrow' }, resourceSelect, merchantState),
      toolField('Телефон владельца для перевода через СБП', payoutPhone),
      toolField('Банк владельца', payoutBank),
      h('div', { class: 'muted small', style: 'margin:-8px 0 10px' }, 'Реквизиты сохраняются в приложении и видны владельцу и администратору платформы. Платёж покупателя поступает на счёт платформы; владелец получает ручной перевод за вычетом комиссии 1,5%.'),
      h('div', { class: 'row wrap' }, connect, createPlan)),
      h('div', { class: 'card' }, groupPermissionsBox),
      h('div', { class: 'card list', style: 'margin-top:8px' }, planList));
    await refreshOwner();
  }

  async function toolExport(el) {
    const kinds = [['resources', 'Ресурсы'], ['posts', 'Публикации'], ['moderation', 'Модерация'], ['ads', 'Кампании']];
    el.append(h('div', { class: 'card' }, h('b', {}, 'Экспорт данных'), h('div', { class: 'muted small', style: 'margin:6px 0 12px' }, 'Сформируйте CSV-файл для выбранного раздела. Доступ зависит от тарифа.')));
    kinds.forEach(([kind, label]) => {
      const result = h('div', { class: 'row wrap', style: 'margin-top:8px' });
      const button = h('button', { class: 'btn' }, `Подготовить: ${label}`);
      button.onclick = (e) => busy(e.currentTarget, async () => {
        try {
          const data = await api('GET', `/export?kind=${encodeURIComponent(kind)}`);
          const headers = data.items.length ? Object.keys(data.items[0]) : [];
          const quote = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
          const csv = [headers.map(quote).join(','), ...data.items.map((row) => headers.map((key) => quote(row[key])).join(','))].join('\r\n');
          const url = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
          clear(result).append(h('span', { class: 'pill ok' }, `${data.count} строк`), h('a', { class: 'btn sm primary', href: url, download: data.filename }, 'Скачать CSV'));
        } catch (err) { fail(err); }
      });
      el.append(h('div', { class: 'card row wrap' }, h('span', { class: 'grow' }, label), button, result));
    });
  }

  // ================================================================ NOTIFICATIONS
  VIEWS.notifications = async (el) => {
    const r = await api('GET', '/notifications?limit=60');
    el.append(h('div', { class: 'row', style: 'margin-bottom:14px' }, h('h1', { class: 'title' }, 'Уведомления'), r.unread ? h('span', { class: 'pill blue' }, r.unread + ' новых') : null,
      h('button', { class: 'btn sm right', disabled: !r.unread, onclick: async (e) => busy(e.currentTarget, async () => { try { await api('POST', '/notifications/read'); S.unread = 0; renderNav(); renderHeader(); toast('Всё прочитано'); show('notifications'); } catch (err) { fail(err); } }) }, 'Прочитать все')));
    if (!r.items.length) el.append(empty('🔔', 'Пока тихо', 'Здесь появятся события: публикации, ошибки, изменения прав бота.'));
    else {
      const today = MP.todayKey(), yesterday = MP.addDays(today, -1), groups = new Map();
      r.items.forEach((n) => { const k = MP.dayKey(n.created_at, MP.state.tz); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(n); });
      groups.forEach((items, k) => el.append(h('div', { class: 'h2' }, k === today ? 'Сегодня' : k === yesterday ? 'Вчера' : MP.fmtDay(k)),
        h('div', { class: 'card list' }, items.map((n) => noteItem(n, () => { TG.haptic('select'); if (n.kind.startsWith('resource') || n.kind === 'rights_changed') goWork('resources'); else goWork('posts', n.kind === 'published' ? 'published' : n.kind === 'publish_unknown' ? 'unknown' : 'failed'); })))));
    }
    el.append(h('div', { class: 'h2' }, 'Доставка в Telegram'), h('div', { class: 'card' },
      h('div', { class: 'setrow' }, h('div', { class: 'grow' }, h('b', {}, 'Уведомления в чат с ботом'), h('div', { class: 'muted small' }, 'Ошибки публикаций, потеря прав, отключение ресурсов')), switchEl(r.notify, async (v) => { adopt(await api('PUT', '/me', { notify: v })); toast(v ? 'Уведомления включены' : 'Уведомления выключены'); })),
      h('div', { class: 'setrow' }, h('div', { class: 'grow muted small' }, 'Проверить, что сообщения доходят'), h('button', { class: 'btn sm', onclick: (e) => busy(e.currentTarget, async () => { try { const x = await api('POST', '/me/test-notification'); x.sent ? toast('Тестовое уведомление отправлено в чат') : toast(x.reason, true); } catch (err) { fail(err); } }) }, 'Отправить тест'))));
    // mark as read shortly after the list is on screen
    if (r.unread) setTimeout(() => {
      if (S.tab !== 'notifications') return;
      api('POST', '/notifications/read').then(() => {
        S.unread = 0; renderNav(); renderHeader();
        if (S.tab === 'notifications') show('notifications');
      }).catch(() => {});
    }, 2500);
  };
  function switchEl(checked, onchange) {
    return h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked, onchange: async (e) => { TG.haptic('select'); const box = e.target, v = box.checked; box.disabled = true; try { await onchange(v); } catch (err) { box.checked = !v; fail(err); } box.disabled = false; } }), h('i'));
  }

  // ================================================================ PROFILE
  VIEWS.profile = async (el) => {
    const [u] = await Promise.all([api('GET', '/me'), loadResources()]); adopt(u);
    const tgu = TG.user, photo = tgu && tgu.photo_url, bot = botLink();
    const pct = Math.min(100, Math.round((u.resources_used / (u.resource_limit || 1)) * 100));
    const since = new Intl.DateTimeFormat(MP.state.lang === 'en' ? 'en-US' : 'ru-RU', { timeZone: MP.state.tz, day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(u.created_at));
    el.append(h('div', { class: 'card', style: 'text-align:center;padding:24px 16px' },
      h('div', { class: 'avatar', style: 'width:88px;height:88px;font-size:36px;margin:0 auto 12px' }, photo ? h('img', { src: photo, alt: '', referrerpolicy: 'no-referrer', onerror: (e) => e.target.remove() }) : (u.first_name || '?').slice(0, 1).toUpperCase()),
      h('h1', { class: 'title', style: 'font-size:22px' }, u.first_name || '—'), u.username ? h('div', { class: 'muted' }, '@' + u.username) : null,
      h('div', { style: 'margin-top:10px' }, h('span', { class: 'pill blue' }, 'Тариф ' + MP.planLabel(u.plan)), u.is_demo ? ' ' : null, u.is_demo ? demoPill() : null)),
      h('div', { class: 'kpis' }, [[u.resources_used, 'Ресурсов'], [u.posts_total, 'Постов'], [u.published_total, 'Опубликовано']].map(([v, l]) => h('div', { class: 'kpi' }, h('div', { class: 'v' }, fmtNum(v)), h('div', { class: 'l' }, l)))),
      h('div', { class: 'h2' }, 'Тариф и лимиты'), h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, 'Ресурсы'), h('span', { class: 'right muted' }, `${u.resources_used} из ${u.resource_limit}`)), h('div', { class: 'bar', style: 'margin:10px 0' }, h('i', { style: `width:${pct}%` })),
        h('button', { class: 'btn primary', style: 'margin-top:10px', onclick: () => openSheet({ title: 'Тарифы', full: true, body: MP.tariffPanel((url) => TG.openLink(url)) }) }, 'Тарифы и оплата')),
      h('div', { class: 'h2' }, 'Аккаунт'), h('div', { class: 'card list' },
        [['Telegram ID', u.telegram_id ? String(u.telegram_id) : '—'], ['В MarketPilot с', since], ['Часовой пояс', u.timezone], ['Язык', u.language === 'en' ? 'English' : 'Русский']].map(([a, b]) => h('div', { class: 'item', style: 'align-items:center' }, h('span', { class: 'muted' }, a), h('b', { class: 'right', style: 'text-align:right;word-break:break-all' }, b)))),
      h('div', { class: 'h2' }, 'Действия'), h('div', { class: 'col' },
        h('button', { class: 'btn', onclick: () => show('settings') }, '⚙️ Настройки аккаунта'),
        bot ? h('button', { class: 'btn', onclick: () => TG.openTelegramLink('https://t.me/' + bot) }, '💬 Открыть чат с ботом') : null,
        bot ? h('button', { class: 'btn', onclick: () => TG.openTelegramLink('https://t.me/share/url?url=' + encodeURIComponent('https://t.me/' + bot) + '&text=' + encodeURIComponent('MarketPilot — управление Telegram-каналами и группами')) }, '📤 Поделиться ботом') : null,
        S.status.miniapp_url ? h('button', { class: 'btn', onclick: () => TG.openLink(new URL(S.status.miniapp_url).origin) }, '🖥 Открыть веб-версию') : null));
  };

  // ================================================================ SETTINGS
  async function renderWorkspaceSettings(el) {
    MP.state.workspaces = (await api('GET', '/workspaces')).items;
    const active = MP.state.workspaces.find((item) => item.id === Number(MP.state.workspaceId)) || MP.state.workspaces[0];
    if (!active) return;
    MP.state.workspaceId = active.id;
    const members = (await api('GET', `/workspaces/${active.id}/members`)).items;
    const canManage = ['owner', 'admin'].includes(active.role);
    const section = [h('div', { class: 'h2' }, 'Рабочее пространство'),
      h('div', { class: 'card' },
        h('div', { class: 'setrow' }, h('div', { class: 'grow' }, h('b', {}, 'Активное пространство')),
          h('select', { value: active.id, onchange: (e) => {
            MP.state.workspaceId = Number(e.target.value);
            try { localStorage.setItem('mp_workspace_' + S.user.id, String(MP.state.workspaceId)); } catch (err) { /* storage may be blocked */ }
            show('settings');
          } }, MP.state.workspaces.map((item) => h('option', { value: item.id, selected: item.id === active.id }, `${item.name} · ${item.role}`))))),
      h('div', { class: 'h2' }, 'Команда'),
      h('div', { class: 'card list' }, members.map((member) => {
        const isOwner = member.role === 'owner';
        const canEdit = canManage && !isOwner && (active.role === 'owner' || member.role !== 'admin');
        const roleControl = canEdit ? h('select', { value: member.role, onchange: async (e) => {
          try { await api('PUT', `/workspaces/${active.id}/members/${member.user_id}`, { role: e.target.value }); toast('Роль обновлена'); show('settings'); }
          catch (err) { e.target.value = member.role; fail(err); }
        } }, (active.role === 'owner' ? ['admin', 'moderator', 'viewer'] : ['moderator', 'viewer']).map((role) => h('option', { value: role, selected: member.role === role }, role))) : h('span', { class: 'pill' }, member.role);
        const canRemove = canManage && !isOwner && member.user_id !== S.user.id && (active.role === 'owner' || member.role !== 'admin');
        return h('div', { class: 'item' }, h('div', { class: 'grow' }, h('b', {}, member.first_name || `User ${member.user_id}`),
          h('div', { class: 'muted small' }, member.username ? '@' + member.username : `ID ${member.user_id}`)), roleControl,
          canRemove ? h('button', { class: 'btn sm danger', title: 'Отозвать доступ', onclick: async () => {
            if (!(await TG.confirm('Отозвать доступ этому участнику?'))) return;
            try { await api('DELETE', `/workspaces/${active.id}/members/${member.user_id}`); toast('Доступ отозван'); show('settings'); }
            catch (err) { fail(err); }
          } }, 'Удалить') : null);
      }))];

    if (canManage) {
      const invitations = (await api('GET', `/workspaces/${active.id}/invitations`)).items;
      const roleOptions = active.role === 'owner' ? ['admin', 'moderator', 'viewer'] : ['moderator', 'viewer'];
      const roleSelect = h('select', {}, roleOptions.map((role) => h('option', { value: role }, role)));
      const expirySelect = h('select', {}, [[24, '24 часа'], [72, '3 дня'], [168, '7 дней']].map(([value, label]) => h('option', { value }, label)));
      const inviteOutput = h('div');
      const createInvite = h('button', { class: 'btn primary' }, 'Создать приглашение');
      createInvite.onclick = (e) => busy(e.currentTarget, async () => {
        try {
          const invite = await api('POST', `/workspaces/${active.id}/invitations`,
            { role: roleSelect.value, expires_in_hours: Number(expirySelect.value) });
          const link = invite.invite_url || invite.token;
          clear(inviteOutput).append(h('div', { class: 'row wrap' }, h('input', { class: 'grow', value: link, readonly: true, 'aria-label': 'Ссылка-приглашение' }),
            h('button', { class: 'btn sm', onclick: async () => { if (await TG.copy(link)) toast('Ссылка скопирована'); else fail(new Error('Не удалось скопировать ссылку')); } }, 'Копировать')));
          toast('Приглашение создано');
        } catch (err) { fail(err); }
      });
      section.push(h('div', { class: 'h2' }, 'Приглашения'), h('div', { class: 'card' },
        h('div', { class: 'setrow' }, h('label', { class: 'grow' }, h('span', { class: 'small' }, 'Роль'), roleSelect),
          h('label', {}, h('span', { class: 'small' }, 'Срок'), expirySelect)), createInvite, inviteOutput,
        invitations.length ? h('div', { class: 'list', style: 'margin-top:12px' }, invitations.map((invite) => h('div', { class: 'item' },
          h('div', { class: 'grow' }, h('b', {}, invite.role), h('div', { class: 'muted small' }, `Истекает ${fmtDateTime(invite.expires_at)}`)),
          h('button', { class: 'btn sm danger', onclick: async () => {
            try { await api('DELETE', `/workspaces/${active.id}/invitations/${invite.id}`); toast('Приглашение отозвано'); show('settings'); }
            catch (err) { fail(err); }
          } }, 'Отозвать')))) : null));
    } else if (active.role !== 'owner') {
      section.push(h('button', { class: 'btn block', style: 'margin-top:12px', onclick: async () => {
        if (!(await TG.confirm('Покинуть это рабочее пространство?'))) return;
        try { await api('DELETE', `/workspaces/${active.id}/members/me`); await loadWorkspaces(); show('settings'); }
        catch (err) { fail(err); }
      } }, 'Покинуть пространство'));
    }
    el.append(...section);
  }

  VIEWS.settings = async (el) => {
    const u = await api('GET', '/me'); adopt(u);
    await renderWorkspaceSettings(el);
    const hasDemo = (await loadResources(), S.resources.some((r) => r.is_demo));
    const tzs = (typeof Intl.supportedValuesOf === 'function' ? Intl.supportedValuesOf('timeZone') : ['Europe/Moscow', 'Europe/Kiev', 'Asia/Almaty', 'Europe/London', 'America/New_York']).slice();
    if (!tzs.includes('UTC')) tzs.unshift('UTC'); if (!tzs.includes(u.timezone)) tzs.unshift(u.timezone);
    const save = async (patch, msg) => { try { adopt(await api('PUT', '/me', patch)); toast(msg || 'Сохранено'); return true; } catch (e) { fail(e); return false; } };
    const tzSel = h('select', { onchange: (e) => save({ timezone: e.target.value }, 'Часовой пояс сохранён') }, tzs.map((z) => h('option', { value: z, selected: z === u.timezone }, z)));
    const themeSeg = h('div', { class: 'seg' });
    const drawTheme = () => clear(themeSeg).append([['tg', 'Как в Telegram'], ['light', 'Светлая'], ['dark', 'Тёмная']].map(([v, l]) => h('button', { class: prefs.theme === v ? 'on' : '', onclick: () => { prefs.theme = v; savePrefs(); applyPrefs(); drawTheme(); TG.haptic('select'); } }, l)));
    drawTheme();
    el.append(h('h1', { class: 'title', style: 'margin-bottom:6px' }, t('Настройки')),
      h('div', { class: 'h2' }, 'Основное'), h('div', { class: 'card' },
        h('div', { class: 'setrow' }, h('div', { class: 'grow' }, h('b', {}, 'Язык')), h('select', { onchange: async (e) => { if (await save({ language: e.target.value }, 'Язык сохранён')) enter(), (S.tab = 'settings'), show('settings'); } }, [['ru', 'Русский'], ['en', 'English']].map(([v, l]) => h('option', { value: v, selected: v === u.language }, l)))),
        h('div', { class: 'setrow' }, h('div', { class: 'grow' }, h('b', {}, 'Часовой пояс'), h('div', { class: 'muted small' }, 'Для расписания и дат')), tzSel),
        h('div', { class: 'setrow' }, h('div', { class: 'grow muted small' }, 'Определить по устройству'), h('button', { class: 'btn sm', onclick: async () => { const z = Intl.DateTimeFormat().resolvedOptions().timeZone; if (z && await save({ timezone: z }, 'Часовой пояс: ' + z)) show('settings'); } }, 'Определить'))),
      h('div', { class: 'h2' }, 'Оформление'), h('div', { class: 'card' }, themeSeg, h('div', { class: 'setrow', style: 'margin-top:8px' }, h('div', { class: 'grow' }, h('b', {}, 'Вибро-отклик'), h('div', { class: 'muted small' }, 'Тактильные подтверждения действий')), switchEl(prefs.haptics, async (v) => { prefs.haptics = v; savePrefs(); applyPrefs(); if (v) TG.haptic('success'); }))),
      h('div', { class: 'h2' }, 'Уведомления'), h('div', { class: 'card' }, h('div', { class: 'setrow' }, h('div', { class: 'grow' }, h('b', {}, 'Уведомления в Telegram'), h('div', { class: 'muted small' }, 'Ошибки публикаций и потеря прав бота')), switchEl(u.notify, async (v) => { const ok = await save({ notify: v }, v ? 'Уведомления включены' : 'Уведомления выключены'); if (!ok) throw new Error('не удалось сохранить'); }))),
      h('div', { class: 'h2' }, 'Данные'), h('div', { class: 'card' }, h('div', { class: 'muted small', style: 'margin-bottom:10px' }, 'Демо-ресурсы помечены DEMO: публикации в них имитируются, в Telegram ничего не уходит.'),
        u.is_demo ? h('button', { class: 'btn block', onclick: async (e) => { if (await TG.confirm('Сбросить демо-аккаунт к исходным данным?')) busy(e.currentTarget, async () => { try { await api('POST', '/me/reset-demo'); toast('Демо-данные сброшены'); } catch (err) { fail(err); } }); } }, 'Сбросить демо-данные')
          : hasDemo ? h('button', { class: 'btn block', onclick: async (e) => { if (await TG.confirm('Убрать демо-ресурсы и связанные с ними публикации?')) busy(e.currentTarget, async () => { try { await api('DELETE', '/me/demo-data'); toast('Демо-данные удалены'); show('settings'); } catch (err) { fail(err); } }); } }, 'Убрать демо-данные')
            : h('button', { class: 'btn block', onclick: async (e) => busy(e.currentTarget, async () => { try { await api('POST', '/me/demo-data'); toast('Демо-данные загружены'); show('settings'); } catch (err) { fail(err); } }) }, 'Загрузить демо-данные')),
      h('div', { class: 'h2' }, 'О приложении'), h('div', { class: 'card list' },
        [['Версия', 'MarketPilot ' + S.status.version], ['Платформа Telegram', TG.platform + (TG.wa ? ' · WebApp ' + TG.wa.version : '')], ['Бот', S.status.telegram.connected ? '@' + S.status.telegram.username + ' — на связи' : 'нет связи с Telegram']].map(([a, b]) => h('div', { class: 'item', style: 'align-items:center' }, h('span', { class: 'muted' }, a), h('b', { class: 'right', style: 'text-align:right' }, b)))),
      h('div', { class: 'h2' }, 'Опасная зона'), h('div', { class: 'card' }, h('div', { class: 'muted small', style: 'margin-bottom:10px' }, 'Удаление аккаунта безвозвратно стирает ресурсы, публикации, шаблоны и историю в MarketPilot. Сообщения в Telegram не затрагиваются.'),
        h('button', { class: 'btn danger block', onclick: async () => { if (!(await TG.confirm('Удалить аккаунт и все данные безвозвратно?'))) return; if (!(await TG.confirm('Это действие нельзя отменить. Удалить?'))) return; try { await api('DELETE', '/me'); MP.token = ''; gate('👋', 'Аккаунт удалён', 'Все ваши данные в MarketPilot стёрты. Вы всегда можете начать заново: отправьте боту /start.', h('button', { class: 'btn primary', onclick: () => TG.close() }, 'Закрыть')); } catch (err) { fail(err); } } }, 'Удалить аккаунт')));
  };

  boot().catch((e) => fatal(e));
})();
